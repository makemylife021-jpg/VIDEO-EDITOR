

```
                            ### EFFECTS ###
```


## animate sliding onscroll / hierarchy  

> ### Lateral On-Scroll Sliding with jQuery  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2011/12/LateralOnScrollSliding.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou | December 5, 2011_  
> "Slide-in on scroll" effect. You've probably seen this cool effect on some websites, like on Nizo or in the portfolio section of brilliantly designed La Moulade. The main idea is to laterally slide in elements depending on the scroll position of the document. Dividing the page into a left and right side, we want to move the elements from "outside" of the page to the center when they are in the viewport.  
[tutorial](http://tympanus.net/codrops/2011/12/05/lateral-on-scroll-sliding-with-jquery/)
[demo](http://tympanus.net/Tutorials/LateralOnScrollSliding/)
[source](http://tympanus.net/Tutorials/LateralOnScrollSliding/LateralOnScrollSliding.zip)


## animate filter items  

> ### Filter Functionality with CSS3  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2012/01/CSS3FilterFunctionality.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou January 9, 2012_  
> Using the general sibling combinator and the :checked pseudo-class, we can toggle states of other elements by checking a checkbox or a radio button. In this tutorial we will be exploring those CSS3 properties by creating a experimental portfolio filter that will toggle the states of items of a specific type.  
[tutorial](http://tympanus.net/codrops/2012/01/09/filter-functionality-with-css3/)
[demo](http://tympanus.net/Tutorials/CSS3FilterFunctionality/)
[source](http://tympanus.net/Tutorials/CSS3FilterFunctionality/CSS3FilterFunctionality.zip)



## image slideshow  

> ### How to Create a Tiled Background Slideshow  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2014/06/FourBoxes.jpg)  
> :star: :star: :star:  
> _by Mary Lou | June 11, 2014_  
> Recreate the four tiles slideshow effect seen on the website of Serge Thoroval. Using 3D transforms, transitions and animations, the aim is to implement a smooth effect and add some variations.  
[tutorial](http://tympanus.net/codrops/2014/06/11/how-to-create-a-tiled-background-slideshow/)
[demo](http://tympanus.net/Tutorials/FourBoxes/)
[source](http://tympanus.net/Tutorials/FourBoxes/FourBoxes.zip)
[git](https://github.com/codrops/FourBoxes)

##   

> ### Slideshow with jmpress.js  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2012/04/SlideshowJmpress.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou | April 5, 2012_  
> Slideshow using jmpress.js. The jQuery plugin that is based on impress.js will allow us to use some interesting 3D effects for the slides.  
[tutorial](http://tympanus.net/codrops/2012/04/05/slideshow-with-jmpress-js/)
[demo](http://tympanus.net/Tutorials/SlideshowJmpress/)
[source](http://tympanus.net/Tutorials/SlideshowJmpress/SlideshowJmpress.zip)

##  

> ### Fullscreen Background Image Slideshow with CSS3 / overlay grid  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2011/12/CSS3FullscreenSlideshow.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou | January 2, 2012_  
> CSS-only fullscreen background image slideshow. We'll create different image transitions and also make a title appear using CSS animations.  
[tutorial](http://tympanus.net/codrops/2012/01/02/fullscreen-background-image-slideshow-with-css3/)
[demo](http://tympanus.net/Tutorials/CSS3FullscreenSlideshow/)
[source](http://tympanus.net/Tutorials/CSS3FullscreenSlideshow/CSS3FullscreenSlideshow.zip)

## animate accordion  

> ### Flexible Slide-to-top Accordion  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2011/10/FlexibleSlideToTopAccordion.jpg)  
> :star: :star: :star:  
> _by Mary Lou | October 12, 2011_  
> Simple responsive accordion that, when opened, will slide to the top of the viewport and reveal the content by fading it in. The idea is to avoid that the user has to scroll the content area into place. We'll also add some nice CSS3 transitions for the arrow to appear and to rotate when we click on an item. The accordion will be flexible, meaning that it will have a liquid width adjusting to the screen size.  
[tutorial](http://tympanus.net/codrops/2011/10/12/flexible-slide-to-top-accordion/)
[demo](http://tympanus.net/Tutorials/FlexibleSlideToTopAccordion/)
[source](http://tympanus.net/Tutorials/FlexibleSlideToTopAccordion/FlexibleSlideToTopAccordion.zip)


## image hover SVG-shape

> ### Shape Hover Effect with SVG  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2014/01/ShapeHoverEffect.png)  
> :star: :star: :star:  
> _by Mary Lou January 7, 2014_  
> The hover effect as seen on The Christmas Experiments website. We'll be using SVG for the shape and Snap.svg for animating it on hover.  
[tutorial](http://tympanus.net/codrops/2014/01/07/shape-hover-effect-with-svg/)
[demo](http://tympanus.net/Tutorials/ShapeHoverEffectSVG/)
[source](http://tympanus.net/Tutorials/ShapeHoverEffectSVG/ShapeHoverEffectSVG.zip)
[git](https://github.com/codrops/ShapeHoverEffectSVG)


## blur nav / grid overlay 

> ### Blur Menu with CSS3  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2011/10/BlurMenuwithCss3.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou | October 19, 2011_  
> Experiment with text shadows and with transitions in order to achieve a blur effect that we'll apply to a menu on hovering over the elements. The main idea is to blur the other items while enhancing the one we are currently hovering  
[tutorial](http://tympanus.net/codrops/2011/10/19/blur-menu-with-css3-transitions/)
[demo](http://tympanus.net/Tutorials/BlurMenu/)
[source](http://tympanus.net/Tutorials/BlurMenu/BlurMenu.zip)

## animate nav sliding  

> ### Sliding Background Image Menu with jQuery  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2011/07/SlidingBackgroundImageMenu.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou | July 3, 2011_  
> This menu will have several panels, each one corresponding to a different background image that will show on all panels when we hover over a panel label. Also, a submenu will slide out from the bottom. This menu comes with some configuration possibilities, such as size of the image, the hover effect and custom default states.  
[tutorial](http://tympanus.net/codrops/2011/07/03/sliding-background-image-menu/)
[demo](http://tympanus.net/Development/SlidingBackgroundImageMenu/example5.html)
[source](http://tympanus.net/Development/SlidingBackgroundImageMenu/SlidingBackgroundImageMenu.zip)


## animate buttons  

> ### Animated Buttons with CSS3  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2011/11/AnimatedButtons.jpg)  
> :star: :star: :star:  
> _by Mary Lou | November 7, 2011_  
> Still hyped by the possibilities of CSS3, I want to share some CSS3 button experiments with you. The idea is to create some animated link elements with different styles, hover effects and active states.  
[tutorial](http://tympanus.net/codrops/2011/11/07/animated-buttons-with-css3/)
[demo](http://tympanus.net/Tutorials/AnimatedButtons/)
[source](http://tympanus.net/Tutorials/AnimatedButtons/AnimatedButtons.zip)


## animate content tilted slideshow   

> ### Tilted Content Slideshow  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2014/03/TiltedContentSlideshow.jpg)  
> :star: :star: :star:  
> _by Mary Lou | March 13, 2014_  
> A tutorial on how to recreate the slideshow seen on the FWA landing page with 3D effects involving random animations.  
[tutorial](http://tympanus.net/codrops/2014/03/13/tilted-content-slideshow/)
[demo](http://tympanus.net/Tutorials/TiltedContentSlideshow/)
[source](http://tympanus.net/Tutorials/TiltedContentSlideshow/TiltedContentSlideshow.zip)











# EFFECTS IMAGE
```

    `7MMF'                                            
      MM                                              
      MM  `7MMpMMMb.pMMMb.   ,6"Yb.  .P"Ybmmm .gP"Ya  
      MM    MM    MM    MM  8)   MM :MI  I8  ,M'   Yb 
      MM    MM    MM    MM   ,pm9MM  WmmmP"  8M"""""" 
      MM    MM    MM    MM  8M   MM 8M       YM.    , 
    .JMML..JMML  JMML  JMML.`Moo9^Yo.YMMMMMb  `Mbmmd' 
                                    6'     dP         
                                    Ybmmmd'  

```

## image animate carousel  

> ### Elastislide – A Responsive jQuery Carousel Plugin  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2011/09/elastislide.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou | September 12, 2011_  
> Elastislide is a responsive image carousel that will adapt fluidly in a layout. It is a jQuery plugin that can be laid out horizontally or vertically with a pre-defined minimum number of shown images.  
[tutorial](http://tympanus.net/codrops/2011/09/12/elastislide-responsive-carousel/)
[demo](http://tympanus.net/Development/Elastislide/)
[source](http://tympanus.net/Development/Elastislide/Elastislide.zip)
[git](https://github.com/codrops/Elastislide)


## image blur  

> ### Fullscreen Image Blur Effect with HTML5  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2011/11/FullscreenImageBlur.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou November 18, 2011_  
> A neat image blur effect. Using canvas, we want to blur images on the transition to another one, creating a smooth effect.  
[tutorial](http://tympanus.net/codrops/2011/11/18/fullscreen-image-blur-effect-with-html5/)
[demo](http://tympanus.net/Development/FullscreenImageBlurEffect/)
[source](http://tympanus.net/Development/FullscreenImageBlurEffect/FullscreenImageBlurEffect.zip)


## image hover 

> ### Using Custom Data Attributes and Pseudo-Elements  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2013/07/PseudoElementsImageCaptions.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou | July 5, 2013_  
> A tutorial on how to (ab)use custom data attributes and pseudo-elements for creating image captions.  
[tutorial](http://tympanus.net/codrops/2013/07/05/using-custom-data-attributes-and-pseudo-elements/)
[demo](http://tympanus.net/Tutorials/PseudoElementsImageCaptions/)
[source](http://tympanus.net/Tutorials/PseudoElementsImageCaptions/PseudoElementsImageCaptions.zip)

##

> ### Ideas for Subtle Hover Effects
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2014/06/HoverEffectsIdeasNew.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou | June 19, 2014_  
> Some creative and subtle hover effect inspiration using modern CSS techniques including 3D translate and pseudo elements.
[tutorial](http://tympanus.net/codrops/2014/06/19/ideas-for-subtle-hover-effects/)
[demo](http://tympanus.net/Development/HoverEffectIdeas/)
[source](https://github.com/codrops/HoverEffectIdeas)

##  

> ### Original Hover Effects with CSS3  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2011/11/OriginalHoverEffects.jpg)  
> :star: :star: :star: :star:  
> _by Alessio Atzeni | November 2, 2011_  
> Some thumbnail hover effects with CSS3 transitions. On hover over a thumbnail, we will reveal some description of the thumbnail, using a different style in each example  
[tutorial](http://tympanus.net/codrops/2011/11/02/original-hover-effects-with-css3/)
[demo](http://tympanus.net/Tutorials/OriginalHoverEffects/)
[source](http://tympanus.net/Tutorials/OriginalHoverEffects/OriginalHoverEffects.zip)


## image zoom  

> ### Image Zoom Tour with jQuery  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2011/08/ImageZoomTour.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou | August 23, 2011_  
> A little zoom tour script. Showing a main image initially, we want to be able to zoom into certain parts of the image by clicking on tags, using another image for the closer view. This next step can contain other tags that again allow to show more images. We achieve the "zoom" effect by enlarging the current image and fading in the new one.  
[tutorial](http://tympanus.net/codrops/2011/08/23/image-zoom-tour/)
[demo](http://tympanus.net/Development/ImageZoomTour/)
[source](http://tympanus.net/Development/ImageZoomTour/ImageZoomTour.zip)

// == / EFFECTS IMAGE == 



# EFFECTS ANIMATION
```

                                ,,                            
          db                    db                            
         ;MM:                                                 
        ,V^MM.    `7MMpMMMb.  `7MM  `7MMpMMMb.pMMMb.  .gP"Ya  
       ,M  `MM      MM    MM    MM    MM    MM    MM ,M'   Yb 
       AbmmmqMA     MM    MM    MM    MM    MM    MM 8M"""""" 
      A'     VML    MM    MM    MM    MM    MM    MM YM.    , 
    .AMA.   .AMMA..JMML  JMML..JMML..JMML  JMML  JMML.`Mbmmd' 


```



## animate inputbox

> ### Text Input Effects
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2015/01/TextInputEffects1.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou | January 8, 2015_  
> Some inspiration for effects on text inputs using CSS transitions, animations and pseudo-elements.  
[tutorial](http://tympanus.net/codrops/2015/01/08/inspiration-text-input-effects/)
[demo](http://tympanus.net/Development/TextInputEffects/index2.html)
[source](https://github.com/codrops/TextInputEffects)

##

> ### Creative Add/Remove Effects for List Items with CSS3 Animations
> ![img](http://sarasoueidan.com/images/demo-6.png)  
> :star: :star: :star: :star: :star:  
> _by Sara Soueidan | June 27, 2013_  
> Some creative animations and transitions for adding and removing items from a list, inspired by the concept from [Pasquale D'Silva's article on Medium](https://medium.com/design-ux/926eb80d64e3). Chris Coyier [coded the transitions](http://css-tricks.com/transitional-interfaces-coded/) from Pasquale's article.  
> In this tutorial I'm extending Pasquale's example, adding more animations and transitional effects, and I'll also be using a small snippet from Chris's article to add an extra step in each animation, which "makes room" for the added items before they are actually added.  
[tutorial](http://sarasoueidan.com/blog/creative-list-effects/)
[demo](http://sarasoueidan.com/demos/creative-list-effects)
[source](http://github.com/sarasoueidan/creative-list-effects)


## animate background

> ### Animated Background Headers  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2014/09/AnimatedHeaderBackgrounds.png)  
> :star: :star: :star:  
> _by Rachel Smith | September 23, 2014_  
> A collection of animated background header effects for your inspiration. We use Canvas and Javascript to create an animated background for large site headers.  
[tutorial](http://tympanus.net/codrops/2014/09/23/animated-background-headers/)
[demo](http://tympanus.net/Development/AnimatedHeaderBackgrounds/)
[source](http://tympanus.net/Development/AnimatedHeaderBackgrounds/AnimatedHeaderBackgrounds.zip)


## animate items  

> ### Inspiration for Item Transitions  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2014/03/ItemTransitions.png)  
> :star: :star: :star: :star: :star:  
> _by Mary Lou | March 18, 2014_  
> Some inspiration and ideas for item transitions considering different scenarios and use cases, including a small component, a full-width image header and a product image with a transparent background. State transitions are done using CSS Animations.  
[tutorial](http://tympanus.net/codrops/2014/03/18/inspiration-for-item-transitions/)
[demo](http://tympanus.net/Development/ItemTransitions/)
[source](http://tympanus.net/Development/ItemTransitions/ItemTransitions.zip)


> ### Creative Link Effects
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2013/08/CreativeLinkEffects1.png)  
> :star: :star: :star: :star: :star:  
> _by Mary Lou | August 6, 2013_  
> An inspirational collection of experimental link effects mostly using transitions on pseudo-elements.  
[tutorial](http://tympanus.net/codrops/2013/08/06/creative-link-effects/)
[demo](http://tympanus.net/Development/CreativeLinkEffects/)
[source](http://tympanus.net/Development/CreativeLinkEffects/CreativeLinkEffects.zip)






## translate header  

> ### Inspiration for Article Intro Effects  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2014/05/ArticleIntroEffects.png)  
> :star: :star: :star: :star:  
> _by Mary Lou | May 22, 2014_  
> Some inspiration for effects applied to title headers of articles with a fullscreen image. The idea is to show some creative transition when continuing to the article body.  
[tutorial](http://tympanus.net/codrops/2014/05/22/inspiration-for-article-intro-effects/)
[demo](http://tympanus.net/Development/ArticleIntroEffects/)
[source](http://tympanus.net/Development/ArticleIntroEffects/ArticleIntroEffects.zip)

> ### Animated Resizing Header On Scroll
http://callmenick.com/post/animated-resizing-header-on-scroll


> ### Sliding Header Layout
http://tympanus.net/codrops/2014/12/23/sliding-header-layout/
https://github.com/codrops/SlidingHeaderLayout

## blur navigation images items 

> ### Motion Blur Effect with SVG  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2015/04/MotionBlur.jpg)  
> :star: :star: :star: :star:  
> _by Lucas Bebber | April 8, 2015_  
> Create a motion blur effect on HTML elements using JavaScript and an SVG blur filter.  
[tutorial](http://tympanus.net/codrops/2015/04/08/motion-blur-effect-svg/)
[demo](http://tympanus.net/Tutorials/MotionBlurEffect/)
[source](http://tympanus.net/Tutorials/MotionBlurEffect/MotionBlurEffect.zip)
[git](https://github.com/codrops/MotionBlurEffect)


## rotate quotes  

> ### Quotes Rotator  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2013/03/QuotesRotator.jpg)  
> :star: :star: :star: :star: :star:  
> _by Author | Januar 1, 2015_  
> A simple automatic quotes rotator with progress bar and example media query.  
[tutorial](http://tympanus.net/codrops/2013/03/29/quotes-rotator/)
[demo](http://tympanus.net/Blueprints/QuotesRotator/)
[source](https://github.com/codrops/Blueprint-QuotesRotator)

## rotate image

> ### Circular Content Carousel with jQuery  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2011/08/CircularContentCarousel.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou | August 16, 2011_  
> Simple circular content carousel. The idea is to have some content boxes that we can slide infinitely (circular). When clicking on the "more" link, the respective item moves to the left and a content area will slide out. Now we can navigate through the carousel where each step will reveal the next or previous content box with its expanded content. Clicking on the closing cross will slide the expanded content area back in and animate the item to its original position.  
[tutorial](http://tympanus.net/codrops/2011/08/16/circular-content-carousel/)
[demo](http://tympanus.net/Development/CircularContentCarousel/)
[source](http://tympanus.net/Development/CircularContentCarousel/CircularContentCarousel.zip)

## hover menu  

> ### Creative CSS3 Animation Menus  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2011/10/CreativeCSS3Menus.jpg)  
> :star: :star: :star:   
> _by Mary Lou | October 24, 2011_  
> Some creative menu hover effects in today's tutorial. The idea is to have a simple composition of elements, an icon, a main title and a secondary title, that will be animated on hover using only CSS transitions and animations. We'll be exploring some different effects for the elements.  
[tutorial](http://tympanus.net/codrops/2011/10/24/creative-css3-animation-menus/)
[demo](http://tympanus.net/Tutorials/CreativeCSS3AnimationMenus/)
[source](http://tympanus.net/Tutorials/CreativeCSS3AnimationMenus/CreativeCSS3AnimationMenus.zip)

##

> ### On Scroll Header Effects
> tutorial :star: :star: :star: :star: / by Mary Lou | July 16, 2013 
> headers that animate when scrolling the page  
![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2013/07/HeaderEffects.jpg)  
[tutorial](http://tympanus.net/codrops/2013/07/16/on-scroll-header-effects/)
[demo](http://tympanus.net/Development/HeaderEffects/)
[source](http://tympanus.net/Development/HeaderEffects/HeaderEffects.zip)

## Medium-Style Page Transition
> tutorial :star: :star: :star: :star: / by Brian Gonzalez | October 30, 2013
> lower article easing upward as the current article fades up and out
[tutorial](http://tympanus.net/codrops/2013/10/30/medium-style-page-transition/)
[demo](http://tympanus.net/Tutorials/MediumStylePageTransition/)
[source](https://github.com/briangonzalez/codrops-medium-style-page-transitions/archive/master.zip)



## Inspiration for Article Intro Effects
> tutorial :star: :star: :star: :star: / by Mary Lou | May 22, 2014  
> _Effects applied to title headers of articles with a fullscreen image. The idea is to show some creative transition when continuing to the article body_  
![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2014/05/ArticleIntroEffects.png)  
[tutorial]()
[demo]()
[source]()

# Animate
> animate.css (to animate) 
http://daneden.github.io/animate.css/


// == / EFFECTS ANIMATION == 



# EFFECTS SCROLL
```
//========================================================================== 
                                        ,,    ,,  
     .M"""bgd                         `7MM  `7MM  
    ,MI    "Y                           MM    MM  
    `MMb.      ,p6"bo `7Mb,od8 ,pW"Wq.  MM    MM  
      `YMMNq. 6M'  OO   MM' "'6W'   `Wb MM    MM  
    .     `MM 8M        MM    8M     M8 MM    MM  
    Mb     dM YM.    ,  MM    YA.   ,A9 MM    MM  
    P"Ybmmd"   YMbmd' .JMML.   `Ybmd9'.JMML..JMML.

//========================================================================== 
```

## scrollbar  

> ### Scrollbar Visibility with jScrollPane  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2011/09/ScrollbarVisibility.jpg)  
> :star: :star: :star:  
> _by Mary Lou | September 30, 2011_  
> Hide the scrollbar of elements in a website and only show it when the user really needs it like at the activity feed in Facebook.  
[tutorial](http://tympanus.net/codrops/2011/09/30/scrollbar-visibility-with-jscrollpane/)
[demo](http://tympanus.net/Tutorials/ScrollbarVisibility/)
[source](http://tympanus.net/Tutorials/ScrollbarVisibility/ScrollbarVisibility.zip)

##

> ### Perfect-scroll
> Minimalistic but perfect custom scrollbar plugin  
[doc](http://noraesae.github.com/perfect-scrollbar/)
[source](https://github.com/noraesae/perfect-scrollbar)

## scroll disable

> ### Disable touch scroll when off-canvas navigation is active  
> Medium inspired  
[source](http://codepen.io/rppld/pen/rfhvo)


// == / EFFECTS SCROLL == 


# EFFECTS VIDEO
```
//==========================================================================
                  ,,        ,,                    
    `7MMF'   `7MF'db      `7MM                    
      `MA     ,V            MM                    
       VM:   ,V `7MM   ,M""bMM  .gP"Ya   ,pW"Wq.  
        MM.  M'   MM ,AP    MM ,M'   Yb 6W'   `Wb 
        `MM A'    MM 8MI    MM 8M"""""" 8M     M8 
         :MM;     MM `Mb    MM YM.    , YA.   ,A9 
          VF    .JMML.`Wbmd"MML.`Mbmmd'  `Ybmd9'  
                                                  
//========================================================================== 
```

## video background slideshow

> ### Fullscreen Video Slideshow with BigVideo.js
> :star: :star: :star: :star:
> Create a slideshow-like fullscreen video background using BigVideo.js, a jQuery plugin for big background video.
[tutorial](http://tympanus.net/codrops/2012/09/19/fullscreen-video-slideshow-with-bigvideo-js/)
[demo](http://tympanus.net/Tutorials/BigVideoSlideshow/)
[source](http://tympanus.net/Tutorials/BigVideoSlideshow/BigVideoSlideshow.zip)


// == / EFFECTS VIDEO == 









# EFFECTS PARALLAX
```
//==========================================================================
                                          ,,    ,,                      
    `7MM"""Mq.                          `7MM  `7MM                      
      MM   `MM.                           MM    MM                      
      MM   ,M9 ,6"Yb.  `7Mb,od8 ,6"Yb.    MM    MM   ,6"Yb.  `7M'   `MF'
      MMmmdM9 8)   MM    MM' "'8)   MM    MM    MM  8)   MM    `VA ,V'  
      MM       ,pm9MM    MM     ,pm9MM    MM    MM   ,pm9MM      XMX    
      MM      8M   MM    MM    8M   MM    MM    MM  8M   MM    ,V' VA.  
    .JMML.    `Moo9^Yo..JMML.  `Moo9^Yo..JMML..JMML.`Moo9^Yo..AM.   .MA.
                                                                    
//==========================================================================
```

## parallax fixed background  

> ### Fixed Background Effect  
> ![img](http://0bf196087c14ed19d1f11cf1.ambercreativelab.netdna-cdn.com/wp-content/uploads/2015/03/fixed-background-effect-featured-new.png)  
> :star: :star: :star: :star: :star:  
> _by Sebastiano Guerriero | MARCH 25, 2015_  
> A simple template that takes advantage of the background-attachment CSS property to create a fixed background effect.  
[tutorial](http://codyhouse.co/gem/fixed-background-effect/)
[demo](http://codyhouse.co/demo/fixed-background-effect/index.html)
[source](http://codyhouse.co/redirect/?resource=fixed-background-effect)

## parallax slider 

> ### Parallax Content Slider with CSS3 and jQuery  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2012/03/Parallax-Content-Slider.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou | March 15, 2012_  
> A simple parallax content slider with different animations for each slider element and a background parallax effect. The idea for this comes from the slider of the Kendo UI homepage.  
[tutorial](http://tympanus.net/codrops/2012/03/15/parallax-content-slider-with-css3-and-jquery/)
[demo](http://tympanus.net/Development/ParallaxContentSlider/)
[source](http://tympanus.net/Development/ParallaxContentSlider/ParallaxContentSlider.zip)


#effects_parallax Pure CSS Parallax Websites
> tutorial :star: :star: :star: :star: /  how to use CSS transforms, perspective and some scaling trickery to create a pure CSS parallax scrolling website / see comments!
http://keithclark.co.uk/articles/pure-css-parallax-websites/
http://keithclark.co.uk/articles/pure-css-parallax-websites/demo3/
http://keithclark.co.uk/articles/pure-css-parallax-websites/demo3-webkit-overflow-fix/
http://codepen.io/keithclark/details/JycFw/

#Создаем сайт с эффектом Parallax, используя Stellar.js
http://habrahabr.ru/post/145772/
http://pavel.shimansky.ru/parallax_effect/
http://webdesigntutsplus.s3.amazonaws.com/tuts/338_parallax/src.zip

#effects_parallax Simple parallax scrolling tutorial
> tutorial :star: :star: :star: :star: :star: / by Petr Tichy
> how to setup your html for a parallax website
> how to animate background image at a different speed then page scrolling
> how to precisely control the timing and duration of your animations.
https://ihatetomatoes.net/simple-parallax-scrolling-tutorial/
http://ihatetomatoes.net/demos/simple-parallax-scrolling-tutorial/
http://ihatetomatoes.net/demos/simple-parallax-scrolling-tutorial-s.zip
#effect_parallax How To Create A Parallax Scrolling Website
https://ihatetomatoes.net/how-to-create-a-parallax-scrolling-website/
http://ihatetomatoes.net/demos/parallax-scroll-effect/


#effects_parallax A Simple Parallax Scrolling Technique
> tutorial :star: :star: :star: +
http://code.tutsplus.com/tutorials/a-simple-parallax-scrolling-technique--net-27641
http://cdn.tutsplus.com/net/uploads/legacy/2138_SimpleParallax/Demo/index.html
http://cdn.tutsplus.com/net/uploads/legacy/2138_SimpleParallax/source.zip


#effect_parallax Creating Scrolling Parallax Effects with CSS3
> tutorial :star: :star: :star: :star: / parallax with background-attachment: fixed
[Article](http://davidwalsh.name/parallax)
[demo](http://codepen.io/stefanjudis/pen/nrzHI?editors=010)


#effects_parallax Advanced Parallax Scrolling Effect
> tutorial :star: :star: :star: / parallax scrolling effect with a background image moving at a different speed to the content above it
http://callmenick.com/post/advanced-parallax-scrolling-effect
http://callmenick.com/_development/advanced-parallax-effect
http://callmenick.com/_development/advanced-parallax-effect/advanced-parallax-effect-source.zip
#effects_parallax Simple Parallax Scrolling Effect
http://callmenick.com/2014/07/15/simple-parallax-scrolling-effect/
http://callmenick.com/_development/simple-parallax-effect/
http://callmenick.com/_development/simple-parallax-effect/simple-parallax-effect-source.zip


#effects_parallax How to implement parallax effects on scroll using CSS & jQuery
> tutorial :star: :star: :star: / create parallax effects on scroll, by Andy Shora
http://andyshora.com/parallax.html


// == / EFFECTS PARALLAX == 






# EFFECTS MASONRY
//=============================================================================
```                                                                         
`7MMM.     ,MMF'                                                         
  MMMb    dPMM                                                           
  M YM   ,M MM   ,6"Yb.  ,pP"Ybd  ,pW"Wq.`7MMpMMMb.  `7Mb,od8 `7M'   `MF'
  M  Mb  M' MM  8)   MM  8I   `" 6W'   `Wb MM    MM    MM' "'   VA   ,V  
  M  YM.P'  MM   ,pm9MM  `YMMMa. 8M     M8 MM    MM    MM        VA ,V   
  M  `YM'   MM  8M   MM  L.   I8 YA.   ,A9 MM    MM    MM         VVV    
.JML. `'  .JMML.`Moo9^Yo.M9mmmP'  `Ybmd9'.JMML  JMML..JMML.       ,V     
                                                                 ,V      
                                                              OOb"       
```
//=============================================================================

## Masonry Three Super Easy Ways to Pull Off a Masonry Layout
> tutorial :star: :star: :star: / overview by Joshua Johnson
http://designshack.net/articles/css/masonry/
http://stackoverflow.com/questions/22742354/how-create-grid-out-of-images-of-different-sizes


#effects_masonry Seamless Responsive Photo Grid
> tutorial :star: :star: :star: :star: / by Chris Coyier
https://css-tricks.com/seamless-responsive-photo-grid/
http://codepen.io/team/css-tricks/pen/pvamyK


#effects_masonry - Cascading grid layout library
http://masonry.desandro.com/
http://masonry.desandro.com/masonry-docs.zip
http://cdnjs.cloudflare.com/ajax/libs/masonry/3.3.0/masonry.pkgd.min.js
https://github.com/desandro/masonry


#effects_masonry Google Grid Gallery
> tutorial :star: :star: :star: :star: / by Mary Lou March 21, 2014
> A responsive Masonry grid with a gallery view using 3D Transforms.
> Based on the gallery seen on the Chromebook Getting Started guide by Google.
http://tympanus.net/codrops/2014/03/21/google-grid-gallery/
http://tympanus.net/Blueprints/GridGallery/
http://tympanus.net/Blueprints/GridGallery/GridGallery.zip


> tutorial + + / responsive e-commerce grid
http://tympanus.net/codrops/2013/05/17/product-grid-layout/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+tympanus+%28Codrops%29
http://tympanus.net/Blueprints/ProductGridLayout/
http://tympanus.net/Blueprints/ProductGridLayout/ProductGridLayout.zip
[remake](http://www.sophrosynelife.com/2014/05/responsive-ecommerce-grid/)


## animate grid  

> ### Grid Item Animation Layout  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2015/04/GridItemAnimation.jpg)  
> :star: :star: :star: :star:  
> _by Mary Lou | April 15, 2015_  
> A responsive, magazine-like website layout with a grid item animation effect that happens when opening the content  
[tutorial](http://tympanus.net/codrops/2015/04/15/grid-item-animation-layout/)
[demo](http://tympanus.net/Development/AnimatedGridLayout/)
[source](http://tympanus.net/Development/AnimatedGridLayout/AnimatedGridLayout.zip)

##

> ### Recreating the “Design Samsung” Grid Loading Effect  
> ![img](http://codropspz.tympanus.netdna-cdn.com/codrops/wp-content/uploads/2014/05/SamsungGrid.png)  
> :star: :star: :star: :star:  
> _by Mary Lou | May 15, 2014_  
> A tutorial on how to achieve the grid loading effect seen on the "Design Samsung" site. The effect will show a colored element sliding in first and then sliding out again, revealing the image.  
[tutorial](http://tympanus.net/codrops/2014/05/15/recreating-the-design-samsung-grid-loading-effect/)
[demo](http://tympanus.net/Tutorials/SamsungGrid/)
[source](http://tympanus.net/Tutorials/SamsungGrid/SamsungGrid.zip)
[git](https://github.com/codrops/SamsungGrid)



// == / EFFECTS MASONRY == 



# EFFECTS STAMP
```
//========================================================================== 
                                                        
                                                        
     .M"""bgd mm                                        
    ,MI    "Y MM                                        
    `MMb.   mmMMmm  ,6"Yb.  `7MMpMMMb.pMMMb. `7MMpdMAo. 
      `YMMNq. MM   8)   MM    MM    MM    MM   MM   `Wb 
    .     `MM MM    ,pm9MM    MM    MM    MM   MM    M8 
    Mb     dM MM   8M   MM    MM    MM    MM   MM   ,AP 
    P"Ybmmd"  `Mbmo`Moo9^Yo..JMML  JMML  JMML. MMbmmd'  
                                               MM       
                                             .JMML.     
//========================================================================== 
```

## Time stamp - MomentJS
http://momentjs.com/

## Live stamp - LivestampJS
http://mattbradley.github.io/livestampjs/

// == / EFFECTS STAMP == 







