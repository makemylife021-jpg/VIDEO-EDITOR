def application(environ, start_response):
    zip = 'foo.zip'
    length = lengthof(zip)
    buff = readzip(zip)
    start_response('200 OK', [('Content-type', 'application/zip'), ('Content-Disposition', 'attachment; filename=' + zip), ('Content-Length',str(length))])

    return buff

def readzip(file):
    return open(file, 'rb').read()
    

def lengthof(file):
    import os.path
    return os.path.getsize(file)

from wsgiref import simple_server

if __name__ == '__main__':

    server = simple_server.make_server('', 8080, application)

    server.serve_forever()