# Meshes

Every shape is a **mesh**: a list of corner points and the flat faces between them. The built-in shapes build their
meshes for you. Knowing what's inside one lets you pick shapes that read well, and build your own when none fits.

## The idea

- **Vertices** are the corner points, in the shape's own coordinates, centered on its origin.
- **Faces** are flat polygons, each listing the vertices at its corners.
- **Edges** are where two faces meet. A wireframe draws them.
- Each face has a **normal**: an arrow pointing straight out of it. Normals decide which faces turn toward the
  camera and how brightly each face is lit.

The order a face lists its corners in sets which way its normal points. Listed **counterclockwise as seen from
outside**, the normal points out of the shape. List them the other way and the face is inside out: it's culled when
it should show, and shows when it should be hidden.

![Two triangles as seen from the camera: corners listed counterclockwise face the camera and are drawn, corners listed clockwise face away and are culled](../../img/effectguide/3d/winding.webp)

Faces must be **convex**: no corner may point inward. A shape with inward corners, such as a star, splits each such
face into triangles, which are always convex.

![A cube with one face's corners numbered counterclockwise and its outward normal, beside a star cap split into a fan of triangles](../../img/effectguide/3d/mesh_anatomy.webp)

Curved shapes are meshes too. A sphere is a band of flat faces, and more `segments` and `rings` make its outline
rounder at a higher cost per frame.

## Shape ownership

A body's `shape` is read-only: its mesh, surface and texture layouts are built from that shape when
`world.body(shape)` is called. Create another body to use a different shape, and attach the characters to it.


## In TTE

The Gallery example shows every built-in shape, a few at a time so each is large enough to read. Each shape is one body:

```python
body = self.world.body(shape, at=(x, 0, 0)).draw(self.look)  # shape is Cube(...), Torus(...) and so on.
body.rotate("x", 25)
body.spin("y", turns=1, frames=180, ease=easing.in_out_sine)
```

??? example "gallery.py"

    Save it in your community effects directory as `gallery.py`.

    ```python
    --8<-- "docs/effectguide/examples/3d/gallery/gallery.py"
    ```

```bash
tte --input-file concept_input.txt --canvas-width 80 --canvas-height 24 --anchor-text c gallery
```

![The ten shapes turning two or three at a time, each named underneath: cube, box and prism; pyramid, tetrahedron and octahedron; icosahedron and cylinder; sphere and torus](../../img/effectguide/gallery_demo.webp)

| Shape | Sizes | Faces |
| --- | --- | --- |
| `Cube(size)`, `Box(width, height, depth)` | Edge lengths | `"front"`, `"right"`, `"back"`, `"left"`, `"top"`, `"bottom"` |
| `Prism(sides, radius, height)` | `radius` is center to corner | Sides `0` to `sides - 1`, `"top"`, `"bottom"` |
| `Pyramid(sides, radius, height)` | Base radius and height | Sides `0` to `sides - 1`, `"bottom"` |
| `Cylinder(radius, height, segments)` | `segments` around | `"side"`, `"top"`, `"bottom"` |
| `Tetrahedron`, `Octahedron`, `Icosahedron` | `radius` to each corner | |
| `Sphere(radius, segments, rings)` | `segments` around, `rings` top to bottom | |
| `Torus(major_radius, minor_radius, segments, sides)` | Ring radius and tube radius | |

The faces are the ones the body's [surface](surfaces.md#faces) names, so one name means one face whether you lay text
out on it or draw it: `body.draw(Shaded(), faces={"front": Textured("1")})` gives the front of a cube its own look
(see the [die recipe](recipes.md#die)). Underneath, the mesh tags each face with a number in the same order, so a
cube's `"front"` is tag 0 and its `"bottom"` tag 5; `shape.face_tags()` lists them. Shapes without named faces, such
as the icosahedron, take mesh tags in `faces` instead.

The Star example builds its own shape. A custom shape subclasses `Shape`, like the built-in ones a frozen dataclass, and returns
a mesh from `build_mesh`. Once defined, it's used like any other shape:

```python
star = self.world.body(StarPrism()).draw(Shaded())
star.rotate("x", -70)  # Stand the star up, with a cap facing the viewer.
```

??? example "star.py"

    Save it in your community effects directory as `star.py`.

    ```python
    --8<-- "docs/effectguide/examples/3d/star/star.py"
    ```

=== "Shaded"

    ```bash
    tte --input-file concept_input.txt --canvas-width 80 --canvas-height 24 --anchor-text c star
    ```

    ![A five-pointed star prism tumbling](../../img/effectguide/star_demo.webp)

=== "Wireframe"

    ```bash
    tte --input-file concept_input.txt --canvas-width 80 --canvas-height 24 --anchor-text c star --wireframe
    ```

    ![The same star drawn as edges, showing the triangles in its caps](../../img/effectguide/star_wireframe_demo.webp)

`StarPrism.build_mesh` places a ring of corners at each end, alternating between the points and the notches. Each
side is a rectangle between the rings. Each cap is a fan of triangles around a center vertex, because the star's
outline isn't convex.

## Under the hood

[`geometry3d.Mesh`](../../engine/utils/geometry3d.md) holds `vertices` (`Vec3`s) and `faces` (`Face`s). A `Face`
has `indices` into the vertices, optional `uvs` for [texture mapping](textures.md), and a `tag`. The mesh works out
each face's normal from its corner order when it's created, and `edges()` lists each edge once.

The builders, such as `g3.box`, `g3.prism` and `g3.uv_sphere`, return meshes, and `mesh.scaled(x, y, z)` stretches
one. A `Shape` adds what a body needs on top of its mesh: `build_surface` for the grid characters sit on and
`texture_cell` for `Textured` looks.

A mesh is only for drawing. Characters sit on the body's **surface**, a grid built by `build_surface`, which is a
separate thing from the mesh's faces (see [Surfaces](surfaces.md)). A custom shape like `StarPrism` doesn't define
`build_surface`, so its body has no surface: it can be drawn, and characters can be attached to it with `(x, y, z)`
positions in its axes, as on a pivot.

## At cell resolution

- More faces cost more time but don't always look better. Past the point where each face covers only a few cells,
  extra detail is lost at cell resolution.
- Thin parts, like a torus's tube seen edge-on, can fall between cell centers. Keep every part a few cells thick.
- Flat faces show as flat patches of one symbol. That's what makes a cube read as a cube, and why a low-detail
  sphere looks faceted.

## Dimension contracts

Use positive dimensions for built-in shapes and mesh factories. They intentionally do not check
dimension signs: zero can collapse faces, and negative sizes can reverse winding and normals.
Shading and texture layouts for those sizes are not guaranteed. Body scale is a separate transform
and explicitly rejects non-positive values. Custom mesh faces should be flat, convex, and wound outward.
