# ChangeBlog Home

The ChangeBlog contains optional release write-ups, demos, and in-depth explanations of TTE Engine features.
The [changelog](../changelog.md) is the canonical release history; a blog post is not required for every release.

## Release Entries

* [0.15.0 - Go Fetch](./changeblog_0.15.0.md)
* [0.14.0 - Easier Easing](./changeblog_0.14.0.md)
* [0.13.0 - Still Alive](./changeblog_0.13.0.md)
* [0.12.0 - Color Parsing, Background Color, more Easing](./changeblog_0.12.0.md)
* [0.11.0 - Matrix Effect and Canvas+Text Anchoring](./changeblog_0.11.0.md)
* [0.10.0 - ColorShift, Canvas, Better Compatibility, and more Customization](./changeblog_0.10.0.md)
