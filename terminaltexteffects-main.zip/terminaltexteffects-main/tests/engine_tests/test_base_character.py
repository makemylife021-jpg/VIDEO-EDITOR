"""Tests for the base_character module including the BaseCharacter class and the EventHandler class."""

from __future__ import annotations

from typing import Any

import pytest

from terminaltexteffects.engine.base_character import EffectCharacter, EventHandler
from terminaltexteffects.engine.motion import Path
from terminaltexteffects.engine.terminal import Terminal, TerminalConfig
from terminaltexteffects.utils.exceptions.base_character_exceptions import (
    DuplicateEventRegistrationError,
    EventRegistrationCallerError,
    EventRegistrationTargetError,
)
from terminaltexteffects.utils.geometry import Coord

pytestmark = [pytest.mark.engine, pytest.mark.base_character, pytest.mark.smoke]


@pytest.fixture
def effectcharacter() -> EffectCharacter:
    """Fixture for creating an EffectCharacter instance."""
    return EffectCharacter(0, "a", 1, 1)


@pytest.fixture
def eventhandler(effectcharacter: EffectCharacter) -> EventHandler:
    """Fixture for creating an EventHandler instance."""
    return EventHandler(effectcharacter)


def test_eventhandler_init(eventhandler: EventHandler, effectcharacter: EffectCharacter) -> None:
    """Test the initialization of EventHandler."""
    assert eventhandler.character == effectcharacter
    assert eventhandler.registered_events == {}


def test_eventhandler_callback_init(eventhandler: EventHandler) -> None:
    """Test the initialization of EventHandler.Callback."""

    def func(*_: Any) -> None:
        pass

    cb = eventhandler.Callback(func, "a")
    assert cb.callback == func
    assert len(cb.args) == 1


@pytest.mark.parametrize(
    "event",
    [
        EventHandler.Event.PATH_COMPLETE,
        EventHandler.Event.PATH_ACTIVATED,
        EventHandler.Event.PATH_HOLDING,
        EventHandler.Event.SCENE_ACTIVATED,
        EventHandler.Event.SCENE_COMPLETE,
        EventHandler.Event.SEGMENT_ENTERED,
        EventHandler.Event.SEGMENT_EXITED,
    ],
)
def test_eventhandler_register_event_invalid_event_caller(
    event: EventHandler.Event,
    eventhandler: EventHandler,
) -> None:
    """Test registering an event with an invalid event caller."""
    with pytest.raises(EventRegistrationCallerError):
        eventhandler.register_event(event, 1, EventHandler.Action.ACTIVATE_PATH, Path("a"))  # type: ignore[call-overload]


@pytest.mark.parametrize(
    "event_caller_action_target",
    [
        (EventHandler.Event.PATH_COMPLETE, Path("a"), EventHandler.Action.ACTIVATE_PATH, 1),
        (EventHandler.Event.PATH_COMPLETE, Path("a"), EventHandler.Action.DEACTIVATE_PATH, 1),
        (EventHandler.Event.PATH_COMPLETE, Path("a"), EventHandler.Action.ACTIVATE_SCENE, 1),
        (EventHandler.Event.PATH_COMPLETE, Path("a"), EventHandler.Action.DEACTIVATE_SCENE, 1),
        (EventHandler.Event.PATH_COMPLETE, Path("a"), EventHandler.Action.CALLBACK, 1),
        (EventHandler.Event.PATH_COMPLETE, Path("a"), EventHandler.Action.SET_LAYER, ""),
        (EventHandler.Event.PATH_COMPLETE, Path("a"), EventHandler.Action.SET_COORDINATE, 1),
        (EventHandler.Event.PATH_COMPLETE, Path("a"), EventHandler.Action.RESET_APPEARANCE, 1),
    ],
)
def test_eventhandler_register_event_invalid_target(
    eventhandler: EventHandler,
    event_caller_action_target: tuple[EventHandler.Event, Path, EventHandler.Action, str],
) -> None:
    """Test registering an event with an invalid target."""
    event, caller, action, target = event_caller_action_target
    with pytest.raises(EventRegistrationTargetError):
        eventhandler.register_event(event, caller, action, target)  # type: ignore[call-overload]


def test_eventhandler_register_event(eventhandler: EventHandler) -> None:
    """Test registering a valid event."""
    p1 = Path("a")
    p2 = Path("b")
    eventhandler.register_event(EventHandler.Event.PATH_COMPLETE, p1, EventHandler.Action.ACTIVATE_PATH, p2)
    assert (
        eventhandler.registered_events[(EventHandler.Event.PATH_COMPLETE, p1)][0][0]
        is EventHandler.Action.ACTIVATE_PATH
    )
    assert eventhandler.registered_events[(EventHandler.Event.PATH_COMPLETE, p1)][0][1] is p2


def test_eventhandler_register_event_path_caller_with_id(eventhandler: EventHandler) -> None:
    """Test registering an event using a path ID caller."""
    caller = eventhandler.character.motion.new_path(path_id="caller")
    target = eventhandler.character.motion.new_path(path_id="target")
    eventhandler.register_event(
        EventHandler.Event.PATH_COMPLETE,
        "caller",
        EventHandler.Action.ACTIVATE_PATH,
        target,
    )
    assert eventhandler.registered_events[(EventHandler.Event.PATH_COMPLETE, caller)][0][1] is target


def test_eventhandler_register_event_scene_caller_with_id(eventhandler: EventHandler) -> None:
    """Test registering an event using a scene ID caller."""
    caller = eventhandler.character.animation.new_scene(scene_id="caller")
    target = eventhandler.character.animation.new_scene(scene_id="target")
    target.add_frame("a", duration=1)
    eventhandler.register_event(
        EventHandler.Event.SCENE_COMPLETE,
        "caller",
        EventHandler.Action.ACTIVATE_SCENE,
        target,
    )
    assert eventhandler.registered_events[(EventHandler.Event.SCENE_COMPLETE, caller)][0][1] is target


def test_eventhandler_register_event_activate_path_with_id(eventhandler: EventHandler) -> None:
    """Test registering ACTIVATE_PATH using a path ID target."""
    caller = eventhandler.character.motion.new_path(path_id="caller")
    target = eventhandler.character.motion.new_path(path_id="target")
    eventhandler.register_event(
        EventHandler.Event.PATH_COMPLETE,
        caller,
        EventHandler.Action.ACTIVATE_PATH,
        "target",
    )
    assert eventhandler.registered_events[(EventHandler.Event.PATH_COMPLETE, caller)][0][1] is target


def test_eventhandler_register_event_activate_scene_with_id(eventhandler: EventHandler) -> None:
    """Test registering ACTIVATE_SCENE using a scene ID target."""
    caller = eventhandler.character.animation.new_scene(scene_id="caller")
    target = eventhandler.character.animation.new_scene(scene_id="target")
    target.add_frame("a", duration=1)
    eventhandler.register_event(
        EventHandler.Event.SCENE_COMPLETE,
        caller,
        EventHandler.Action.ACTIVATE_SCENE,
        "target",
    )
    assert eventhandler.registered_events[(EventHandler.Event.SCENE_COMPLETE, caller)][0][1] is target


def test_eventhandler_register_event_deactivate_path_with_id(eventhandler: EventHandler) -> None:
    """Test registering DEACTIVATE_PATH using a path ID target."""
    caller = eventhandler.character.motion.new_path(path_id="caller")
    target = eventhandler.character.motion.new_path(path_id="target")
    eventhandler.register_event(
        EventHandler.Event.PATH_COMPLETE,
        caller,
        EventHandler.Action.DEACTIVATE_PATH,
        "target",
    )
    assert eventhandler.registered_events[(EventHandler.Event.PATH_COMPLETE, caller)][0][1] is target


def test_eventhandler_register_event_deactivate_path_with_object(eventhandler: EventHandler) -> None:
    """Test registering DEACTIVATE_PATH using a path object target."""
    caller = eventhandler.character.motion.new_path(path_id="caller")
    target = eventhandler.character.motion.new_path(path_id="target")
    eventhandler.register_event(
        EventHandler.Event.PATH_COMPLETE,
        caller,
        EventHandler.Action.DEACTIVATE_PATH,
        target,
    )
    assert eventhandler.registered_events[(EventHandler.Event.PATH_COMPLETE, caller)][0][1] is target


def test_eventhandler_register_event_deactivate_path_with_none_target(eventhandler: EventHandler) -> None:
    """Test registering DEACTIVATE_PATH without a target."""
    caller = eventhandler.character.motion.new_path(path_id="caller")
    eventhandler.register_event(
        EventHandler.Event.PATH_COMPLETE,
        caller,
        EventHandler.Action.DEACTIVATE_PATH,
    )
    assert eventhandler.registered_events[(EventHandler.Event.PATH_COMPLETE, caller)][0][1] is None


def test_eventhandler_register_event_deactivate_scene_with_id(eventhandler: EventHandler) -> None:
    """Test registering DEACTIVATE_SCENE using a scene ID target."""
    caller = eventhandler.character.animation.new_scene(scene_id="caller")
    target = eventhandler.character.animation.new_scene(scene_id="target")
    eventhandler.register_event(
        EventHandler.Event.SCENE_COMPLETE,
        caller,
        EventHandler.Action.DEACTIVATE_SCENE,
        "target",
    )
    assert eventhandler.registered_events[(EventHandler.Event.SCENE_COMPLETE, caller)][0][1] is target


def test_eventhandler_register_event_deactivate_scene_with_object(eventhandler: EventHandler) -> None:
    """Test registering DEACTIVATE_SCENE using a scene object target."""
    caller = eventhandler.character.animation.new_scene(scene_id="caller")
    target = eventhandler.character.animation.new_scene(scene_id="target")
    eventhandler.register_event(
        EventHandler.Event.SCENE_COMPLETE,
        caller,
        EventHandler.Action.DEACTIVATE_SCENE,
        target,
    )
    assert eventhandler.registered_events[(EventHandler.Event.SCENE_COMPLETE, caller)][0][1] is target


def test_eventhandler_register_event_deactivate_scene_with_none_target(eventhandler: EventHandler) -> None:
    """Test registering DEACTIVATE_SCENE without a target."""
    caller = eventhandler.character.animation.new_scene(scene_id="caller")
    eventhandler.register_event(
        EventHandler.Event.SCENE_COMPLETE,
        caller,
        EventHandler.Action.DEACTIVATE_SCENE,
    )
    assert eventhandler.registered_events[(EventHandler.Event.SCENE_COMPLETE, caller)][0][1] is None


def test_eventhandler_register_event_duplicate_raises_error(eventhandler: EventHandler) -> None:
    """Test that registering the same event-caller-action-target combination raises DuplicateEventRegistrationError."""
    p1 = Path("a")
    p2 = Path("b")

    # Register the event once - should succeed
    eventhandler.register_event(EventHandler.Event.PATH_COMPLETE, p1, EventHandler.Action.ACTIVATE_PATH, p2)

    # Try to register the same combination again - should raise error
    with pytest.raises(DuplicateEventRegistrationError):
        eventhandler.register_event(EventHandler.Event.PATH_COMPLETE, p1, EventHandler.Action.ACTIVATE_PATH, p2)


def test_eventhandler_registrations_remain_independent_between_characters() -> None:
    """Shared validation rules keep equal path IDs and action lists independent."""
    first = EffectCharacter(0, "a", 1, 1)
    second = EffectCharacter(1, "b", 2, 1)
    first_path = first.motion.new_path(path_id="shared")
    second_path = second.motion.new_path(path_id="shared")
    event = EventHandler.Event.PATH_COMPLETE
    action = EventHandler.Action.SET_LAYER

    first.event_handler.register_event(event, first_path, action, 1)
    second.event_handler.register_event(event, second_path, action, 2)
    first.event_handler._handle_event(event, first_path)
    assert first.layer == 1
    assert second.layer == 0

    first.event_handler.registered_events.clear()
    first.event_handler.register_event(event, first_path, action, 3)
    second.event_handler._handle_event(event, second_path)
    first.event_handler._handle_event(event, first_path)
    assert first.layer == 3
    assert second.layer == 2


def test_eventhandler_handle_event(eventhandler: EventHandler) -> None:
    """Test handling an event."""
    p1 = Path("a")
    p2 = Path("b")
    p2.new_waypoint(Coord(0, 0))
    eventhandler.register_event(EventHandler.Event.PATH_COMPLETE, p1, EventHandler.Action.ACTIVATE_PATH, p2)
    eventhandler._handle_event(EventHandler.Event.PATH_COMPLETE, p1)
    assert eventhandler.character.motion.active_path == p2


def test_eventhandler_handle_event_dispatches_scene_and_character_actions(eventhandler: EventHandler) -> None:
    """Test that scene and character actions execute with their registered targets."""
    caller = Path("caller")
    scene = eventhandler.character.animation.new_scene(scene_id="scene")
    scene.add_frame("b", duration=1)
    callback_characters: list[EffectCharacter] = []
    callback = EventHandler.Callback(callback_characters.append)
    target_coord = Coord(3, 4)
    event = EventHandler.Event.PATH_COMPLETE

    eventhandler.character.animation.set_appearance("x")
    eventhandler.register_event(event, caller, EventHandler.Action.ACTIVATE_SCENE, scene)
    eventhandler.register_event(event, caller, EventHandler.Action.SET_LAYER, 5)
    eventhandler.register_event(event, caller, EventHandler.Action.SET_COORDINATE, target_coord)
    eventhandler.register_event(event, caller, EventHandler.Action.RESET_APPEARANCE)
    eventhandler.register_event(event, caller, EventHandler.Action.CALLBACK, callback)

    eventhandler._handle_event(event, caller)

    assert eventhandler.character.animation.active_scene is scene
    assert eventhandler.character.layer == 5
    assert eventhandler.character.motion.current_coord == target_coord
    assert eventhandler.character.animation.current_character_visual.symbol == "a"
    assert callback_characters == [eventhandler.character]


def test_eventhandler_handle_event_deactivate_path_with_none_target(eventhandler: EventHandler) -> None:
    """Test handling DEACTIVATE_PATH with no target deactivates the active path."""
    caller = eventhandler.character.motion.new_path(path_id="caller")
    active = eventhandler.character.motion.new_path(path_id="active")
    active.new_waypoint(Coord(0, 0))
    eventhandler.character.motion.activate_path(active)
    eventhandler.register_event(
        EventHandler.Event.PATH_COMPLETE,
        caller,
        EventHandler.Action.DEACTIVATE_PATH,
    )
    eventhandler._handle_event(EventHandler.Event.PATH_COMPLETE, caller)
    assert eventhandler.character.motion.active_path is None


def test_eventhandler_handle_event_deactivate_path_with_id_target(eventhandler: EventHandler) -> None:
    """Test handling DEACTIVATE_PATH with a path ID target deactivates that path."""
    caller = eventhandler.character.motion.new_path(path_id="caller")
    active = eventhandler.character.motion.new_path(path_id="active")
    active.new_waypoint(Coord(0, 0))
    eventhandler.character.motion.activate_path(active)
    eventhandler.register_event(
        EventHandler.Event.PATH_COMPLETE,
        caller,
        EventHandler.Action.DEACTIVATE_PATH,
        "active",
    )
    eventhandler._handle_event(EventHandler.Event.PATH_COMPLETE, caller)
    assert eventhandler.character.motion.active_path is None


def test_eventhandler_handle_event_deactivate_scene_with_none_target(eventhandler: EventHandler) -> None:
    """Test handling DEACTIVATE_SCENE with no target deactivates the active scene."""
    caller = eventhandler.character.animation.new_scene(scene_id="caller")
    active = eventhandler.character.animation.new_scene(scene_id="active")
    active.add_frame("a", duration=1)
    eventhandler.character.animation.activate_scene(active)
    eventhandler.register_event(
        EventHandler.Event.SCENE_COMPLETE,
        caller,
        EventHandler.Action.DEACTIVATE_SCENE,
    )
    eventhandler._handle_event(EventHandler.Event.SCENE_COMPLETE, caller)
    assert eventhandler.character.animation.active_scene is None


def test_eventhandler_handle_event_deactivate_scene_with_id_target(eventhandler: EventHandler) -> None:
    """Test handling DEACTIVATE_SCENE with a scene ID target deactivates that scene."""
    caller = eventhandler.character.animation.new_scene(scene_id="caller")
    active = eventhandler.character.animation.new_scene(scene_id="active")
    active.add_frame("a", duration=1)
    eventhandler.character.animation.activate_scene(active)
    eventhandler.register_event(
        EventHandler.Event.SCENE_COMPLETE,
        caller,
        EventHandler.Action.DEACTIVATE_SCENE,
        "active",
    )
    eventhandler._handle_event(EventHandler.Event.SCENE_COMPLETE, caller)
    assert eventhandler.character.animation.active_scene is None


def test_effectcharacter_init(effectcharacter: EffectCharacter) -> None:
    """Test the initialization of EffectCharacter."""
    assert effectcharacter.character_id == 0
    assert effectcharacter._input_symbol == "a"
    assert effectcharacter._input_coord == Coord(1, 1)
    assert effectcharacter._is_visible is False
    assert effectcharacter.layer == 0
    assert effectcharacter.is_fill_character is False


def test_effectcharacter_repr(effectcharacter: EffectCharacter) -> None:
    """Test the __repr__ method of EffectCharacter."""
    assert repr(effectcharacter) == "EffectCharacter(character_id=0, symbol='a', input_column=1, input_row=1)"


def test_effectcharacter_set_input_coord_synchronizes_motion(effectcharacter: EffectCharacter) -> None:
    """Changing the layout coordinate also changes the character's current position."""
    coord = Coord(4, 3)

    effectcharacter._set_input_coord(coord)

    assert effectcharacter.input_coord == coord
    assert effectcharacter.motion.current_coord == coord


def test_effectcharacter_hash_consistency(effectcharacter: EffectCharacter) -> None:
    """Test the consistency of the __hash__ method of EffectCharacter."""
    assert hash(effectcharacter) == hash(effectcharacter)


def test_effectcharacter_objects_with_same_attributes_have_distinct_identity(effectcharacter: EffectCharacter) -> None:
    """Separately created characters retain distinct identity-based equality and hashes."""
    effectcharacter2 = EffectCharacter(0, "a", 1, 1)
    assert effectcharacter != effectcharacter2
    assert len({effectcharacter, effectcharacter2}) == 2


def test_effectcharacters_from_different_terminals_do_not_collide() -> None:
    """Terminal-local IDs must not collapse independent characters in sets or mappings."""
    first = Terminal("a", TerminalConfig()).get_characters()[0]
    second = Terminal("b", TerminalConfig()).get_characters()[0]

    assert first.character_id == second.character_id == 0
    assert first != second
    assert len({first, second}) == 2
    character_map = {first: "first", second: "second"}
    assert len(character_map) == 2
    assert character_map[first] == "first"
    assert character_map[second] == "second"


def test_effectcharacter_properties(effectcharacter: EffectCharacter) -> None:
    """Test the properties of EffectCharacter."""
    assert effectcharacter.input_symbol == "a"
    assert effectcharacter.input_coord == Coord(1, 1)
    assert effectcharacter.is_visible is False
    assert effectcharacter.character_id == 0
    assert effectcharacter.is_active is False


def test_effectcharacter_is_active(effectcharacter: EffectCharacter) -> None:
    """Test the is_active property of EffectCharacter."""
    assert effectcharacter.is_active is False
    p = effectcharacter.motion.new_path()
    p.new_waypoint(Coord(0, 0))
    effectcharacter.motion.activate_path(p)
    assert effectcharacter.is_active is True


def test_effectcharacter_tick_no_paths_or_scenes(effectcharacter: EffectCharacter) -> None:
    """Test that tick does not fail when there are no paths or scenes."""
    effectcharacter.tick()


def test_effectcharacter_tick_scene_and_path(effectcharacter: EffectCharacter) -> None:
    """Test that tick updates both scene and path correctly."""
    p = effectcharacter.motion.new_path()
    p.new_waypoint(Coord(3, 3))
    effectcharacter.motion.activate_path(p)
    s = effectcharacter.animation.new_scene()
    s.add_frame("a", duration=2)
    effectcharacter.animation.activate_scene(s)
    effectcharacter.tick()
    assert effectcharacter.animation.active_scene.frames[0].ticks_elapsed == 1  # type: ignore[union-attr]
    assert effectcharacter.motion.active_path.current_step == 1  # type: ignore[union-attr]


def test_effectcharacter_equal_invalid_type(effectcharacter: EffectCharacter) -> None:
    """Test that __eq__ returns NotImplemented when comparing with an invalid type."""
    assert effectcharacter.__eq__("a") is NotImplemented


def test_effectcharacter_hashes_by_character_id() -> None:
    """Sets of characters iterate in the same order on every run, since the hash doesn't depend on memory address."""
    first = EffectCharacter(7, "a", 1, 1)
    twin = EffectCharacter(7, "a", 1, 1)
    assert hash(first) == 7
    assert first != twin
    assert len({first, twin}) == 2
