"""Tests for the Path, Segment, Waypoint and Motion classes."""

from __future__ import annotations

import pytest

from terminaltexteffects.engine.base_character import EffectCharacter, EventHandler
from terminaltexteffects.engine.motion import Path, Segment, Waypoint
from terminaltexteffects.utils import easing
from terminaltexteffects.utils import geometry3d as g3
from terminaltexteffects.utils.exceptions import (
    ActivateEmptyPathError,
    DuplicatePathIDError,
    DuplicateWaypointIDError,
    PathInvalidSpeedError,
    PathNotFoundError,
    WaypointNotFoundError,
)
from terminaltexteffects.utils.geometry import Coord, find_length_of_bezier_curve, find_length_of_line

pytestmark = [pytest.mark.engine, pytest.mark.motion, pytest.mark.smoke]


@pytest.fixture
def character() -> EffectCharacter:
    """Fixture for creating an EffectCharacter instance."""
    return EffectCharacter(0, "a", 0, 0)


@pytest.fixture
def waypoint() -> Waypoint:
    """Fixture for creating a Waypoint instance."""
    return Waypoint(waypoint_id="waypoint_0", coord=Coord(0, 0), bezier_control=(Coord(0, 10),))


def test_waypoint_init(waypoint: Waypoint) -> None:
    """Test the initialization of a Waypoint."""
    assert waypoint.waypoint_id == "waypoint_0"
    assert waypoint.coord == Coord(0, 0)
    assert waypoint.bezier_control == (Coord(0, 10),)


def test_waypoint_equal_waypoint(waypoint: Waypoint) -> None:
    """Test equality of waypoints with the same ID and coordinates."""
    assert waypoint == Waypoint(waypoint_id="waypoint_0", coord=Coord(0, 0), bezier_control=(Coord(0, 10),))


def test_waypoint_equal_unqual_waypoint(waypoint: Waypoint) -> None:
    """Test inequality of waypoints with different IDs and coordinates."""
    assert waypoint != Waypoint(waypoint_id="waypoint_1", coord=Coord(1, 0), bezier_control=(Coord(0, 10),))


def test_waypoint_equal_different_type(waypoint: Waypoint) -> None:
    """Test inequality of waypoint with a different type."""
    assert waypoint != "waypoint_0"


def test_segment_length_no_bezier() -> None:
    """Test segment length calculation without bezier control points."""
    waypoint_0 = Waypoint(waypoint_id="waypoint_0", coord=Coord(0, 0))
    waypoint_1 = Waypoint(waypoint_id="waypoint_1", coord=Coord(10, 0))
    segment = Segment(waypoint_0, waypoint_1, find_length_of_line(waypoint_0.coord, waypoint_1.coord))
    line_length = 10
    assert segment.distance == line_length


def test_segment_length_bezier() -> None:
    """Test segment length calculation with bezier control points."""
    waypoint_0 = Waypoint(waypoint_id="waypoint_0", coord=Coord(0, 0), bezier_control=(Coord(5, 5),))
    waypoint_1 = Waypoint(waypoint_id="waypoint_1", coord=Coord(10, 0), bezier_control=(Coord(10, 10),))
    segment = Segment(
        waypoint_0,
        waypoint_1,
        find_length_of_bezier_curve(waypoint_0.coord, waypoint_0.bezier_control, waypoint_1.coord),  # type: ignore[arg-type]
    )
    bezier_length = 14.789428575445976
    assert segment.distance == pytest.approx(bezier_length, rel=1e-4)


def test_segment_is_hashable() -> None:
    """Test that a Segment instance is hashable."""
    waypoint_0 = Waypoint(waypoint_id="waypoint_0", coord=Coord(0, 0))
    waypoint_1 = Waypoint(waypoint_id="waypoint_1", coord=Coord(10, 0))
    segment = Segment(waypoint_0, waypoint_1, find_length_of_line(waypoint_0.coord, waypoint_1.coord))
    assert hash(segment) == hash((waypoint_0, waypoint_1))


def test_segment_equal_segment() -> None:
    """Test equality of segments with the same waypoints and distance."""
    waypoint_0 = Waypoint(waypoint_id="waypoint_0", coord=Coord(0, 0))
    waypoint_1 = Waypoint(waypoint_id="waypoint_1", coord=Coord(10, 0))
    segment = Segment(waypoint_0, waypoint_1, find_length_of_line(waypoint_0.coord, waypoint_1.coord))
    assert segment == Segment(waypoint_0, waypoint_1, find_length_of_line(waypoint_0.coord, waypoint_1.coord))


def test_segment_equal_incorrect_type() -> None:
    """Test inequality of segment with a different type."""
    waypoint_0 = Waypoint(waypoint_id="waypoint_0", coord=Coord(0, 0))
    waypoint_1 = Waypoint(waypoint_id="waypoint_1", coord=Coord(10, 0))
    segment = Segment(waypoint_0, waypoint_1, find_length_of_line(waypoint_0.coord, waypoint_1.coord))
    assert segment != "segment"


def test_path_init() -> None:
    """Test the initialization of a Path."""
    p = Path("path_0")
    assert p.path_id == "path_0"
    assert p.speed == 1
    assert p.ease is None
    assert p.layer is None
    assert p.hold_time == 0
    assert p.loop is False
    assert p.segments == []
    assert p.waypoints == []
    assert p.waypoint_lookup == {}
    assert p.total_distance == 0
    assert p.current_step == 0
    assert p.max_steps == 0
    assert p.hold_time_remaining == 0
    assert p.last_distance_reached == 0
    assert p.origin_segment is None


def test_path_init_invalid_speed() -> None:
    """Test initialization of a Path with invalid speed."""
    with pytest.raises(PathInvalidSpeedError):
        Path("path_0", speed=-1)


def test_path_new_waypoint_auto_id_generation() -> None:
    """Test auto ID generation for new waypoints.

    ID's should start at 0 and increment by 1 for each new waypoint.
    """
    p = Path("p")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    assert p.waypoints[0].waypoint_id == "0"
    assert p.waypoints[1].waypoint_id == "1"


def test_path_new_waypoint_auto_id_deleted_waypoints() -> None:
    """Test auto ID generation for new waypoints after deletion.

    ID's should start at 0 and increment by 1 for each new waypoint, even if waypoints have been deleted.
    """
    # waypoint auto ID's start at 0
    p = Path("p")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    p.new_waypoint(Coord(20, 0))
    p.waypoints.pop(-1)
    new_waypoint = p.new_waypoint(Coord(30, 0))
    assert new_waypoint.waypoint_id == "3"


def test_path_new_waypoint_duplicate_waypoint_id() -> None:
    """Test that creating a waypoint with a duplicate ID raises an error."""
    p = Path("p")
    p.new_waypoint(Coord(0, 0), waypoint_id="0")
    with pytest.raises(DuplicateWaypointIDError):
        p.new_waypoint(Coord(10, 0), waypoint_id="0")


def test_path_new_waypoint_bezier_as_single_coord() -> None:
    """Test that a single coordinate can be used as a bezier control point."""
    p = Path("p")
    p.new_waypoint(Coord(0, 0), bezier_control=Coord(0, 10))
    assert p.waypoints[0].bezier_control == (Coord(0, 10),)


def test_path_new_waypoint_bezier_as_tuple() -> None:
    """Test that a tuple can be used as bezier control points."""
    p = Path("p")
    p.new_waypoint(Coord(0, 0), bezier_control=(Coord(0, 10),))
    assert p.waypoints[0].bezier_control == (Coord(0, 10),)


def test_path_new_waypoint_multiple_waypoints_with_bezier_segment() -> None:
    """Test multiple waypoints with bezier segments."""
    p = Path("p")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0), bezier_control=Coord(10, 10))
    assert p.segments[0].distance == find_length_of_bezier_curve(Coord(0, 0), Coord(10, 10), Coord(10, 0))


@pytest.mark.parametrize(
    ("start", "control", "end"),
    [
        (Coord(0, 0), Coord(5, 0), Coord(10, 0)),
        (Coord(0, 0), Coord(0, 5), Coord(0, 10)),
        (Coord(0, 0), Coord(5, 5), Coord(10, 10)),
    ],
)
def test_straight_and_collinear_bezier_paths_have_equal_duration(
    start: Coord,
    control: Coord,
    end: Coord,
) -> None:
    """Test that terminal-adjusted line and Bézier paths take the same number of steps."""
    line_path = Path("line", speed=0.5)
    line_path.new_waypoint(start)
    line_path.new_waypoint(end)
    bezier_path = Path("bezier", speed=0.5)
    bezier_path.new_waypoint(start)
    bezier_path.new_waypoint(end, bezier_control=control)

    assert bezier_path.total_distance == pytest.approx(line_path.total_distance)
    assert bezier_path.max_steps == line_path.max_steps


def test_path_query_waypoint_valid_waypoint() -> None:
    """Test querying an existing waypoint ID in a path."""
    p = Path("p")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    assert p.query_waypoint("0") == p.waypoints[0]


def test_path_query_waypoint_invalid_waypoint() -> None:
    """Test querying a non-existing waypoint ID in a path."""
    p = Path("p")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    with pytest.raises(WaypointNotFoundError):
        p.query_waypoint("2")


def test_path_step_zero_distance(character: EffectCharacter) -> None:
    """Test stepping through a path with zero distance."""
    p = Path("p")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(0, 0))
    assert p.step(character.event_handler) == g3.Vec3(0, 0, 0)


def test_path_step_single_segment(character: EffectCharacter) -> None:
    """Test stepping through a single segment path."""
    p = Path("p")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    current_point = p.step(character.event_handler)
    while current_point != g3.Vec3(10, 0, 0):
        current_point = p.step(character.event_handler)


def test_path_step_single_segment_eased(character: EffectCharacter) -> None:
    """Test stepping through a single segment path with easing."""
    p = Path("p", ease=easing.in_out_sine)
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    current_point = p.step(character.event_handler)
    while current_point != g3.Vec3(10, 0, 0):
        current_point = p.step(character.event_handler)


def test_path_step_multiple_segments(character: EffectCharacter) -> None:
    """Test stepping through a path with multiple segments."""
    p = Path("p")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    p.new_waypoint(Coord(10, 10))
    p.new_waypoint(Coord(0, 10))
    current_point = p.step(character.event_handler)
    while current_point != g3.Vec3(0, 10, 0):
        current_point = p.step(character.event_handler)


def test_path_step_hopped_segments_trigger_enter_and_exit(character: EffectCharacter) -> None:
    """Test that fully crossed segments trigger both enter and exit events."""
    p = Path("p", speed=25)
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    p.new_waypoint(Coord(20, 0))
    p.new_waypoint(Coord(30, 0))
    p.new_waypoint(Coord(40, 0))
    p.new_waypoint(Coord(50, 0))
    triggered_events: list[str] = []

    for waypoint, enter_label, exit_label in (
        (p.waypoints[1], "enter_1", "exit_1"),
        (p.waypoints[2], "enter_2", "exit_2"),
        (p.waypoints[3], "enter_3", "exit_3"),
    ):
        character.event_handler.register_event(
            EventHandler.Event.SEGMENT_ENTERED,
            waypoint,
            EventHandler.Action.CALLBACK,
            EventHandler.Callback(lambda _character, label: triggered_events.append(label), enter_label),
        )
        character.event_handler.register_event(
            EventHandler.Event.SEGMENT_EXITED,
            waypoint,
            EventHandler.Action.CALLBACK,
            EventHandler.Callback(lambda _character, label: triggered_events.append(label), exit_label),
        )

    p.step(character.event_handler)

    assert triggered_events == ["enter_1", "exit_1", "enter_2", "exit_2", "enter_3"]


def test_path_step_boundary_segment_does_not_trigger_exit(character: EffectCharacter) -> None:
    """Test that landing exactly on a segment boundary enters but does not exit that segment."""
    p = Path("p", speed=10)
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    p.new_waypoint(Coord(20, 0))
    triggered_events: list[str] = []

    character.event_handler.register_event(
        EventHandler.Event.SEGMENT_ENTERED,
        p.waypoints[1],
        EventHandler.Action.CALLBACK,
        EventHandler.Callback(lambda _character: triggered_events.append("enter_1")),
    )
    character.event_handler.register_event(
        EventHandler.Event.SEGMENT_EXITED,
        p.waypoints[1],
        EventHandler.Action.CALLBACK,
        EventHandler.Callback(lambda _character: triggered_events.append("exit_1")),
    )
    character.event_handler.register_event(
        EventHandler.Event.SEGMENT_ENTERED,
        p.waypoints[2],
        EventHandler.Action.CALLBACK,
        EventHandler.Callback(lambda _character: triggered_events.append("enter_2")),
    )

    p.step(character.event_handler)

    assert triggered_events == ["enter_1"]


def test_path_step_multiple_segments_eased(character: EffectCharacter) -> None:
    """Test stepping through a path with multiple segments and easing."""
    p = Path("p", ease=easing.in_out_elastic)
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    p.new_waypoint(Coord(10, 10))
    p.new_waypoint(Coord(0, 10))
    current_point = p.step(character.event_handler)
    while current_point != g3.Vec3(0, 10, 0):
        current_point = p.step(character.event_handler)


def test_path_step_multiple_segments_zero_distance(character: EffectCharacter) -> None:
    """Test stepping through a path with multiple segments and zero distance."""
    p = Path("p")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(0, 0))
    current_point = p.step(character.event_handler)
    while current_point != g3.Vec3(0, 0, 0):
        current_point = p.step(character.event_handler)


def test_path_step_multiple_segments_mutiple_bezier(character: EffectCharacter) -> None:
    """Test stepping through a path with multiple segments and multiple bezier control points."""
    p = Path("p")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0), bezier_control=Coord(10, 10))
    p.new_waypoint(Coord(10, 10), bezier_control=Coord(0, 10))
    p.new_waypoint(Coord(0, 10), bezier_control=Coord(0, 0))
    current_point = p.step(character.event_handler)
    while current_point != g3.Vec3(0, 10, 0):
        current_point = p.step(character.event_handler)


def test_path_equality() -> None:
    """Test equality of paths with the same waypoints."""
    p1 = Path("p")
    p1.new_waypoint(Coord(0, 0))
    p1.new_waypoint(Coord(10, 0))
    p1.new_waypoint(Coord(10, 10))
    p1.new_waypoint(Coord(0, 10))

    p2 = Path("p")
    p2.new_waypoint(Coord(0, 0))
    p2.new_waypoint(Coord(10, 0))
    p2.new_waypoint(Coord(10, 10))
    p2.new_waypoint(Coord(0, 10))

    assert p1 == p2


def test_path_equality_invalid_type() -> None:
    """Test inequality of path with a different type."""
    p = Path("p")
    assert p != "p"


def test_motion_set_coordinate(character: EffectCharacter) -> None:
    """Test setting the coordinate of a character."""
    character.motion.set_coordinate(Coord(10, 10))
    assert character.motion.current_coord == Coord(10, 10)


def test_motion_new_path_duplicate_path_id(character: EffectCharacter) -> None:
    """Test creating a new path with a duplicate ID raises an error."""
    character.motion.new_path(path_id="0")
    with pytest.raises(DuplicatePathIDError):
        character.motion.new_path(path_id="0")


def test_motion_new_path_auto_id_avoid_duplicate(character: EffectCharacter) -> None:
    """Test auto ID generation for new paths avoiding duplicates."""
    character.motion.new_path(path_id="1")
    character.motion.new_path(path_id="2")
    character.motion.new_path(path_id="3")
    new_path = character.motion.new_path()
    assert new_path.path_id == "4"


def test_motion_query_path_valid_path(character: EffectCharacter) -> None:
    """Test querying an existing path ID."""
    character.motion.new_path(path_id="0")
    character.motion.new_path(path_id="1")
    assert character.motion.query_path("0").path_id == "0"


def test_motion_query_path_invalid_path(character: EffectCharacter) -> None:
    """Test querying a non-existing path ID raises an error."""
    character.motion.new_path(path_id="0")
    character.motion.new_path(path_id="1")
    with pytest.raises(PathNotFoundError):
        character.motion.query_path("2")


def test_motion_movement_is_complete_no_active_paths(character: EffectCharacter) -> None:
    """Test checking if movement is complete with no active paths."""
    assert character.motion.movement_is_complete() is True


def test_motion_movement_is_complete_active_path_complete(character: EffectCharacter) -> None:
    """Test checking if movement is complete with an active path that is complete."""
    p = character.motion.new_path(path_id="0")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    character.motion.activate_path(p)
    while character.motion.active_path:
        character.motion.move()

    assert character.motion.movement_is_complete() is True


def test_motion_movement_is_complete_active_path_incomplete(character: EffectCharacter) -> None:
    """Test checking if movement is complete with an active path that is incomplete."""
    p = character.motion.new_path(path_id="0")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    character.motion.activate_path(p)

    assert character.motion.movement_is_complete() is False


def test_motion_chain_paths_single_path(character: EffectCharacter) -> None:
    """Test chaining a single path."""
    p = character.motion.new_path(path_id="0")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    character.motion.chain_paths(
        [
            p,
        ],
    )


def test_motion_chain_paths_multiple_paths(character: EffectCharacter) -> None:
    """Test chaining multiple paths."""
    p1 = character.motion.new_path(path_id="0")
    p1.new_waypoint(Coord(0, 0))
    p1.new_waypoint(Coord(10, 0))

    p2 = character.motion.new_path(path_id="1")
    p2.new_waypoint(Coord(10, 0))
    p2.new_waypoint(Coord(10, 10))

    character.motion.chain_paths([p1, p2])
    assert (EventHandler.Event.PATH_COMPLETE, p1) in character.event_handler.registered_events
    assert character.event_handler.registered_events[(EventHandler.Event.PATH_COMPLETE, p1)] == [
        (EventHandler.Action.ACTIVATE_PATH, p2),
    ]


def test_motion_chain_paths_multiple_paths_looping(character: EffectCharacter) -> None:
    """Test chaining multiple paths with looping."""
    p1 = character.motion.new_path(path_id="0")
    p1.new_waypoint(Coord(0, 0))
    p1.new_waypoint(Coord(10, 0))

    p2 = character.motion.new_path(path_id="1")
    p2.new_waypoint(Coord(10, 0))
    p2.new_waypoint(Coord(10, 10))

    character.motion.chain_paths([p1, p2], loop=True)
    assert (EventHandler.Event.PATH_COMPLETE, p1) in character.event_handler.registered_events
    assert character.event_handler.registered_events[(EventHandler.Event.PATH_COMPLETE, p1)] == [
        (EventHandler.Action.ACTIVATE_PATH, p2),
    ]
    assert (EventHandler.Event.PATH_COMPLETE, p2) in character.event_handler.registered_events
    assert character.event_handler.registered_events[(EventHandler.Event.PATH_COMPLETE, p2)] == [
        (EventHandler.Action.ACTIVATE_PATH, p1),
    ]


def test_motion_activate_path_first_waypoint_bezier(character: EffectCharacter) -> None:
    """Test activating a path with the first waypoint having a bezier control point."""
    p = character.motion.new_path(path_id="0")
    p.new_waypoint(Coord(0, 0), bezier_control=Coord(0, 10))
    p.new_waypoint(Coord(10, 0))
    character.motion.activate_path(p)
    assert character.motion.active_path == p


def test_motion_activate_path_by_id(character: EffectCharacter) -> None:
    """Test activating a path by path ID."""
    p = character.motion.new_path(path_id="path_0")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    character.motion.activate_path("path_0")
    assert character.motion.active_path == p


def test_motion_activate_path_no_waypoints(character: EffectCharacter) -> None:
    """Test activating a path with no waypoints raises an error."""
    p = character.motion.new_path(path_id="0")
    with pytest.raises(ActivateEmptyPathError):
        character.motion.activate_path(p)


def test_motion_active_path_with_layer(character: EffectCharacter) -> None:
    """Test activating a path with a layer."""
    p = character.motion.new_path(path_id="0", layer=1)
    p.new_waypoint(Coord(0, 0), bezier_control=Coord(0, 10))
    p.new_waypoint(Coord(10, 0))
    character.motion.activate_path(p)
    assert character.motion.active_path == p
    assert character.layer == 1


def test_motion_activate_path_previously_deactivated(character: EffectCharacter) -> None:
    """Test reactivating a path that was previously deactivated."""
    character.motion.set_coordinate(Coord(5, 5))
    p = character.motion.new_path(path_id="0")
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    character.motion.activate_path(p)
    first_origin_distance = p.origin_segment.distance if p.origin_segment else 0
    character.motion.deactivate_path(p)
    character.motion.set_coordinate(Coord(2, 2))
    character.motion.activate_path(p)
    second_origin_distance = p.origin_segment.distance if p.origin_segment else 0
    assert character.motion.active_path == p
    assert second_origin_distance < first_origin_distance


def test_motion_deactivate_path_without_arg(character: EffectCharacter) -> None:
    """Test deactivating the current active path without providing a target."""
    p = character.motion.new_path(path_id="0")
    p.new_waypoint(Coord(0, 0))
    character.motion.activate_path(p)
    character.motion.deactivate_path()
    assert character.motion.active_path is None


def test_motion_deactivate_path_by_object(character: EffectCharacter) -> None:
    """Test deactivating the active path by path object."""
    p = character.motion.new_path(path_id="path_0")
    p.new_waypoint(Coord(0, 0))
    character.motion.activate_path(p)
    character.motion.deactivate_path(p)
    assert character.motion.active_path is None


def test_motion_deactivate_path_by_id(character: EffectCharacter) -> None:
    """Test deactivating the active path by path ID."""
    p = character.motion.new_path(path_id="path_0")
    p.new_waypoint(Coord(0, 0))
    character.motion.activate_path(p)
    character.motion.deactivate_path("path_0")
    assert character.motion.active_path is None


def test_motion_move_no_active_path(character: EffectCharacter) -> None:
    """Test moving a character with no active path."""
    assert character.motion.active_path is None
    character.motion.move()


def test_motion_move_final_segment_triggers_exit_before_path_completion(character: EffectCharacter) -> None:
    """Test that completing a path exits its final segment before completing the path."""
    path = character.motion.new_path(speed=10)
    final_waypoint = path.new_waypoint(Coord(10, 0))
    triggered_events: list[str] = []
    for event, label in (
        (EventHandler.Event.SEGMENT_ENTERED, "entered"),
        (EventHandler.Event.SEGMENT_EXITED, "exited"),
        (EventHandler.Event.PATH_COMPLETE, "completed"),
    ):
        target = final_waypoint if event is not EventHandler.Event.PATH_COMPLETE else path
        character.event_handler.register_event(
            event,
            target,
            EventHandler.Action.CALLBACK,
            EventHandler.Callback(lambda _character, label: triggered_events.append(label), label),
        )

    character.motion.activate_path(path)
    character.motion.move()

    assert triggered_events == ["entered", "exited", "completed"]


def test_motion_final_segment_exit_callback_stops_path_completion(character: EffectCharacter) -> None:
    """Test that a final-segment exit callback can deactivate the path before completion."""
    path = character.motion.new_path(speed=10)
    final_waypoint = path.new_waypoint(Coord(10, 0))
    triggered_events: list[str] = []
    callback_coord = Coord(20, 20)

    def deactivate_path(char: EffectCharacter) -> None:
        triggered_events.append("exited")
        char.motion.set_coordinate(callback_coord)
        char.motion.deactivate_path()

    character.event_handler.register_event(
        EventHandler.Event.SEGMENT_EXITED,
        final_waypoint,
        EventHandler.Action.CALLBACK,
        EventHandler.Callback(deactivate_path),
    )
    character.event_handler.register_event(
        EventHandler.Event.PATH_COMPLETE,
        path,
        EventHandler.Action.CALLBACK,
        EventHandler.Callback(lambda _character: triggered_events.append("completed")),
    )

    character.motion.activate_path(path)
    character.motion.move()

    assert triggered_events == ["exited"]
    assert character.motion.active_path is None
    assert character.motion.current_coord == callback_coord


def test_motion_move_path_hold_time(character: EffectCharacter) -> None:
    """Test moving a character along a path with hold time."""
    p = character.motion.new_path(path_id="0", hold_time=5)
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    character.motion.activate_path(p)
    character.motion.move()
    while character.motion.active_path:
        character.motion.move()
    assert character.motion.active_path is None


def test_motion_move_path_looping(character: EffectCharacter) -> None:
    """Test moving a character along a looping path."""
    p = character.motion.new_path(path_id="0", loop=True)
    p.new_waypoint(Coord(0, 0))
    p.new_waypoint(Coord(10, 0))
    p.new_waypoint(Coord(10, 10))
    character.motion.activate_path(p)
    for _ in range(100):
        character.motion.move()


@pytest.mark.parametrize("change", ["deactivate", "replace", "restart"])
@pytest.mark.parametrize(
    ("event", "speed"),
    [
        pytest.param(EventHandler.Event.SEGMENT_ENTERED, 1, id="enter-current-segment"),
        pytest.param(EventHandler.Event.SEGMENT_ENTERED, 3, id="enter-crossed-segment"),
        pytest.param(EventHandler.Event.SEGMENT_EXITED, 3, id="exit-crossed-segment"),
        pytest.param(EventHandler.Event.PATH_HOLDING, 3, id="holding"),
    ],
)
def test_motion_callback_path_change(
    character: EffectCharacter,
    event: EventHandler.Event,
    speed: int,
    change: str,
) -> None:
    """Path-changing callbacks stop the old traversal without overwriting callback state."""
    path = character.motion.new_path(speed=speed, hold_time=2)
    first = path.new_waypoint(Coord(1, 0))
    last = path.new_waypoint(Coord(3, 0))
    replacement = character.motion.new_path(hold_time=4)
    replacement.new_waypoint(Coord(30, 10))
    callback_coord = Coord(10, 10)
    events: list[str] = []

    def change_path(char: EffectCharacter) -> None:
        events.append("change")
        char.motion.set_coordinate(callback_coord)
        if change == "deactivate":
            char.motion.deactivate_path()
        elif change == "replace":
            char.motion.activate_path(replacement)
        else:
            char.motion.activate_path(path)

    character.event_handler.register_event(
        event,
        path if event is EventHandler.Event.PATH_HOLDING else first,
        EventHandler.Action.CALLBACK,
        EventHandler.Callback(change_path),
    )
    if event is not EventHandler.Event.PATH_HOLDING:
        character.event_handler.register_event(
            EventHandler.Event.SEGMENT_ENTERED,
            last,
            EventHandler.Action.CALLBACK,
            EventHandler.Callback(lambda _: events.append("stale segment")),
        )
    character.event_handler.register_event(
        EventHandler.Event.PATH_COMPLETE,
        path,
        EventHandler.Action.CALLBACK,
        EventHandler.Callback(lambda _: events.append("stale completion")),
    )
    character.motion.activate_path(path)
    character.motion.move()

    assert events == ["change"]
    assert character.motion.current_coord == callback_coord
    assert character.motion.previous_coord == Coord(0, 0)
    if change == "deactivate":
        assert character.motion.active_path is None
        character.motion.move()
        assert character.motion.current_coord == callback_coord
    else:
        active_path = replacement if change == "replace" else path
        assert character.motion.active_path is active_path
        assert active_path.current_step == 0
        assert active_path.hold_time_remaining == active_path.hold_time
        assert active_path.origin_segment is not None
        assert active_path.origin_segment.start.coord == callback_coord
        character.event_handler.registered_events.clear()
        character.motion.move()
        assert active_path.current_step == 1
        # A slow diagonal step may round back to the origin on its first tick.
        character.motion.move()
        assert active_path.current_step == 2
        assert character.motion.current_coord != callback_coord


def test_motion_callback_deactivating_other_path_continues(character: EffectCharacter) -> None:
    """Deactivating an inactive path during an event must not interrupt movement."""
    path = character.motion.new_path()
    waypoint = path.new_waypoint(Coord(2, 0))
    other_path = character.motion.new_path()
    character.event_handler.register_event(
        EventHandler.Event.SEGMENT_ENTERED,
        waypoint,
        EventHandler.Action.DEACTIVATE_PATH,
        other_path,
    )
    character.motion.activate_path(path)

    character.motion.move()

    assert character.motion.active_path is path
    assert character.motion.current_coord == Coord(1, 0)


@pytest.mark.parametrize("bezier_control", [None, Coord(2, 8)])
def test_motion_reactivation_preserves_retained_origin_objects(
    character: EffectCharacter,
    bezier_control: Coord | None,
) -> None:
    """Repeated origins stay fresh while retained segments keep their previous state."""
    path = character.motion.new_path(speed=0.7, hold_time=2)
    path.new_waypoint(Coord(4, 4), bezier_control=bezier_control)
    path.new_waypoint(Coord(7, 6))
    character.motion.set_coordinate(Coord(1, 2))
    character.motion.activate_path(path)
    retained = path.origin_segment
    assert retained is not None
    distance = path.total_distance
    retained.enter_event_triggered = True
    retained.exit_event_triggered = True
    expected = vars(retained).copy()
    path.current_step = 5
    path.last_distance_reached = 2
    path.hold_time_remaining = 0

    character.motion.activate_path(path)

    assert path.origin_segment is not None
    assert path.origin_segment is not retained
    assert path.origin_segment.start is not retained.start
    assert vars(retained) == expected
    assert path.total_distance == distance
    assert path.current_step == path.last_distance_reached == 0
    assert path.hold_time_remaining == 2
    assert not path.origin_segment.enter_event_triggered
    assert not path.origin_segment.exit_event_triggered


def test_motion_activation_callback_restarts_from_new_origin(character: EffectCharacter) -> None:
    """An activation callback may restart the same path without stale origin data."""
    path = character.motion.new_path(speed=1)
    path.new_waypoint(Coord(4, 4))
    origins: list[Segment] = []

    def restart(char: EffectCharacter) -> None:
        assert path.origin_segment is not None
        origins.append(path.origin_segment)
        if len(origins) == 1:
            char.motion.set_coordinate(Coord(4, 3))
            char.motion.activate_path(path)

    character.event_handler.register_event(
        EventHandler.Event.PATH_ACTIVATED,
        path,
        EventHandler.Action.CALLBACK,
        EventHandler.Callback(restart),
    )
    character.motion.set_coordinate(Coord(1, 2))
    character.motion.activate_path(path)

    assert len(origins) == 2
    assert origins[0] is not origins[1]
    assert origins[0].start.coord == Coord(1, 2)
    assert origins[1].start.coord == Coord(4, 3)
    assert path.origin_segment is origins[1]
    assert path.total_distance == pytest.approx(2)
    assert path.max_steps == 2
    assert character.motion.current_coord == Coord(4, 3)
