"""Pytest fixtures and constants for terminaltexteffects package."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal, cast

import pytest

from terminaltexteffects import EffectCharacter, ParticlePool
from terminaltexteffects.effects import (
    effect_beams,
    effect_binarypath,
    effect_blackhole,
    effect_bouncyballs,
    effect_bubbles,
    effect_burn,
    effect_colorshift,
    effect_crumble,
    effect_decrypt,
    effect_errorcorrect,
    effect_expand,
    effect_fireworks,
    effect_highlight,
    effect_laseretch,
    effect_matrix,
    effect_middleout,
    effect_orbittingvolley,
    effect_overflow,
    effect_pour,
    effect_print,
    effect_rain,
    effect_random_sequence,
    effect_rings,
    effect_scattered,
    effect_slice,
    effect_slide,
    effect_smoke,
    effect_spotlights,
    effect_spray,
    effect_swarm,
    effect_sweep,
    effect_synthgrid,
    effect_thunderstorm,
    effect_unstable,
    effect_vhstape,
    effect_waves,
    effect_wipe,
)
from terminaltexteffects.engine.terminal import TerminalConfig
from terminaltexteffects.utils import geometry, graphics
from terminaltexteffects.utils.argutils import CharacterGroup
from terminaltexteffects.utils.easing import (
    EasingFunction,
    in_back,
    in_bounce,
    in_circ,
    in_cubic,
    in_elastic,
    in_expo,
    in_out_back,
    in_out_bounce,
    in_out_circ,
    in_out_cubic,
    in_out_elastic,
    in_out_expo,
    in_out_quad,
    in_out_quart,
    in_out_quint,
    in_out_sine,
    in_quad,
    in_quart,
    in_quint,
    in_sine,
    out_back,
    out_bounce,
    out_circ,
    out_cubic,
    out_elastic,
    out_expo,
    out_quad,
    out_quart,
    out_quint,
    out_sine,
)
from terminaltexteffects.utils.graphics import Color, Gradient
from tests.pairwise import select_pairwise_indices

if TYPE_CHECKING:
    from collections.abc import Callable, Generator

    from terminaltexteffects.engine.base_effect import BaseEffect
    from terminaltexteffects.engine.terminal import Terminal

INPUT_COMPACT = "ab\ncd"
INPUT_EMPTY = ""
INPUT_SINGLE_CHAR = "a"
INPUT_SINGLE_COLUMN = """
a
b
c
d
e
f"""
INPUT_SINGLE_ROW = "abcdefg"
INPUT_LARGE = """
0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ
123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0
23456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01
3456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ012
456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123
56789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234
6789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ012345
789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456
89abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567
9abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ012345678
"""
INPUT_MEDIUM = """
0123456789abcdefg
123456789abcdefgh
23456789abcdefghi
3456789abcdefghij
456789abcdefghijk"""
INPUT_TABS = """Tabs\tTabs\t\tTabs\t\t\tTabs"""
CANVAS_TEST_INPUT = """TL!!!!!!!!!!!!!!!!!!!!!TOP*********************TR
+                 <----50---->                  #
+                       |                       #
+                       |                       #
L        ^              |                       R
E        |              |                       I
F MID 13 |            CENTER                MID G
T        |              |                       H
-        v              |                       T
-                       |                       @
-                       |                       @
-                       |                       @
BL--------------------BOTTOM...................BR"""

COLOR_SEQUENCES = (
    "\x1b[38;5;231m....\x1b[39m....| \x1b[38;5;95m\x1b[48;5;128mggggggg\x1b[0m \x1b[38;5;180mggggggg "
    "\x1b[38;5;146m:gggggg; \x1b[38;5;64mggggggg \x1b[38;5;182mggggggg \x1b[38;5;195m:gggggg; "
    "\x1b[38;5;214mggggggg \x1b[38;5;146m;gggggg  \x1b[38;5;174mggggggg \x1b[0m"
)

TEST_INPUTS = {
    "empty": INPUT_EMPTY,
    "compact": INPUT_COMPACT,
    "single_char": INPUT_SINGLE_CHAR,
    "single_column": INPUT_SINGLE_COLUMN,
    "single_row": INPUT_SINGLE_ROW,
    "medium": INPUT_MEDIUM,
    "tabs": INPUT_TABS,
    "large": INPUT_LARGE,
    "canvas": CANVAS_TEST_INPUT,
    "color_sequences": COLOR_SEQUENCES,
}

EFFECTS = [
    effect_beams.Beams,
    effect_binarypath.BinaryPath,
    effect_blackhole.Blackhole,
    effect_bouncyballs.BouncyBalls,
    effect_bubbles.Bubbles,
    effect_burn.Burn,
    effect_colorshift.ColorShift,
    effect_crumble.Crumble,
    effect_decrypt.Decrypt,
    effect_errorcorrect.ErrorCorrect,
    effect_expand.Expand,
    effect_fireworks.Fireworks,
    effect_highlight.Highlight,
    effect_laseretch.LaserEtch,
    effect_matrix.Matrix,
    effect_middleout.MiddleOut,
    effect_orbittingvolley.OrbittingVolley,
    effect_overflow.Overflow,
    effect_pour.Pour,
    effect_print.Print,
    effect_rain.Rain,
    effect_random_sequence.RandomSequence,
    effect_rings.Rings,
    effect_scattered.Scattered,
    effect_slice.Slice,
    effect_slide.Slide,
    effect_smoke.Smoke,
    effect_spotlights.Spotlights,
    effect_spray.Spray,
    effect_thunderstorm.Thunderstorm,
    effect_swarm.Swarm,
    effect_sweep.Sweep,
    effect_synthgrid.SynthGrid,
    effect_unstable.Unstable,
    effect_vhstape.VHSTape,
    effect_waves.Waves,
    effect_wipe.Wipe,
]

EASING_FUNCTIONS = [
    in_sine,
    out_sine,
    in_out_sine,
    in_quad,
    out_quad,
    in_out_quad,
    in_cubic,
    out_cubic,
    in_out_cubic,
    in_quart,
    out_quart,
    in_out_quart,
    in_quint,
    out_quint,
    in_out_quint,
    in_expo,
    out_expo,
    in_out_expo,
    in_circ,
    out_circ,
    in_out_circ,
    in_elastic,
    out_elastic,
    in_out_elastic,
    in_back,
    out_back,
    in_out_back,
    in_bounce,
    out_bounce,
    in_out_bounce,
]

ANCHORS = ["sw", "s", "se", "e", "ne", "n", "nw", "w", "c"]

# Configuration matrices cover every individual value and every two-option interaction
# without repeatedly rendering the full Cartesian product. Keep dedicated default
# integration and geometry tests alongside these selected combinations.
PAIRWISE_EFFECT_TESTS = frozenset(
    {
        ("test_beams.py", "test_beams_effect_args"),
        ("test_beams.py", "test_beams_final_gradient"),
        ("test_binarypath.py", "test_binarypath_args"),
        ("test_binarypath.py", "test_binarypath_final_gradient"),
        ("test_blackhole.py", "test_blackhole_args"),
        ("test_blackhole.py", "test_blackhole_final_gradient"),
        ("test_bouncyballs.py", "test_bouncyballs_args"),
        ("test_bouncyballs.py", "test_bouncyballs_final_gradient"),
        ("test_bubbles.py", "test_bubbles_args"),
        ("test_bubbles.py", "test_bubbles_final_gradient"),
        ("test_burn.py", "test_burn_args"),
        ("test_burn.py", "test_burn_final_gradient"),
        (
            "test_character_order_effects.py",
            "test_character_order_effect_reversal_preserves_queue_and_final_appearance",
        ),
        ("test_character_order_effects.py", "test_character_order_sweep_reverses_phases_independently"),
        ("test_colorshift.py", "test_colorshift_args"),
        ("test_colorshift.py", "test_colorshift_final_gradient"),
        ("test_crumble.py", "test_crumble_final_gradient"),
        ("test_decrypt.py", "test_decrypt_args"),
        ("test_decrypt.py", "test_decrypt_final_gradient"),
        ("test_errorcorrect.py", "test_errorcorrect_args"),
        ("test_errorcorrect.py", "test_errorcorrect_final_gradient"),
        ("test_expand.py", "test_expand_args"),
        ("test_expand.py", "test_expand_final_gradient"),
        ("test_fireworks.py", "test_fireworks_args"),
        ("test_fireworks.py", "test_fireworks_final_gradient"),
        ("test_highlight.py", "test_highlight_args"),
        ("test_highlight.py", "test_highlight_final_gradient"),
        ("test_laseretch.py", "test_laseretch_args"),
        ("test_laseretch.py", "test_laseretch_final_gradient"),
        ("test_matrix.py", "test_matrix_args"),
        ("test_matrix.py", "test_matrix_final_gradient"),
        ("test_middleout.py", "test_middleout_args"),
        ("test_middleout.py", "test_middleout_final_gradient"),
        ("test_orbittingvolley.py", "test_orbittingvolley_args"),
        ("test_orbittingvolley.py", "test_orbittingvolley_easing"),
        ("test_orbittingvolley.py", "test_orbittingvolley_final_gradient"),
        ("test_overflow.py", "test_overflow_args"),
        ("test_overflow.py", "test_overflow_final_gradient"),
        ("test_pour.py", "test_pour_args"),
        ("test_pour.py", "test_pour_final_gradient"),
        ("test_print.py", "test_print_args"),
        ("test_print.py", "test_print_final_gradient"),
        ("test_rain.py", "test_rain_args"),
        ("test_rain.py", "test_rain_final_gradient"),
        ("test_randomsequence.py", "test_randomsequence_final_gradient"),
        ("test_rings.py", "test_rings_args"),
        ("test_rings.py", "test_rings_final_gradient"),
        ("test_scattered.py", "test_scattered_args"),
        ("test_scattered.py", "test_scattered_final_gradient"),
        ("test_slice.py", "test_slice_args"),
        ("test_slice.py", "test_slice_final_gradient"),
        ("test_slide.py", "test_slide_args"),
        ("test_slide.py", "test_slide_final_gradient"),
        ("test_smoke.py", "test_smoke_args"),
        ("test_smoke.py", "test_smoke_final_gradient"),
        ("test_spotlights.py", "test_spotlights_args"),
        ("test_spotlights.py", "test_spotlights_final_gradient"),
        ("test_spray.py", "test_spray_args"),
        ("test_spray.py", "test_spray_final_gradient"),
        ("test_swarm.py", "test_swarm_args"),
        ("test_swarm.py", "test_swarm_final_gradient"),
        ("test_sweep.py", "test_sweep_final_gradient"),
        ("test_sweep.py", "test_sweep_mixed_directions_activate_both_phases_in_order_and_restore_canvas"),
        ("test_sweep.py", "test_sweep_travel_speed_preserves_eased_prefixes_phase_handoff_and_animation_ticks"),
        ("test_synthgrid.py", "test_synthgrid_args"),
        ("test_synthgrid.py", "test_synthgrid_gradients"),
        ("test_thunderstorm.py", "test_thunderstorm_args"),
        ("test_thunderstorm.py", "test_thunderstorm_final_gradient"),
        ("test_unstable.py", "test_unstable_args"),
        ("test_unstable.py", "test_unstable_final_gradient"),
        ("test_vhstape.py", "test_vhstape_args"),
        ("test_vhstape.py", "test_vhstape_final_gradient"),
        ("test_waves.py", "test_waves_args"),
        ("test_waves.py", "test_waves_final_gradient"),
        ("test_waves.py", "test_waves_travel_speed_batches_entries_without_changing_order_or_animation_timing"),
        ("test_wipe.py", "test_wipe_args"),
        ("test_wipe.py", "test_wipe_final_gradient"),
    },
)


def pytest_addoption(parser: pytest.Parser) -> None:
    """Register options controlling the cost of effect configuration tests."""
    parser.addoption(
        "--exhaustive-effect-args",
        action="store_true",
        default=False,
        help="Run every Cartesian combination in effect configuration tests.",
    )


@pytest.hookimpl(hookwrapper=True)
def pytest_generate_tests(metafunc: pytest.Metafunc) -> Generator[None, None, None]:
    """Select pairwise calls after parametrization, before pytest creates test items.

    Pytest has no public API for removing generated calls. Keep the private
    `Metafunc._calls` access here; collection regression tests cover fixture
    scopes, indirect values, IDs, deterministic selection, and exhaustive mode.
    """
    yield
    test_id = (metafunc.definition.path.name, metafunc.function.__name__)
    if test_id not in PAIRWISE_EFFECT_TESTS or metafunc.config.getoption("--exhaustive-effect-args"):
        return
    calls = cast("Any", metafunc)._calls
    selected = select_pairwise_indices([call.params for call in calls])
    cast("Any", metafunc)._calls = [calls[index] for index in selected]


@pytest.fixture
def bounded_laseretch_sparks(
    request: pytest.FixtureRequest,
    monkeypatch: pytest.MonkeyPatch,
) -> Generator[None, None, None]:
    """Use real sparks sized for contract tests, retaining default-capacity integration.

    Scope this fixture explicitly to LaserEtch and ordering tests. General smoke
    cases bypass it for other effects, which share the `tte.ParticlePool` symbol.
    Unexpected growth fails rather than silently increasing fixture capacity.
    """
    if request.node.name == "test_laseretch_default_spark_pool_emits_and_reclaims" or (
        request.node.path.name == "test_effects.py"
        and cast("Any", request.node).callspec.params["effect"] is not effect_laseretch.LaserEtch
    ):
        yield
        return
    pools: list[ParticlePool] = []

    def unexpected_growth(symbol: str | None = None) -> EffectCharacter:
        del symbol
        pytest.fail("LaserEtch contract input exceeded its bounded spark pool; review coverage and capacity.")

    def make_pool(
        terminal: Terminal,
        active_characters: set[EffectCharacter],
        symbols: tuple[str, ...],
        *,
        initial_count: int,
        initializer: Callable[[EffectCharacter], None],
    ) -> ParticlePool:
        capacity = max(16, len(terminal.get_characters()))
        assert initial_count >= capacity
        pool = ParticlePool(terminal, active_characters, symbols, initial_count=capacity, initializer=initializer)
        monkeypatch.setattr(pool, "_create_particle", unexpected_growth)
        pools.append(pool)
        return pool

    monkeypatch.setattr(effect_laseretch.tte, "ParticlePool", make_pool)
    yield
    for pool in pools:
        assert len(pool.available) == len(pool.particles)


@pytest.fixture(autouse=True)
def clear_lru_cache() -> Generator[None, Any, None]:
    """Fixture to clear utility LRU caches."""
    yield
    for module in (geometry, graphics):
        for member in vars(module).values():
            cache_clear = getattr(member, "cache_clear", None)
            if callable(cache_clear):
                cache_clear()


@pytest.fixture
def input_data(request: pytest.FixtureRequest) -> str:
    """Fixture to provide input data for tests."""
    return TEST_INPUTS[request.param]


@pytest.fixture(params=EFFECTS)
def effect(request: pytest.FixtureRequest) -> BaseEffect:
    """Fixture to provide effect instances for tests."""
    return request.param


@pytest.fixture(params=EASING_FUNCTIONS)
def easing_function_1(request: pytest.FixtureRequest) -> EasingFunction:
    """Fixture to provide the first easing function for tests."""
    return request.param


@pytest.fixture(params=EASING_FUNCTIONS)
def easing_function_2(request: pytest.FixtureRequest) -> EasingFunction:
    """Fixture to provide the second easing function for tests."""
    return request.param


@pytest.fixture(params=[True, False])
def no_color(request: pytest.FixtureRequest) -> bool:
    """Fixture to provide a boolean indicating whether to disable color."""
    return request.param


@pytest.fixture(params=[True, False])
def xterm_colors(request: pytest.FixtureRequest) -> bool:
    """Fixture to provide a boolean indicating whether to use xterm colors."""
    return request.param


@pytest.fixture(params=ANCHORS)
def canvas_anchor(request: pytest.FixtureRequest) -> str:
    """Fixture to provide canvas anchor positions for tests."""
    return request.param


@pytest.fixture(params=ANCHORS)
def text_anchor(request: pytest.FixtureRequest) -> str:
    """Fixture to provide text anchor positions for tests."""
    return request.param


@pytest.fixture(params=[(60, 30), (25, 8)], ids=["60x30", "25x8"])
def canvas_dimensions(request: pytest.FixtureRequest) -> tuple[int, int]:
    """Fixture to provide canvas dimensions for tests."""
    return request.param


@pytest.fixture
def terminal_config_with_color_options(xterm_colors: bool, no_color: bool) -> TerminalConfig:  # noqa: FBT001
    """Fixture to provide terminal configuration with color options."""
    terminal_config = TerminalConfig._build_config()
    terminal_config.xterm_colors = xterm_colors
    terminal_config.no_color = no_color
    terminal_config.frame_rate = 0
    return terminal_config


@pytest.fixture
def terminal_config_default_no_framerate() -> TerminalConfig:
    """Fixture to provide terminal configuration with default settings and no frame rate."""
    terminal_config = TerminalConfig._build_config()
    terminal_config.frame_rate = 0
    return terminal_config


@pytest.fixture
def terminal_config_with_anchoring(
    canvas_dimensions: tuple[int, int],
    canvas_anchor: Literal["sw", "s", "se", "e", "ne", "n", "nw", "w", "c"],
    text_anchor: Literal["sw", "s", "se", "e", "ne", "n", "nw", "w", "c"],
) -> TerminalConfig:
    """Fixture to provide terminal configuration with anchoring options."""
    terminal_config = TerminalConfig._build_config()
    terminal_config.frame_rate = 0
    terminal_config.canvas_width = canvas_dimensions[0]
    terminal_config.canvas_height = canvas_dimensions[1]
    terminal_config.anchor_canvas = canvas_anchor
    terminal_config.anchor_text = text_anchor
    return terminal_config


@pytest.fixture(params=[(Color("#000000"), Color("#ff00ff"), Color("#0ffff0")), (Color("#ff0fff"),)])
def gradient_stops(request: pytest.FixtureRequest) -> tuple[Color, ...]:
    """Fixture to provide gradient stops for tests."""
    return request.param


@pytest.fixture(params=[(1,), (4,), (1, 3)])
def gradient_steps(request: pytest.FixtureRequest) -> tuple[int, ...]:
    """Fixture to provide gradient steps for tests."""
    return request.param


@pytest.fixture(params=[1, 4])
def gradient_frames(request: pytest.FixtureRequest) -> int:
    """Fixture to provide gradient frames for tests."""
    return request.param


@pytest.fixture(
    params=[
        Gradient.Direction.DIAGONAL,
        Gradient.Direction.HORIZONTAL,
        Gradient.Direction.VERTICAL,
        Gradient.Direction.RADIAL,
    ],
)
def gradient_direction(request: pytest.FixtureRequest) -> Gradient.Direction:
    """Fixture to provide gradient direction for tests."""
    return request.param


@pytest.fixture(params=[True, False])
def bool_arg(request: pytest.FixtureRequest) -> bool:
    """Fixture to provide boolean arguments for tests."""
    return request.param


@pytest.fixture(params=list(CharacterGroup))
def character_group(request: pytest.FixtureRequest) -> CharacterGroup:
    """Fixture to provide CharacterGroup arguments for tests."""
    return request.param
