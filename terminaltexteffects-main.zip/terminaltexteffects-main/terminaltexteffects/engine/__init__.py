"""TerminalTextEffects engine module."""
