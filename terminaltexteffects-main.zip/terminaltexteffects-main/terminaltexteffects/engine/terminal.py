"""A module for managing the terminal state and output.

Classes:
    TerminalConfig: Configuration for the terminal.
    Terminal: A class for managing the terminal state and output.
"""

from __future__ import annotations

import argparse
import math
import random
import shutil
import sys
import time
import typing
import weakref
from bisect import bisect_left, bisect_right
from contextlib import suppress
from copy import deepcopy
from dataclasses import FrozenInstanceError, dataclass
from operator import attrgetter
from typing import Literal

from terminaltexteffects.engine import canvas as canvas_module
from terminaltexteffects.engine._row_cache import RowCache
from terminaltexteffects.engine.base_character import EffectCharacter
from terminaltexteffects.engine.base_config import BaseConfig
from terminaltexteffects.engine.terminal_input import ParsedCharacter, VirtualScreenParser
from terminaltexteffects.engine.world import World
from terminaltexteffects.utils import ansitools, argutils, geometry
from terminaltexteffects.utils.argutils import CharacterGroup, CharacterOrder, CharacterSort, ColorSort
from terminaltexteffects.utils.exceptions import (
    InvalidCharacterCoordinateError,
    InvalidCharacterError,
    InvalidCharacterGroupError,
    InvalidCharacterOrderError,
    InvalidCharacterSortError,
    InvalidCharacterVisibilityError,
    InvalidColorSortError,
    TerminalOutputActiveError,
    TerminalOutputNotPreparedError,
)
from terminaltexteffects.utils.geometry import Coord
from terminaltexteffects.utils.graphics import Color
from terminaltexteffects.utils.terminal_text import get_symbol_cell_width

if typing.TYPE_CHECKING:
    from collections.abc import Callable

_CHARACTER_ID_KEY = attrgetter("_character_id")
_LAYER_KEY = attrgetter("_layer", "_depth_order")
_SPIRAL_SORT_OPTIONS: dict[CharacterOrder, tuple[int, tuple[int, ...]]] = {
    CharacterOrder.SPIRAL_CLOCKWISE: (1, (0,)),
    CharacterOrder.SPIRAL_COUNTER_CLOCKWISE: (-1, (0,)),
    CharacterOrder.SPIRAL_CLOCKWISE_DOUBLE: (1, (0, 2)),
    CharacterOrder.SPIRAL_COUNTER_CLOCKWISE_DOUBLE: (-1, (0, 2)),
    CharacterOrder.SPIRAL_CLOCKWISE_QUAD: (1, (0, 1, 2, 3)),
    CharacterOrder.SPIRAL_COUNTER_CLOCKWISE_QUAD: (-1, (0, 1, 2, 3)),
}


def _bisect_left_by_character_id(
    characters: list[EffectCharacter],
    character_id: int,
    *,
    key: Callable[[EffectCharacter], int],
) -> int:
    """Find a character ID's insertion point on Python versions without keyed bisection."""
    low, high = 0, len(characters)
    while low < high:
        middle = (low + high) // 2
        if key(characters[middle]) < character_id:
            low = middle + 1
        else:
            high = middle
    return low


_bisect_visible_characters = bisect_left if sys.version_info >= (3, 10) else _bisect_left_by_character_id


@dataclass
class TerminalConfig(BaseConfig):
    """Configuration for the terminal.

    Attributes:
        tab_width (int): Number of spaces to use for a tab character.
        xterm_colors (bool): Convert any colors specified in RGB hex to the closest XTerm-256 color.
        no_color (bool): Disable all colors in the effect.
        terminal_background_color (Color): Background color of the terminal used by effects that depend on it.
        existing_color_handling (Literal['always','dynamic','ignore']): Specify handling of existing ANSI SGR color
            sequences in the input data. Supported input colors include 3-bit, 4-bit, 8-bit, and 24-bit
            foreground/background sequences. 'always' will always use the input colors, ignoring any effect specific
            colors. 'dynamic' will leave it to the effect implementation to apply input colors. 'ignore' will ignore
            the colors in the input data. Default is 'ignore'.
        wrap_text (bool): Wrap text wider than the canvas width.
        frame_rate (int): Target frame rate for the animation in frames per second. Set to 0 to disable frame
            rate limiting.
        canvas_width (int): Canvas width, set to an integer > 0 to use a specific dimension, if set to 0 the canvas
            width is detected automatically based on the terminal device, if set to -1 the canvas width is based on
            the input data width.
        canvas_height (int): Canvas height, set to an integer > 0 to use a specific dimension, if set to 0 the canvas
            height is detected automatically based on the terminal device, if set to -1 the canvas height is
            based on the input data height.
        anchor_canvas (Literal['sw','s','se','e','ne','n','nw','w','c']): Anchor point for the Canvas. The Canvas will
            be anchored in the terminal to the location corresponding to the cardinal/diagonal direction.
            Defaults to 'sw'.
        anchor_text (Literal['n','ne','e','se','s','sw','w','nw','c']): Anchor point for the text within the Canvas.
            Input text will be anchored in the Canvas to the location corresponding to the cardinal/diagonal
            direction. Defaults to 'sw'.
        ignore_terminal_dimensions (bool): Ignore the terminal dimensions and utilize the full Canvas beyond the extents
            of the terminal. Useful for sending frames to another output handler.
        reuse_canvas (bool): Do not create new rows at the start of the effect. The cursor will be restored to the
            position of the previous canvas.
        no_eol (bool): Suppress the trailing newline emitted when an effect animation completes.
        no_restore_cursor (bool): Do not restore cursor visibility when an effect animation completes.

    """

    _is_frozen: typing.ClassVar[bool] = False

    def __setattr__(self, name: str, value: typing.Any) -> None:
        """Normalize assignments until this config becomes a terminal snapshot."""
        if self._is_frozen:
            message = f"cannot assign to field {name!r} on a terminal configuration snapshot"
            raise FrozenInstanceError(message)
        super().__setattr__(name, value)

    def _freeze(self) -> None:
        """Prevent mutation after the configuration is installed on a `Terminal`."""
        object.__setattr__(self, "_is_frozen", True)

    tab_width: int = argutils.ArgSpec(
        name="--tab-width",
        type=argutils.PositiveInt.type_parser,
        metavar=argutils.PositiveInt.METAVAR,
        default=4,
        help="Number of spaces to use for a tab character.",
    )  # pyright: ignore[reportAssignmentType]
    "int : Number of spaces to use for a tab character."

    xterm_colors: bool = argutils.ArgSpec(
        name="--xterm-colors",
        default=False,
        action="store_true",
        help="Convert any colors specified in 24-bit RGB hex to the closest 8-bit XTerm-256 color.",
    )  # pyright: ignore[reportAssignmentType]
    "bool : Convert any colors specified in 24-bit RGB hex to the closest 8-bit XTerm-256 color."

    no_color: bool = argutils.ArgSpec(
        name="--no-color",
        default=False,
        action="store_true",
        help="Disable all colors in the effect.",
    )  # pyright: ignore[reportAssignmentType]
    "bool : Disable all colors in the effect."

    terminal_background_color: Color = argutils.ArgSpec(
        name="--terminal-background-color",
        type=argutils.ColorArg.type_parser,
        default=Color("#000000"),
        metavar=argutils.ColorArg.METAVAR,
        help=(
            "The background color of your terminal. "
            "Used to determine the appropriate color for fade-in/out within effects."
        ),
    )  # type: ignore[assignment]
    "Color: User-defined background color of the terminal."

    existing_color_handling: Literal["always", "dynamic", "ignore"] = argutils.ArgSpec(
        name="--existing-color-handling",
        default="ignore",
        choices=["always", "dynamic", "ignore"],
        help=(
            "Specify handling of existing ANSI SGR color sequences in the input data. Supported input colors include "
            "3-bit, 4-bit, 8-bit, and 24-bit foreground/background sequences. 'always' will always use the input "
            "colors, ignoring any effect specific colors. 'dynamic' will leave it to the effect implementation to "
            "apply input colors. 'ignore' will ignore the colors in the input data. Default is 'ignore'."
        ),
    )  # pyright: ignore[reportAssignmentType]
    (
        "Literal['always','dynamic','ignore'] : Specify handling of existing ANSI SGR color sequences in the input "
        "data. Supported input colors include 3-bit, 4-bit, 8-bit, and 24-bit foreground/background sequences. "
        "'always' will always use the input colors, ignoring any effect specific colors. 'dynamic' will leave it to "
        "the effect implementation to apply input colors. 'ignore' will ignore the colors in the input data. "
        "Default is 'ignore'."
    )

    wrap_text: bool = argutils.ArgSpec(
        name="--wrap-text",
        default=False,
        action="store_true",
        help="Wrap text wider than the canvas width.",
    )  # pyright: ignore[reportAssignmentType]
    "bool : Wrap text wider than the canvas width."

    frame_rate: int = argutils.ArgSpec(
        name="--frame-rate",
        type=argutils.NonNegativeInt.type_parser,
        default=60,
        help=(
            "Target frame rate for the animation in frames per second. Set to 0 to disable frame rate limiting. "
            "Defaults to 60."
        ),
    )  # type: ignore[assignment]

    "int : Target frame rate for the animation in frames per second. Set to 0 to disable frame rate limiting."

    canvas_width: int = argutils.ArgSpec(
        name="--canvas-width",
        metavar=argutils.CanvasDimension.METAVAR,
        type=argutils.CanvasDimension.type_parser,
        default=-1,
        help=(
            "Canvas width, set to an integer > 0 to use a specific dimension, use 0 to match the terminal width, "
            "or use -1 to match the input text width. Defaults to -1."
        ),
    )  # pyright: ignore[reportAssignmentType]
    (
        "int : Canvas width, set to an integer > 0 to use a specific dimension, if set to 0 the canvas width is "
        "detected automatically based on the terminal device, if set to -1 the canvas width is based on "
        "the input data width. Defaults to -1."
    )

    canvas_height: int = argutils.ArgSpec(
        name="--canvas-height",
        metavar=argutils.CanvasDimension.METAVAR,
        type=argutils.CanvasDimension.type_parser,
        default=-1,
        help=(
            "Canvas height, set to an integer > 0 to use a specific dimension, use 0 to match the terminal "
            "height, or use -1 to match the input text height. Defaults to -1."
        ),
    )  # pyright: ignore[reportAssignmentType]
    (
        "int : Canvas height, set to an integer > 0 to use a specific dimension, if set to 0 the canvas height "
        "is detected automatically based on the terminal device, if set to -1 the canvas height is "
        "based on the input data height. Defaults to -1."
    )

    anchor_canvas: Literal["sw", "s", "se", "e", "ne", "n", "nw", "w", "c"] = argutils.ArgSpec(
        name="--anchor-canvas",
        choices=["sw", "s", "se", "e", "ne", "n", "nw", "w", "c"],
        default="sw",
        help=(
            "Anchor point for the canvas. The canvas will be anchored in the terminal to the location "
            "corresponding to the cardinal/diagonal direction. Defaults to 'sw'."
        ),
    )  # pyright: ignore[reportAssignmentType]
    (
        "Literal['sw','s','se','e','ne','n','nw','w','c'] : Anchor point for the canvas. The canvas will be "
        "anchored in the terminal to the location corresponding to the cardinal/diagonal direction. Defaults to 'sw'."
    )

    anchor_text: Literal["n", "ne", "e", "se", "s", "sw", "w", "nw", "c"] = argutils.ArgSpec(
        name="--anchor-text",
        choices=["n", "ne", "e", "se", "s", "sw", "w", "nw", "c"],
        default="sw",
        help=(
            "Anchor point for the text within the Canvas. Input text will be anchored in the Canvas to "
            "the location corresponding to the cardinal/diagonal direction. Defaults to 'sw'."
        ),
    )  # pyright: ignore[reportAssignmentType]
    (
        "Literal['n','ne','e','se','s','sw','w','nw','c'] : Anchor point for the text within the Canvas. "
        "Input text will be anchored in the Canvas to the location corresponding to the cardinal/diagonal direction. "
        "Defaults to 'sw'."
    )

    ignore_terminal_dimensions: bool = argutils.ArgSpec(
        name="--ignore-terminal-dimensions",
        default=False,
        action="store_true",
        help=(
            "Ignore the terminal dimensions and utilize the full Canvas beyond the extents of the terminal. "
            "Useful for sending frames to another output handler."
        ),
    )  # pyright: ignore[reportAssignmentType]
    (
        "bool : Ignore the terminal dimensions and utilize the full Canvas beyond the extents of the terminal. "
        "Useful for sending frames to another output handler."
    )

    reuse_canvas: bool = argutils.ArgSpec(
        name="--reuse-canvas",
        default=False,
        action="store_true",
        help=(
            "Do not create new rows at the start of the effect. The cursor will be moved up the number of rows "
            "present in the input text in an attempt to re-use the canvas. This option works best when used in "
            "a shell script. If used interactively with prompts between runs, the result is unpredictable."
        ),
    )  # pyright: ignore[reportAssignmentType]
    (
        "bool: Do not create new rows at the start of the effect. The cursor will be moved up the number of rows "
        "present in the input text in an attempt to re-use the canvas. This option works best when used in "
        "a shell script. If used interactively with prompts between runs, the result is unpredictable."
    )

    no_eol: bool = argutils.ArgSpec(
        name="--no-eol",
        default=False,
        action="store_true",
        help=("Suppress the trailing newline emitted when an effect animation completes."),
    )  # pyright: ignore[reportAssignmentType]
    ("bool : Suppress the trailing newline emitted when an effect animation completes. ")

    no_restore_cursor: bool = argutils.ArgSpec(
        name="--no-restore-cursor",
        default=False,
        action="store_true",
        help=("Do not restore cursor visibility after the effect."),
    )  # pyright: ignore[reportAssignmentType]
    ("bool : Do not restore cursor visibility after the effect.")


class Terminal:
    """A class for managing the terminal state and output.

    The terminal tracks input characters, fill characters, added characters, and the
    currently visible rendered state for the active canvas.

    Attributes:
        config (TerminalConfig): Immutable construction-time configuration snapshot. To apply different settings,
            construct a new `Terminal` from a mutable `TerminalConfig`.
        canvas (Canvas): The canvas in the terminal.
        world (World): The 3D world: its text plane covers the canvas, and every character starts on it.
        character_by_input_coord (dict[Coord, EffectCharacter]): Mapping of input-character leading coordinates and
            fill characters keyed by canvas coordinates. Accessing the mapping materializes any deferred fill
            characters. Characters created with `add_character()` are tracked separately.
        terminal_state (list[str]): Internal row-by-row representation of the currently visible terminal output.
        visible_top (int): Top visible row within the terminal after canvas anchoring is applied.
        visible_bottom (int): Bottom visible row within the terminal after canvas anchoring is applied.
        visible_right (int): Rightmost visible column within the terminal after canvas anchoring is applied.
        visible_left (int): Leftmost visible column within the terminal after canvas anchoring is applied.

    Methods:
        get_piped_input:
            Gets the piped input from stdin.
        prep_canvas:
            Prepares the terminal for the effect by adding empty lines and hiding the cursor.
        restore_cursor:
            Restores the cursor visibility.
        get_characters:
            Get a list of all EffectCharacters in the terminal with an optional sort.
        get_characters_grouped:
            Get a list of all EffectCharacters grouped by the specified CharacterGroup grouping.
        get_character_by_input_coord:
            Get an EffectCharacter by its input coordinates.
        prepare_character_graph:
            Materialize fill characters and cardinal neighbor relationships.
        set_character_visibility:
            Set the visibility of a character.
        get_formatted_output_string:
            Get the formatted output string based on the current terminal state.
        print:
            Prints the current terminal state to stdout while preserving the cursor position.
        clock:
            Return the effect clock, in seconds, for time-based effect phases.

    """

    _active_output_terminal: typing.ClassVar[weakref.ReferenceType[Terminal] | None] = None

    def __init__(
        self,
        input_data: str,
        config: TerminalConfig | None = None,
        *,
        terminal_dimensions: tuple[int, int] | None = None,
        frame_clock: bool = False,
    ) -> None:
        """Initialize the Terminal.

        Args:
            input_data (str): The input data to be displayed in the terminal. Empty input produces an empty text
                region on a minimal one-cell canvas.
            config (TerminalConfig, optional): Configuration copied into an immutable construction-time snapshot.
                Later mutations to the caller's configuration do not affect this terminal. Defaults to None.
            terminal_dimensions (tuple[int, int], optional): The `terminal_dimensions` tuple provides the terminal
                width and height instead of probing the current terminal. Used when a fresh effect iterator must match
                an already prepared output canvas.
                Defaults to None.
            frame_clock (bool, optional): Advance `clock()` by one frame period per rendered frame instead of
                reading wall-clock time, and never sleep to enforce the frame rate. Frames are produced as fast as
                possible while time-based effect phases keep their configured duration in frames. Requires a
                configured frame rate greater than `0`. Defaults to False.

        Raises:
            ValueError: If `frame_clock` is enabled while the configured frame rate is `0`.

        """
        self.config = deepcopy(config) if config is not None else TerminalConfig._build_config()
        self.config._freeze()
        self._initialize_frame_timing(frame_clock=frame_clock)
        self._character_ownership_token = weakref.ref(self)
        self._output_prepared = False
        self._next_character_id = 0
        self._input_parser = VirtualScreenParser(tab_width=self.config.tab_width)
        self._preprocessed_character_columns: dict[EffectCharacter, int] = {}
        self._preprocessed_line_widths: list[int] = []
        self._preprocessed_character_lines = self._preprocess_input_data(input_data)
        self._wrapped_character_lines: list[list[EffectCharacter]] | None = None
        self._wrapped_character_line_widths: list[int] | None = None
        self._wrapped_character_columns: dict[EffectCharacter, int] = {}
        self._wrapped_character_lines_width: int | None = None
        self._terminal_width, self._terminal_height = (
            terminal_dimensions if terminal_dimensions is not None else self._get_terminal_dimensions()
        )
        self.canvas = canvas_module.Canvas(*self._get_canvas_dimensions())
        self.world = World(self.canvas)
        self.world._attach_terminal(self)
        if not self.config.ignore_terminal_dimensions:
            self.canvas_column_offset, self.canvas_row_offset = self._calc_canvas_offsets()
        else:
            self.canvas_column_offset = self.canvas_row_offset = 0
            self._terminal_width = self.canvas.right
            self._terminal_height = self.canvas.top
        # the visible_* attributes are used to determine which characters are visible on the terminal
        self.visible_top = min(self.canvas.top + self.canvas_row_offset, self._terminal_height)
        self.visible_bottom = max(self.canvas.bottom + self.canvas_row_offset, 1)
        self.visible_right = min(
            self.canvas.right + self.canvas_column_offset,
            self._terminal_width,
        )
        self.visible_left = max(self.canvas.left + self.canvas_column_offset, 1)
        self._input_characters = [
            character
            for character in self._setup_input_characters()
            if character.input_coord.row <= self.canvas.top and character.input_coord.column <= self.canvas.right
        ]
        self._input_colors_frequency: dict[Color, int] = {}
        for character in self._input_characters:
            for color in (character.animation.input_fg_color, character.animation.input_bg_color):
                if color is not None:
                    self._input_colors_frequency[color] = self._input_colors_frequency.get(color, 0) + 1
        self._added_characters: list[EffectCharacter] = []
        self._character_by_input_coord: dict[Coord, EffectCharacter] = {
            (character.input_coord): character for character in self._input_characters
        }
        self._input_character_continuations: dict[Coord, EffectCharacter] = {
            Coord(character.input_coord.column + offset, character.input_coord.row): character
            for character in self._input_characters
            for offset in range(1, character.animation.current_character_visual.cell_width)
        }
        self._inner_fill_characters: list[EffectCharacter] = []
        self._outer_fill_characters: list[EffectCharacter] = []
        self._fill_characters_materialized = False
        self._character_neighbors_initialized = False
        self._character_by_occupied_coord = dict(self._character_by_input_coord)
        self._character_by_occupied_coord.update(self._input_character_continuations)
        occupied_cell_indexes = [
            (coord.row - self.canvas.bottom) * self.canvas.width + (coord.column - self.canvas.left)
            for coord in self._character_by_occupied_coord
            if self.canvas.coord_is_in_canvas(coord)
        ]
        self._input_occupied_cell_indexes = tuple(sorted(occupied_cell_indexes))
        self._fill_character_id_start = self._next_character_id
        self._next_character_id += self.canvas.width * self.canvas.height - len(self._input_occupied_cell_indexes)
        self._initialize_render_state()
        self._update_terminal_state()

    def _initialize_frame_timing(self, *, frame_clock: bool) -> None:
        """Initialize frame-rate enforcement and the effect clock."""
        if frame_clock and self.config.frame_rate == 0:
            msg = "frame_clock requires a frame rate greater than 0."
            raise ValueError(msg)
        self._frame_rate = self.config.frame_rate
        self._frame_clock = frame_clock
        self._frames_elapsed = 0
        self._last_time_printed = time.monotonic()

    def _initialize_render_state(self) -> None:
        """Initialize visible-character ordering and reusable blank output rows."""
        self._visible_characters: set[EffectCharacter] = set()
        self._visible_characters_by_id: list[EffectCharacter] = []
        self._visible_character_layer_counts: dict[int, int] = {}
        self._visible_characters_by_layer: list[EffectCharacter] = []
        self._visible_character_order_dirty = False
        self._depth_ordered_character_count = 0
        self._visible_wide_character_count = 0
        self._blank_row = " " * self.visible_right
        self._blank_terminal_state = [self._blank_row] * self.visible_top
        self._row_cache: RowCache | None = None

    def enable_row_cache(self) -> None:
        """Opt into caching unchanged output rows for this terminal.

        Effects should enable this only after measuring a benefit for their input
        sizes and update patterns. Visibility, motion, animation, layers and direct
        `CharacterVisual.formatted_symbol` edits invalidate cached output. Wide
        characters use the existing width-aware renderer.
        """
        if self._row_cache is not None:
            return
        self._row_cache = RowCache(self)
        for character in (
            *self._input_characters,
            *self._inner_fill_characters,
            *self._outer_fill_characters,
            *self._added_characters,
        ):
            self._row_cache.track(character)

    def _project_all_characters(self) -> None:
        """Project every character again, after the camera or a body moved."""
        for character in (
            *self._input_characters,
            *self._inner_fill_characters,
            *self._outer_fill_characters,
            *self._added_characters,
        ):
            motion = character.motion
            if motion.current_coord is not motion._cell:
                # The effect assigned a cell since the last tick: take it before projecting, or it would be lost.
                motion._sync()
            motion._resolve()

    def _build_input_character(self, parsed_character: ParsedCharacter, character_id_offset: int) -> EffectCharacter:
        """Allocate one terminal-owned character from parser output."""
        character = EffectCharacter(
            character_id_offset + parsed_character.character_id,
            parsed_character.symbol,
            0,
            0,
        )
        character._terminal_owner_token = self._character_ownership_token
        character.animation.input_fg_color = parsed_character.fg_color
        character.animation.input_bg_color = parsed_character.bg_color
        character.animation.input_bold = parsed_character.bold
        character.animation.no_color = self.config.no_color
        character.animation.use_xterm_colors = self.config.xterm_colors
        character.animation.existing_color_handling = self.config.existing_color_handling
        character.uses_input_preexisting_colors = True
        if character.animation.existing_color_handling == "always":
            character.animation.set_appearance(character.input_symbol)
        return character

    def _preprocess_input_data(self, input_data: str) -> list[list[EffectCharacter]]:
        """Parse input and allocate the retained terminal-owned characters."""
        parsed_input = self._input_parser.parse(input_data)
        character_id_offset = self._next_character_id
        character_lines: list[list[EffectCharacter]] = []
        character_columns: dict[EffectCharacter, int] = {}
        for parsed_row in parsed_input.character_rows:
            character_line: list[EffectCharacter] = []
            for parsed_character in parsed_row:
                character = self._build_input_character(parsed_character, character_id_offset)
                character_line.append(character)
                character_columns[character] = parsed_character.column
            character_lines.append(character_line)

        self._next_character_id += parsed_input.character_id_count
        self._preprocessed_character_columns = character_columns
        self._preprocessed_line_widths = list(parsed_input.line_widths)
        return character_lines

    def _calc_canvas_offsets(self) -> tuple[int, int]:
        """Calculate terminal-space offsets for the anchored canvas.

        The returned column and row offsets position the canvas within the available
        terminal area according to `config.anchor_canvas`. These offsets are later
        applied when determining visible bounds and when rendering character positions.

        Returns:
            tuple[int, int]: Canvas column offset and row offset.

        """
        canvas_column_offset = canvas_row_offset = 0
        if self.config.anchor_canvas in ("s", "n", "c"):
            canvas_column_offset = (self._terminal_width - self.canvas.width) // 2
        elif self.config.anchor_canvas in ("se", "e", "ne"):
            canvas_column_offset = self._terminal_width - self.canvas.width
        if self.config.anchor_canvas in ("w", "e", "c"):
            canvas_row_offset = (self._terminal_height - self.canvas.height) // 2
        elif self.config.anchor_canvas in ("nw", "n", "ne"):
            canvas_row_offset = self._terminal_height - self.canvas.height
        return canvas_column_offset, canvas_row_offset

    def _get_canvas_dimensions(self) -> tuple[int, int]:
        """Determine the canvas dimensions from terminal config and input geometry.

        Explicit positive canvas dimensions take precedence. A configured value of `0`
        uses the terminal dimension, while `-1` derives the dimension from the input
        text, subject to terminal limits unless `ignore_terminal_dimensions` is enabled.
        When `wrap_text` is enabled, canvas height is based on the wrapped input lines
        for the selected width.

        Returns:
            tuple[int, int]: Canvas height and width.

        """
        if self.config.canvas_width > 0:
            canvas_width = self.config.canvas_width
        elif self.config.canvas_width == 0:
            canvas_width = self._terminal_width
        else:
            input_width = max(self._preprocessed_line_widths)
            if self.config.ignore_terminal_dimensions:
                canvas_width = input_width
            else:
                canvas_width = min(self._terminal_width, input_width)
        if self.config.canvas_height > 0:
            canvas_height = self.config.canvas_height
        elif self.config.canvas_height == 0:
            canvas_height = self._terminal_height
        else:
            input_height = len(self._preprocessed_character_lines)
            if self.config.wrap_text:
                input_height = len(self._get_wrapped_character_lines(canvas_width))
            if self.config.ignore_terminal_dimensions:
                canvas_height = input_height
            else:
                canvas_height = min(self._terminal_height, input_height)

        return canvas_height, canvas_width

    def _get_terminal_dimensions(self) -> tuple[int, int]:
        """Get the terminal dimensions.

        Use `shutil.get_terminal_size()` to get terminal width and height. If that call
        raises `OSError`, return the fallback size `(80, 24)`.

        Returns:
            tuple[int, int]: Terminal width and height.

        """
        try:
            terminal_width, terminal_height = shutil.get_terminal_size()
        except OSError:
            # If the terminal size cannot be determined, return default values
            return 80, 24
        return terminal_width, terminal_height

    @staticmethod
    def get_piped_input() -> str:
        """Return piped input from `stdin`.

        If `stdin` is attached to a TTY, return an empty string. Otherwise, read and
        return the full contents of `stdin`.

        Returns:
            str: The piped input, or an empty string when running interactively.

        """
        if sys.stdin.isatty():
            return ""
        return sys.stdin.read()

    def _wrap_lines(
        self,
        lines: list[list[EffectCharacter]],
        width: int,
    ) -> list[list[EffectCharacter]]:
        """Wrap the given lines of text to fit within the width of the canvas.

        Args:
            lines (list[list[EffectCharacter]]): The lines of text to be wrapped.
            width (int): The maximum length of a line.

        Returns:
            list[list[EffectCharacter]]: The wrapped lines of text.

        """
        wrapped_lines = []
        wrapped_line_widths = []
        line_widths = (
            self._preprocessed_line_widths
            if lines is self._preprocessed_character_lines
            else [
                max(
                    (
                        self._preprocessed_character_columns[character]
                        + character.animation.current_character_visual.cell_width
                        for character in line
                    ),
                    default=0,
                )
                for line in lines
            ]
        )
        wrapped_character_columns: dict[EffectCharacter, int] = {}
        for line, line_width in zip(lines, line_widths):
            placements: list[tuple[int, int, EffectCharacter]] = []
            inserted_padding = 0
            for character in line:
                logical_column = self._preprocessed_character_columns[character]
                adjusted_column = logical_column + inserted_padding
                character_width = character.animation.current_character_visual.cell_width
                column_in_chunk = adjusted_column % width
                if character_width <= width and column_in_chunk + character_width > width:
                    inserted_padding += width - column_in_chunk
                    adjusted_column = logical_column + inserted_padding
                    column_in_chunk = 0
                chunk_index = adjusted_column // width
                placements.append((chunk_index, column_in_chunk, character))
                wrapped_character_columns[character] = column_in_chunk
            adjusted_line_width = line_width + inserted_padding
            wrapped_line_count = max((adjusted_line_width + width - 1) // width, 1)
            line_chunks = [[] for _ in range(wrapped_line_count)]
            for chunk_index, _, character in placements:
                line_chunks[chunk_index].append(character)
            wrapped_lines.extend(line_chunks)
            wrapped_line_widths.extend(
                min(width, max(adjusted_line_width - (chunk_index * width), 0))
                for chunk_index in range(wrapped_line_count)
            )
        self._wrapped_character_columns = wrapped_character_columns
        self._wrapped_character_line_widths = wrapped_line_widths
        return wrapped_lines

    def _get_wrapped_character_lines(self, width: int) -> list[list[EffectCharacter]]:
        """Return cached wrapped input rows for the given canvas width."""
        if self._wrapped_character_lines is None or self._wrapped_character_lines_width != width:
            self._wrapped_character_lines = self._wrap_lines(self._preprocessed_character_lines, width)
            self._wrapped_character_lines_width = width
        return self._wrapped_character_lines

    def _setup_input_characters(self) -> list[EffectCharacter]:
        """Set up the input characters discovered during preprocessing.

        Characters are positioned based on row/column coordinates relative to the anchor point in the Canvas.
        Space characters from the input are excluded from the returned input-character
        list and are instead represented by fill characters when the canvas is populated.

        Coordinates are relative to the cursor row position at the time of execution. 1,1 is the bottom left
        corner of the row above the cursor.

        Returns:
            list[EffectCharacter]: list of EffectCharacter objects

        """
        formatted_lines = (
            self._get_wrapped_character_lines(self.canvas.right)
            if self.config.wrap_text
            else self._preprocessed_character_lines
        )
        input_height = len(formatted_lines)
        input_characters: list[EffectCharacter] = []
        input_cells: list[tuple[Coord, int]] = []
        for row, line in enumerate(formatted_lines):
            for character in line:
                logical_column = self._preprocessed_character_columns[character]
                column = self._wrapped_character_columns[character] + 1 if self.config.wrap_text else logical_column + 1
                if character._input_symbol != " " or any(
                    (character.animation.input_fg_color, character.animation.input_bg_color),
                ):
                    input_characters.append(character)
                    input_cells.append(
                        (
                            Coord(column, input_height - row),
                            character.animation.current_character_visual.cell_width,
                        ),
                    )

        layout = self.canvas.layout_text(input_cells, self.config.anchor_text)
        anchored_characters: list[EffectCharacter] = []
        for placement in layout.placements:
            character = input_characters[placement.source_index]
            character._set_input_coord(placement.coord)
            anchored_characters.append(character)
        return anchored_characters

    @property
    def character_by_input_coord(self) -> dict[Coord, EffectCharacter]:
        """Map input and fill coordinates to characters, materializing fills on access."""
        self._ensure_fill_characters()
        return self._character_by_input_coord

    def _get_or_create_fill_character(self, coord: Coord) -> EffectCharacter | None:
        """Return the character occupying `coord`, creating its fill character if needed."""
        if character := self._character_by_occupied_coord.get(coord):
            return character
        if not self.canvas.coord_is_in_canvas(coord):
            return None

        cell_index = (coord.row - self.canvas.bottom) * self.canvas.width + (coord.column - self.canvas.left)
        occupied_before = bisect_left(self._input_occupied_cell_indexes, cell_index)
        character_id = self._fill_character_id_start + cell_index - occupied_before
        fill_char = EffectCharacter(character_id, " ", coord.column, coord.row)
        fill_char._terminal_owner_token = self._character_ownership_token
        fill_char.is_fill_character = True
        fill_char.animation.no_color = self.config.no_color
        fill_char.animation.use_xterm_colors = self.config.xterm_colors
        fill_char.animation.existing_color_handling = self.config.existing_color_handling
        fill_char.uses_input_preexisting_colors = False
        self._character_by_input_coord[coord] = fill_char
        self._character_by_occupied_coord[coord] = fill_char
        if self.canvas.coord_is_in_text(coord):
            self._inner_fill_characters.append(fill_char)
        else:
            self._outer_fill_characters.append(fill_char)
        if self._row_cache is not None:
            self._row_cache.track(fill_char)
        return fill_char

    def _ensure_fill_characters(self) -> None:
        """Materialize all fill characters in stable row-major ID order.

        Fill characters use a space as `input_symbol` and are inserted into
        `character_by_input_coord` for any canvas coordinate not already occupied by an
        input character. They are split into inner and outer fill characters based on
        whether the coordinate falls within the anchored text bounds.
        """
        if self._fill_characters_materialized:
            return
        for row in range(self.canvas.bottom, self.canvas.top + 1):
            for column in range(self.canvas.left, self.canvas.right + 1):
                coord = Coord(column, row)
                self._get_or_create_fill_character(coord)
        self._fill_characters_materialized = True

    def prepare_character_graph(self) -> None:
        """Materialize fill characters and cardinal neighbor relationships on demand."""
        if self._character_neighbors_initialized:
            return
        self._ensure_fill_characters()
        delta_map = {"north": (0, 1), "south": (0, -1), "west": (-1, 0)}
        for coord, char in self._character_by_input_coord.items():
            neighbors: dict[str, EffectCharacter | None] = {}
            for direction, delta in delta_map.items():
                neighbor_coord = Coord(column=coord.column + delta[0], row=coord.row + delta[1])
                neighbors[direction] = self._character_by_occupied_coord.get(neighbor_coord)
            east_coord = Coord(
                column=coord.column + char.animation.current_character_visual.cell_width,
                row=coord.row,
            )
            neighbors["east"] = self._character_by_occupied_coord.get(east_coord)
            char._neighbors = neighbors
        self._character_neighbors_initialized = True

    def add_character(self, symbol: str, coord: Coord) -> EffectCharacter:
        """Add a character to the terminal for printing.

        Used to create characters that are not in the input data.
        Added characters are stored in `_added_characters` and are not inserted into
        `character_by_input_coord`. As a result, they are not returned by
        `get_character_by_input_coord()` and are not included in the neighbor map built
        from `character_by_input_coord`.

        Args:
            symbol (str): symbol to add
            coord (Coord): set character's input coordinates

        Returns:
            EffectCharacter: the character that was added

        Raises:
            InvalidCharacterCoordinateError: If `coord` is not a `Coord` containing integer values.
            InvalidSymbolError: If `symbol` does not contain one independently printable Unicode code point.

        """
        get_symbol_cell_width(symbol)
        if not isinstance(coord, Coord) or type(coord.column) is not int or type(coord.row) is not int:
            raise InvalidCharacterCoordinateError(coord)
        character = EffectCharacter(self._next_character_id, symbol, coord.column, coord.row)
        character._terminal_owner_token = self._character_ownership_token
        character.animation.no_color = self.config.no_color
        character.animation.use_xterm_colors = self.config.xterm_colors
        character.animation.existing_color_handling = self.config.existing_color_handling
        character.uses_input_preexisting_colors = False

        self._added_characters.append(character)
        self._next_character_id += 1
        if self._row_cache is not None:
            self._row_cache.track(character)
        return character

    def get_input_colors(self, sort: ColorSort = ColorSort.MOST_TO_LEAST) -> list[Color]:
        """Get colors used by retained input characters with an optional sort.

        Foreground and background occurrences are counted separately after cursor
        overwrites, text anchoring, and canvas clipping. Equal-frequency colors retain
        their first-appearance order unless random sorting is requested.

        Args:
            sort (ColorSort, optional): Sort order for the colors.
                Defaults to `ColorSort.MOST_TO_LEAST`.

        Raises:
            InvalidColorSortError: If an invalid sort option is provided.

        Returns:
            list[Color]: Colors used by input characters retained within the canvas.

        """
        if sort == ColorSort.MOST_TO_LEAST:
            return sorted(
                self._input_colors_frequency.keys(),
                key=lambda color: self._input_colors_frequency[color],
                reverse=True,
            )
        if sort == ColorSort.RANDOM:
            colors = list(self._input_colors_frequency.keys())
            random.shuffle(colors)
            return colors
        if sort == ColorSort.LEAST_TO_MOST:
            return sorted(
                self._input_colors_frequency.keys(),
                key=lambda color: self._input_colors_frequency[color],
            )
        raise InvalidColorSortError(sort)

    def _get_selected_characters(
        self,
        *,
        input_chars: bool,
        inner_fill_chars: bool,
        outer_fill_chars: bool,
        added_chars: bool,
    ) -> list[EffectCharacter]:
        """Collect requested character categories, materializing fills only when selected."""
        if inner_fill_chars or outer_fill_chars:
            self._ensure_fill_characters()
        all_characters: list[EffectCharacter] = []
        if input_chars:
            all_characters.extend(self._input_characters)
        if inner_fill_chars:
            all_characters.extend(self._inner_fill_characters)
        if outer_fill_chars:
            all_characters.extend(self._outer_fill_characters)
        if added_chars:
            all_characters.extend(self._added_characters)
        return all_characters

    def get_characters(
        self,
        *,
        input_chars: bool = True,
        inner_fill_chars: bool = False,
        outer_fill_chars: bool = False,
        added_chars: bool = False,
        sort: CharacterSort | CharacterOrder | None = None,
        order: CharacterOrder | CharacterGroup | CharacterSort | str | None = None,
        reverse: bool = False,
        canvas_only: bool | None = None,
        serpentine: bool = False,
    ) -> list[EffectCharacter]:
        """Get selected characters in their complete traversal order.

        `order` accepts `CharacterOrder`, CLI names, and legacy group/sort enums.
        Spatial orders are flattened without losing their internal ordering. Individual
        orders use immutable input coordinates; spirals wind inward through the selected
        coordinates' bounding box, skipping empty cells and interleaving multiple arms.
        The default remains top-to-bottom, left-to-right. Legacy `sort` remains supported;
        pass either `sort` or `order`, not both.

        `reverse` reverses the complete traversal after optional serpentine traversal.
        `serpentine` reverses alternate spatial groups before flattening; singleton orders
        are unaffected. Moving characters does not change their order.

        Args:
            input_chars (bool): Include input characters. Defaults to True.
            inner_fill_chars (bool): Include inner fill characters. Defaults to False.
            outer_fill_chars (bool): Include outer fill characters. Defaults to False.
            added_chars (bool): Include added characters. Defaults to False.
            sort (CharacterSort | CharacterOrder | None): Compatibility ordering argument.
            order (CharacterOrder | CharacterGroup | CharacterSort | str | None): Character traversal.
            reverse (bool): Reverse the final traversal. Defaults to False.
            canvas_only (bool | None): Exclude off-canvas input coordinates. Defaults to True
                for spatial orders and False for individual orders, independently of output form.
            serpentine (bool): Reverse alternate spatial groups. Defaults to False.

        Returns:
            list[EffectCharacter]: Selected characters in traversal order.

        Raises:
            InvalidCharacterSortError: If the compatibility `sort` value is invalid.
            InvalidCharacterOrderError: If `order` is invalid.
            ValueError: If both ordering arguments are supplied.
            TypeError: If a traversal flag is not a boolean.

        """
        if order is not None and sort is not None:
            msg = "Pass either order or sort, not both."
            raise ValueError(msg)
        if order is None:
            if sort is not None and not isinstance(sort, (CharacterSort, CharacterOrder)):
                raise InvalidCharacterSortError(sort)
            order = sort if sort is not None else CharacterOrder.TOP_TO_BOTTOM_LEFT_TO_RIGHT
        characters, groups = self._resolve_character_order(
            order,
            input_chars=input_chars,
            inner_fill_chars=inner_fill_chars,
            outer_fill_chars=outer_fill_chars,
            added_chars=added_chars,
            reverse=reverse,
            canvas_only=canvas_only,
            serpentine=serpentine,
        )
        return characters if characters is not None else [character for group in groups or [] for character in group]

    def _sort_characters(
        self,
        all_characters: list[EffectCharacter],
        sort: CharacterOrder,
    ) -> list[EffectCharacter]:
        """Order an inventory using an individual `CharacterOrder` traversal."""
        # default sort TOP_TO_BOTTOM_LEFT_TO_RIGHT
        all_characters.sort(
            key=lambda character: (-character.input_coord.row, character.input_coord.column),
        )

        if sort is CharacterOrder.RANDOM:
            random.shuffle(all_characters)

        elif sort in (
            CharacterOrder.TOP_TO_BOTTOM_LEFT_TO_RIGHT,
            CharacterOrder.BOTTOM_TO_TOP_RIGHT_TO_LEFT,
        ):
            if sort is CharacterOrder.BOTTOM_TO_TOP_RIGHT_TO_LEFT:
                all_characters.reverse()

        elif sort in (
            CharacterOrder.BOTTOM_TO_TOP_LEFT_TO_RIGHT,
            CharacterOrder.TOP_TO_BOTTOM_RIGHT_TO_LEFT,
        ):
            all_characters.sort(
                key=lambda character: (character.input_coord.row, character.input_coord.column),
            )
            if sort is CharacterOrder.TOP_TO_BOTTOM_RIGHT_TO_LEFT:
                all_characters.reverse()

        elif sort in (
            CharacterOrder.OUTSIDE_ROW_TO_MIDDLE,
            CharacterOrder.MIDDLE_ROW_TO_OUTSIDE,
        ):
            characters_by_row: dict[int, list[EffectCharacter]] = {}
            for character in all_characters:
                characters_by_row.setdefault(character.input_coord.row, []).append(character)
            if characters_by_row:
                row_midpoint_sum = min(characters_by_row) + max(characters_by_row)
                distance_sign = -1 if sort is CharacterOrder.OUTSIDE_ROW_TO_MIDDLE else 1
                ordered_rows = sorted(
                    characters_by_row,
                    key=lambda row: (
                        distance_sign * abs((2 * row) - row_midpoint_sum),
                        -row,
                    ),
                )
                all_characters = [character for row in ordered_rows for character in characters_by_row[row]]
        elif isinstance(sort, CharacterOrder) and sort in _SPIRAL_SORT_OPTIONS:
            direction, corners = _SPIRAL_SORT_OPTIONS[sort]
            self._sort_characters_in_spiral(all_characters, direction, corners)
        else:
            raise InvalidCharacterOrderError(sort)

        return all_characters

    @staticmethod
    def _sort_characters_in_spiral(
        characters: list[EffectCharacter],
        direction: int,
        corners: tuple[int, ...],
    ) -> None:
        """Sort occupied coordinates by ring and distance from each starting corner.

        `direction` is 1 for clockwise and -1 for counterclockwise. `corners`
        indexes top-left, top-right, bottom-right, and bottom-left respectively.
        Computing a rank per character avoids walking empty bounding-box cells.
        """
        if not characters:
            return
        left = min(character.input_coord.column for character in characters)
        right = max(character.input_coord.column for character in characters)
        bottom = min(character.input_coord.row for character in characters)
        top = max(character.input_coord.row for character in characters)

        def spiral_key(character: EffectCharacter) -> tuple[int, int, int]:
            column, row = character.input_coord.column, character.input_coord.row
            ring = min(column - left, right - column, row - bottom, top - row)
            width = right - left + 1 - 2 * ring
            height = top - bottom + 1 - 2 * ring
            x, y = column - left - ring, top - row - ring
            if height == 1:
                distances = tuple(x if corner in (0, 3) else width - 1 - x for corner in corners)
            elif width == 1:
                distances = tuple(y if corner in (0, 1) else height - 1 - y for corner in corners)
            else:
                # Clockwise perimeter offsets measured from the top-left corner.
                if y == 0:
                    offset = x
                elif x == width - 1:
                    offset = width - 1 + y
                elif y == height - 1:
                    offset = 2 * (width - 1) + height - 1 - x
                else:
                    offset = 2 * (width - 1) + 2 * (height - 1) - y
                perimeter = 2 * (width + height - 2)
                starts = (0, width - 1, width + height - 2, 2 * width + height - 3)
                distances = tuple(direction * (offset - starts[corner]) % perimeter for corner in corners)
            distance, arm = min((distance, arm) for arm, distance in enumerate(distances))
            return ring, distance, arm

        characters.sort(key=spiral_key)

    def get_characters_grouped_by_grid(
        self,
        grid: geometry.GridLayout,
        *,
        input_chars: bool = True,
        inner_fill_chars: bool = False,
        outer_fill_chars: bool = False,
        added_chars: bool = False,
        reverse: bool = False,
    ) -> list[list[EffectCharacter]]:
        """Group selected characters by their input coordinates within `grid`.

        Return populated cells bottom-to-top, then left-to-right, preserving
        selection order within each cell. Omit characters outside the grid or
        canvas. Visit selected characters once and locate their cells by binary
        search; no empty canvas coordinates are enumerated.

        Args:
            grid (geometry.GridLayout): Cell boundaries, typically from `geometry.find_balanced_grid()`.
            input_chars (bool): Include input characters. Defaults to True.
            inner_fill_chars (bool): Include inner fill characters. Defaults to False.
            outer_fill_chars (bool): Include outer fill characters. Defaults to False.
            added_chars (bool): Include added characters. Defaults to False.
            reverse (bool): Reverse both cells and their internal traversal. Defaults to False.

        Returns:
            list[list[EffectCharacter]]: Nonempty character groups in grid order.

        Raises:
            TypeError: If `reverse` is not a boolean.

        """
        if not isinstance(reverse, bool):
            msg = "reverse must be a boolean."
            raise TypeError(msg)
        groups: dict[tuple[int, int], list[EffectCharacter]] = {}
        columns, rows = grid.column_boundaries, grid.row_boundaries
        for character in self._get_selected_characters(
            input_chars=input_chars,
            inner_fill_chars=inner_fill_chars,
            outer_fill_chars=outer_fill_chars,
            added_chars=added_chars,
        ):
            coord = character.input_coord
            if (
                not self.canvas.coord_is_in_canvas(coord)
                or not columns[0] <= coord.column < columns[-1]
                or not rows[0] <= coord.row < rows[-1]
            ):
                continue
            key = (bisect_right(rows, coord.row) - 1, bisect_right(columns, coord.column) - 1)
            groups.setdefault(key, []).append(character)
        ordered_groups = [groups[key] for key in sorted(groups)]
        if reverse:
            self._reverse_character_groups(ordered_groups)
        return ordered_groups

    def get_characters_grouped(
        self,
        grouping: CharacterGroup | CharacterOrder | None = None,
        *,
        input_chars: bool = True,
        inner_fill_chars: bool = False,
        outer_fill_chars: bool = False,
        added_chars: bool = False,
        order: CharacterOrder | CharacterGroup | CharacterSort | str | None = None,
        reverse: bool = False,
        canvas_only: bool | None = None,
        serpentine: bool = False,
    ) -> list[list[EffectCharacter]]:
        """Get selected characters as ordered spatial or singleton groups.

        Spatial orders retain their existing boundaries and internal order. Individual
        orders, including spirals, produce one character per group. The default remains
        complete rows from top to bottom. Legacy `grouping` remains supported; supply
        either `grouping` or `order`, not both.

        `reverse` reverses both the groups and the characters within each group, after
        optional serpentine traversal. Flattening the result therefore gives the same
        traversal as `get_characters()` with identical options. Circular groups use
        terminal-adjusted radial bands; diamond groups use Manhattan distance.

        Args:
            grouping (CharacterGroup | CharacterOrder | None): Compatibility grouping argument.
            input_chars (bool): Include input characters. Defaults to True.
            inner_fill_chars (bool): Include inner fill characters. Defaults to False.
            outer_fill_chars (bool): Include outer fill characters. Defaults to False.
            added_chars (bool): Include added characters. Defaults to False.
            order (CharacterOrder | CharacterGroup | CharacterSort | str | None): Character traversal.
            reverse (bool): Reverse the final traversal, preserving membership. Defaults to False.
            canvas_only (bool | None): Exclude off-canvas input coordinates. Defaults to True
                for spatial orders and False for individual orders, independently of output form.
            serpentine (bool): Reverse alternate spatial groups. Defaults to False.

        Returns:
            list[list[EffectCharacter]]: Nonempty groups in traversal order.

        Raises:
            InvalidCharacterGroupError: If the compatibility `grouping` value is invalid.
            InvalidCharacterOrderError: If `order` is invalid.
            ValueError: If both ordering arguments are supplied.
            TypeError: If a traversal flag is not a boolean.

        """
        if order is not None and grouping is not None:
            msg = "Pass either order or grouping, not both."
            raise ValueError(msg)
        if order is None:
            if grouping is not None and not isinstance(grouping, (CharacterGroup, CharacterOrder)):
                raise InvalidCharacterGroupError(grouping)
            order = grouping if grouping is not None else CharacterOrder.ROW_TOP_TO_BOTTOM
        characters, groups = self._resolve_character_order(
            order,
            input_chars=input_chars,
            inner_fill_chars=inner_fill_chars,
            outer_fill_chars=outer_fill_chars,
            added_chars=added_chars,
            reverse=reverse,
            canvas_only=canvas_only,
            serpentine=serpentine,
        )
        return groups if groups is not None else [[character] for character in characters or []]

    def _resolve_character_order(
        self,
        order: CharacterOrder | CharacterGroup | CharacterSort | str,
        *,
        input_chars: bool,
        inner_fill_chars: bool,
        outer_fill_chars: bool,
        added_chars: bool,
        reverse: bool,
        canvas_only: bool | None,
        serpentine: bool,
    ) -> tuple[list[EffectCharacter] | None, list[list[EffectCharacter]] | None]:
        """Resolve selection and traversal once, retaining the order's native output form."""
        try:
            normalized = argutils.CharacterOrderArg.type_parser(order)
        except argparse.ArgumentTypeError as error:
            raise InvalidCharacterOrderError(order) from error
        for name, value in (("reverse", reverse), ("serpentine", serpentine), ("canvas_only", canvas_only)):
            if not isinstance(value, bool) and not (name == "canvas_only" and value is None):
                msg = f"{name} must be a boolean" + (" or None." if name == "canvas_only" else ".")
                raise TypeError(msg)
        characters = self._get_selected_characters(
            input_chars=input_chars,
            inner_fill_chars=inner_fill_chars,
            outer_fill_chars=outer_fill_chars,
            added_chars=added_chars,
        )
        clip_to_canvas = normalized.is_grouped if canvas_only is None else canvas_only
        if clip_to_canvas:
            characters = [
                character for character in characters if self.canvas.coord_is_in_canvas(character.input_coord)
            ]
        if normalized.is_grouped:
            groups = self._group_characters(characters, normalized)
            if serpentine:
                for group in groups[1::2]:
                    group.reverse()
            if reverse:
                self._reverse_character_groups(groups)
            return None, groups
        characters = self._sort_characters(characters, normalized)
        if reverse:
            characters.reverse()
        return characters, None

    @staticmethod
    def _reverse_character_groups(groups: list[list[EffectCharacter]]) -> None:
        """Reverse a complete traversal without changing its group membership."""
        groups.reverse()
        for group in groups:
            group.reverse()

    def _group_characters(
        self,
        all_characters: list[EffectCharacter],
        grouping: CharacterOrder,
    ) -> list[list[EffectCharacter]]:
        """Partition an inventory into ordered spatial groups."""
        all_characters.sort(
            key=lambda character: (character.input_coord.row, character.input_coord.column),
        )

        if grouping in (
            CharacterOrder.COLUMN_LEFT_TO_RIGHT,
            CharacterOrder.COLUMN_RIGHT_TO_LEFT,
        ):
            characters_by_column: dict[int, list[EffectCharacter]] = {}
            for character in all_characters:
                column_index = character.input_coord.column
                characters_by_column.setdefault(column_index, []).append(character)
            ordered_columns = sorted(
                characters_by_column,
                reverse=grouping is CharacterOrder.COLUMN_RIGHT_TO_LEFT,
            )
            return [characters_by_column[column_index] for column_index in ordered_columns]

        if grouping in (
            CharacterOrder.ROW_BOTTOM_TO_TOP,
            CharacterOrder.ROW_TOP_TO_BOTTOM,
        ):
            characters_by_row: dict[int, list[EffectCharacter]] = {}
            for character in all_characters:
                row_index = character.input_coord.row
                characters_by_row.setdefault(row_index, []).append(character)
            ordered_rows = sorted(
                characters_by_row,
                reverse=grouping is CharacterOrder.ROW_TOP_TO_BOTTOM,
            )
            return [characters_by_row[row_index] for row_index in ordered_rows]
        if grouping in (
            CharacterOrder.DIAGONAL_BOTTOM_LEFT_TO_TOP_RIGHT,
            CharacterOrder.DIAGONAL_TOP_RIGHT_TO_BOTTOM_LEFT,
        ):
            characters_by_diagonal: dict[int, list[EffectCharacter]] = {}
            for character in all_characters:
                diagonal_index = character.input_coord.row + character.input_coord.column
                characters_by_diagonal.setdefault(diagonal_index, []).append(character)
            ordered_diagonals = sorted(
                characters_by_diagonal,
                reverse=grouping is CharacterOrder.DIAGONAL_TOP_RIGHT_TO_BOTTOM_LEFT,
            )
            return [characters_by_diagonal[diagonal_index] for diagonal_index in ordered_diagonals]
        if grouping in (
            CharacterOrder.DIAGONAL_TOP_LEFT_TO_BOTTOM_RIGHT,
            CharacterOrder.DIAGONAL_BOTTOM_RIGHT_TO_TOP_LEFT,
        ):
            characters_by_diagonal = {}
            for character in all_characters:
                diagonal_index = character.input_coord.column - character.input_coord.row
                characters_by_diagonal.setdefault(diagonal_index, []).append(character)
            ordered_diagonals = sorted(
                characters_by_diagonal,
                reverse=grouping is CharacterOrder.DIAGONAL_BOTTOM_RIGHT_TO_TOP_LEFT,
            )
            return [characters_by_diagonal[diagonal_index] for diagonal_index in ordered_diagonals]
        if grouping in (
            CharacterOrder.DIAMONDS_CENTER_TO_OUTSIDE,
            CharacterOrder.DIAMONDS_OUTSIDE_TO_CENTER,
        ):
            distance_map: dict[int, list[EffectCharacter]] = {}
            for character in all_characters:
                distance = abs(character.input_coord.column - self.canvas.text_center.column) + abs(
                    character.input_coord.row - self.canvas.text_center.row,
                )
                if distance not in distance_map:
                    distance_map[distance] = []
                distance_map[distance].append(character)
            ordered_distances = sorted(
                distance_map.keys(),
                reverse=grouping is CharacterOrder.DIAMONDS_OUTSIDE_TO_CENTER,
            )
            return [distance_map[distance] for distance in ordered_distances]

        if grouping in (
            CharacterOrder.CIRCLE_CENTER_TO_OUTSIDE,
            CharacterOrder.CIRCLE_OUTSIDE_TO_CENTER,
        ):
            center_column = (self.canvas.text_left + self.canvas.text_right) / 2
            center_row = (self.canvas.text_bottom + self.canvas.text_top) / 2
            rings: dict[int, list[EffectCharacter]] = {}
            for character in all_characters:
                radius = math.ceil(
                    math.hypot(
                        character.input_coord.column - center_column,
                        (character.input_coord.row - center_row) * geometry.TERMINAL_ROW_SCALE,
                    ),
                )
                rings.setdefault(radius, []).append(character)
            return [
                rings[radius] for radius in sorted(rings, reverse=grouping is CharacterOrder.CIRCLE_OUTSIDE_TO_CENTER)
            ]

        raise InvalidCharacterOrderError(grouping)

    def get_character_by_input_coord(self, coord: Coord) -> EffectCharacter | None:
        """Get an EffectCharacter by its input coordinates.

        Lookup includes input and fill characters but not characters added through
        `add_character()`. A coordinate occupied by the continuation cell of a wide
        input symbol returns the owning `EffectCharacter`. Looking up an otherwise
        empty canvas coordinate materializes only that coordinate's fill character.

        Args:
            coord (Coord): input coordinates of the character

        Returns:
            EffectCharacter | None: the character at the specified coordinates, or None if no character is found

        """
        return self._get_or_create_fill_character(coord)

    def set_character_visibility(self, character: EffectCharacter, is_visible: bool) -> None:  # noqa: FBT001
        """Set whether a character participates in terminal rendering.

        This updates both the character's internal visibility flag and the terminal's
        tracked set of currently visible characters. A character the world hides, because
        it is behind the camera or faces away on a body that hides such characters, stays
        hidden until the view sees it again.

        Args:
            character (EffectCharacter): Character whose visibility should be updated.
            is_visible (bool): Whether the character should be visible.

        Raises:
            InvalidCharacterError: If `character` is not owned by this terminal.
            InvalidCharacterVisibilityError: If `is_visible` is not a boolean.

        """
        if (
            not isinstance(character, EffectCharacter)
            or character._terminal_owner_token is not self._character_ownership_token
        ):
            raise InvalidCharacterError(character)
        if not isinstance(is_visible, bool):
            raise InvalidCharacterVisibilityError(is_visible)
        motion = character.motion
        if motion._view_hidden:
            # Behind the camera or facing away: a request to show waits until the view sees it again.
            motion._show_when_seen = is_visible
            if is_visible:
                return
        visibility_changed = character._is_visible != is_visible
        character._is_visible = is_visible
        if is_visible:
            if character not in self._visible_characters:
                self._visible_characters.add(character)
                insertion_index = _bisect_visible_characters(
                    self._visible_characters_by_id,
                    character._character_id,
                    key=_CHARACTER_ID_KEY,
                )
                self._visible_characters_by_id.insert(insertion_index, character)
                self._visible_character_layer_counts[character.layer] = (
                    self._visible_character_layer_counts.get(character.layer, 0) + 1
                )
                if character.animation.current_character_visual.cell_width > 1:
                    self._visible_wide_character_count += 1
                self._visible_character_order_dirty = True
        elif character in self._visible_characters:
            self._visible_characters.remove(character)
            character_index = _bisect_visible_characters(
                self._visible_characters_by_id,
                character._character_id,
                key=_CHARACTER_ID_KEY,
            )
            self._visible_characters_by_id.pop(character_index)
            layer_count = self._visible_character_layer_counts[character.layer] - 1
            if layer_count:
                self._visible_character_layer_counts[character.layer] = layer_count
            else:
                del self._visible_character_layer_counts[character.layer]
            if character.animation.current_character_visual.cell_width > 1:
                self._visible_wide_character_count -= 1
            self._visible_character_order_dirty = True

        if visibility_changed and self._row_cache is not None:
            self._row_cache.visibility_changed(character, visible=is_visible)

    def _notify_character_layer_changed(self, character: EffectCharacter, previous_layer: int) -> None:
        """Update visible-layer counts after an owned character's layer changes."""
        if character not in self._visible_characters:
            return
        previous_layer_count = self._visible_character_layer_counts[previous_layer] - 1
        if previous_layer_count:
            self._visible_character_layer_counts[previous_layer] = previous_layer_count
        else:
            del self._visible_character_layer_counts[previous_layer]
        self._visible_character_layer_counts[character.layer] = (
            self._visible_character_layer_counts.get(character.layer, 0) + 1
        )
        self._visible_character_order_dirty = True
        if self._row_cache is not None:
            self._row_cache.layer_changed(character)

    def _notify_character_depth_order_changed(self, character: EffectCharacter, previous_order: float) -> None:
        """Track characters ordered by depth within their layer and reorder painting if one is visible."""
        if not previous_order:
            self._depth_ordered_character_count += 1
        if not character._depth_order:
            self._depth_ordered_character_count -= 1
        if character not in self._visible_characters:
            return
        self._visible_character_order_dirty = True
        if self._row_cache is not None:
            self._row_cache.layer_changed(character)

    def _notify_character_cell_width_changed(self, character: EffectCharacter, previous_width: int) -> None:
        """Update the visible wide-character count after a visual-width transition."""
        if character not in self._visible_characters:
            return
        if previous_width > 1:
            self._visible_wide_character_count -= 1
        else:
            self._visible_wide_character_count += 1

    def _get_visible_characters_in_painter_order(self) -> list[EffectCharacter]:
        """Return visible characters ordered by layer, then depth order within the layer, then character ID."""
        if len(self._visible_character_layer_counts) <= 1 and not self._depth_ordered_character_count:
            return self._visible_characters_by_id
        if self._visible_character_order_dirty:
            self._visible_characters_by_layer = sorted(self._visible_characters_by_id, key=_LAYER_KEY)
            self._visible_character_order_dirty = False
        return self._visible_characters_by_layer

    def get_formatted_output_string(self) -> str:
        """Get the formatted output string based on the current terminal state.

        This method refreshes the internal terminal representation and returns it as a
        newline-delimited string ordered for terminal printing from top row to bottom row.

        Returns:
            str: The formatted output string.

        """
        self._update_terminal_state()
        return "\n".join(self.terminal_state[::-1])

    def _render_single_cell_characters(self, visible_characters: list[EffectCharacter]) -> list[str]:
        """Render single-cell characters through dense or sparse row buffers."""
        dense_threshold = max(
            1,
            min(
                (self.visible_top * self.visible_right) // 4,
                max(16, self.visible_top * 2),
            ),
        )
        if len(visible_characters) >= dense_threshold:
            dense_rows = [list(self._blank_row) for _ in range(self.visible_top)]
            for character in visible_characters:
                row = character.motion.current_coord.row + self.canvas_row_offset
                column = character.motion.current_coord.column + self.canvas_column_offset
                if self.visible_bottom <= row <= self.visible_top and self.visible_left <= column <= self.visible_right:
                    dense_rows[row - 1][column - 1] = character.animation.current_character_visual._formatted_symbol
            return ["".join(row) for row in dense_rows]

        rows: list[list[str] | None] = [None] * self.visible_top
        for character in visible_characters:
            row = character.motion.current_coord.row + self.canvas_row_offset
            column = character.motion.current_coord.column + self.canvas_column_offset
            if self.visible_bottom <= row <= self.visible_top and self.visible_left <= column <= self.visible_right:
                row_index = row - 1
                row_cells = rows[row_index]
                if row_cells is None:
                    row_cells = list(self._blank_row)
                    rows[row_index] = row_cells
                row_cells[column - 1] = character.animation.current_character_visual._formatted_symbol
        return [self._blank_row if row is None else "".join(row) for row in rows]

    def _render_width_aware_characters(self, visible_characters: list[EffectCharacter]) -> list[str]:
        """Render characters while resolving overlapping double-cell footprints."""
        rows: list[list[str] | None] = [None] * self.visible_top
        owners: list[list[EffectCharacter | None] | None] = [None] * self.visible_top
        footprints: dict[EffectCharacter, tuple[int, int, int]] = {}
        for character in visible_characters:
            row = character.motion.current_coord.row + self.canvas_row_offset
            column = character.motion.current_coord.column + self.canvas_column_offset
            visual = character.animation.current_character_visual
            right_column = column + visual.cell_width - 1
            if (
                self.visible_bottom <= row <= self.visible_top
                and self.visible_left <= column
                and right_column <= self.visible_right
            ):
                row_index = row - 1
                column_index = column - 1
                row_cells = rows[row_index]
                if row_cells is None:
                    row_cells = list(self._blank_row)
                    rows[row_index] = row_cells
                existing_row_owners = owners[row_index]
                row_owners: list[EffectCharacter | None]
                if existing_row_owners is None:
                    row_owners = [None] * self.visible_right
                    owners[row_index] = row_owners
                else:
                    row_owners = existing_row_owners
                overwritten_characters = {owner for owner in row_owners[column_index:right_column] if owner is not None}
                for overwritten_character in overwritten_characters:
                    old_row, old_column, old_width = footprints.pop(overwritten_character)
                    old_row_owners = owners[old_row]
                    old_row_cells = rows[old_row]
                    if old_row_owners is None or old_row_cells is None:
                        msg = "Rendered wide-character footprint has no backing row."
                        raise RuntimeError(msg)
                    for old_column_index in range(old_column, old_column + old_width):
                        if old_row_owners[old_column_index] is overwritten_character:
                            old_row_owners[old_column_index] = None
                            old_row_cells[old_column_index] = " "
                row_cells[column_index] = visual._formatted_symbol
                row_owners[column_index] = character
                for continuation_column in range(column_index + 1, column_index + visual.cell_width):
                    row_cells[continuation_column] = ""
                    row_owners[continuation_column] = character
                footprints[character] = (row_index, column_index, visual.cell_width)
        return [self._blank_row if row is None else "".join(row) for row in rows]

    def _update_terminal_state(self) -> None:
        """Rebuild the internal representation of the visible terminal state.

        Visible characters are rendered using current motion coordinates adjusted by
        canvas offsets. Lower layers are painted first; characters on the same layer
        are painted in ascending character-ID order, so the highest ID wins a
        collision. Characters outside the visible bounds are skipped.
        """
        visible_characters = self._get_visible_characters_in_painter_order()
        if self._row_cache is not None:
            cached_rows = self._row_cache.render(self)
            if cached_rows is not None:
                self.terminal_state = cached_rows
                return
        if self._visible_wide_character_count:
            self.terminal_state = self._render_width_aware_characters(visible_characters)
        else:
            self.terminal_state = self._render_single_cell_characters(visible_characters)

    def prep_canvas(self) -> None:
        """Prepare the terminal for the effect.

        Hide the cursor, position the canvas, and write blank canvas rows.

        If `config.reuse_canvas` is `True`, the cursor is first moved to the previously
        saved canvas position before the blank rows are written. This is intended to let
        the current effect reuse the prior canvas area rather than advancing output
        further down the terminal.

        Note: Use of `config.reuse_canvas` is less predictable if other canvas dimension
        options differ between the last run and the current run.

        Repeated calls during the same output lifecycle are no-ops. A second terminal
        cannot prepare output until the active terminal has restored the cursor because
        DEC save/restore position state is terminal-global and does not support nesting.

        Raises:
            TerminalOutputActiveError: If another terminal currently owns stdout cursor state.

        """
        if self._output_prepared:
            return
        active_terminal = self._active_output_terminal() if self._active_output_terminal is not None else None
        if active_terminal is not None:
            raise TerminalOutputActiveError
        self._output_prepared = True
        type(self)._active_output_terminal = weakref.ref(self)
        try:
            sys.stdout.write(ansitools.hide_cursor())
            if self.config.reuse_canvas:
                self.move_cursor_to_top()
            for _ in range(self.visible_top):
                sys.stdout.write((" " * self.visible_right) + "\n")
            sys.stdout.write(ansitools.dec_save_cursor_position())
        except BaseException:
            self._release_output_ownership()
            with suppress(Exception):
                if not self.config.no_restore_cursor:
                    sys.stdout.write(ansitools.show_cursor())
                sys.stdout.flush()
            raise

    def _release_output_ownership(self) -> None:
        """Mark output inactive and release this terminal's global cursor ownership."""
        self._output_prepared = False
        active_terminal = self._active_output_terminal() if self._active_output_terminal is not None else None
        if active_terminal is self:
            type(self)._active_output_terminal = None

    def restore_cursor(self, end_symbol: str = "\n") -> None:
        """Restore cursor visibility when enabled and write the configured end symbol.

        If the `--no-eol` option is enabled, no end symbol is printed. If the
        `--no-restore-cursor` option is enabled, cursor visibility is not restored.

        Args:
            end_symbol (str, optional): Symbol to print after the effect completes.
                Defaults to a newline.

        """
        if not self._output_prepared:
            return
        self._release_output_ownership()
        if self.config.no_eol:
            end_symbol = ""
        if not self.config.no_restore_cursor:
            sys.stdout.write(ansitools.show_cursor())
        sys.stdout.write(end_symbol)
        sys.stdout.flush()

    def print(self, output_string: str) -> None:
        """Print the provided output string at the top of the current canvas.

        The cursor is restored to the saved canvas position, moved to the top of the
        canvas, and the output string is written to stdout.

        Args:
            output_string (str): The string to print.

        Raises:
            TerminalOutputNotPreparedError: If `prep_canvas()` has not started an output lifecycle.

        """
        if not self._output_prepared:
            operation = "print"
            raise TerminalOutputNotPreparedError(operation)
        self.move_cursor_to_top()
        sys.stdout.write(output_string)
        sys.stdout.flush()

    def clock(self) -> float:
        """Return the effect clock, in seconds.

        Effects should measure time-based phases, such as a duration in seconds, with this clock rather than
        reading wall-clock time directly. During live output the clock is `time.monotonic()`. When the terminal
        was built with `frame_clock` enabled, the clock starts at `0.0` and advances by `1 / frame_rate` for each
        frame, so phase durations stay the same when frames are rendered ahead of time.

        Returns:
            float: Current clock value in seconds. Only differences between values are meaningful.

        """
        if self._frame_clock:
            return self._frames_elapsed / self._frame_rate
        return time.monotonic()

    def enforce_framerate(self) -> None:
        """Enforce the frame rate set in the terminal config.

        Frame rate is enforced by sleeping if the time since the last frame is shorter than the expected frame delay.
        If the configured frame rate is `0`, frame rate limiting is disabled and this method returns immediately.
        When the terminal uses a frame clock, this method advances `clock()` by one frame without sleeping.
        """
        if self._frame_rate == 0:
            return
        if self._frame_clock:
            self._frames_elapsed += 1
            return
        frame_delay = 1 / self._frame_rate
        if (time_since_last_print := time.monotonic() - self._last_time_printed) < frame_delay:
            time.sleep(frame_delay - time_since_last_print)
        self._last_time_printed = time.monotonic()

    def move_cursor_to_top(self) -> None:
        """Restore the saved canvas cursor position and move to the top of the canvas.

        The saved cursor position is restored, immediately saved again as the current
        canvas origin, and then the cursor is moved up by the visible canvas height.

        Raises:
            TerminalOutputNotPreparedError: If `prep_canvas()` has not started an output lifecycle.

        """
        if not self._output_prepared:
            operation = "move_cursor_to_top"
            raise TerminalOutputNotPreparedError(operation)
        sys.stdout.write(ansitools.dec_restore_cursor_position())
        sys.stdout.write(ansitools.dec_save_cursor_position())
        sys.stdout.write(ansitools.move_cursor_up(self.visible_top))
