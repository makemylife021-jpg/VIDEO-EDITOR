"""Classes used to manage the state of a single character from the input data.

Classes:
    EffectCharacter: A class representing a single character from the input data.
    EventHandler: A class used to register and handle events related to a character.
"""

from __future__ import annotations

import typing
from dataclasses import dataclass
from enum import Enum, auto
from types import MappingProxyType

from terminaltexteffects.engine import animation, motion, view, world
from terminaltexteffects.utils.exceptions import (
    DuplicateEventRegistrationError,
    EventRegistrationCallerError,
    EventRegistrationNodeError,
    EventRegistrationTargetError,
    PathNotFoundError,
    SceneNotFoundError,
)
from terminaltexteffects.utils.geometry import Coord
from terminaltexteffects.utils.geometry3d import Vec3

if typing.TYPE_CHECKING:
    from terminaltexteffects.utils import geometry3d as g3


class _CharacterOwner(typing.Protocol):
    """Terminal capability used to lazily prepare character neighbors."""

    world: world.World

    def prepare_character_graph(self) -> None:
        """Materialize fill characters and neighbor relationships."""

    def _notify_character_layer_changed(self, character: EffectCharacter, previous_layer: int) -> None:
        """Notify the terminal that an owned character's layer changed."""

    def _notify_character_depth_order_changed(self, character: EffectCharacter, previous_order: float) -> None:
        """Notify the terminal that an owned character's order within its layer changed."""

    def _notify_character_cell_width_changed(self, character: EffectCharacter, previous_width: int) -> None:
        """Notify the terminal that an owned character's current visual width changed."""

    def set_character_visibility(self, character: EffectCharacter, is_visible: bool) -> None:  # noqa: FBT001
        """Show or hide an owned character."""


class EventHandler:
    """Register and handle events related to a character or a body.

    Events related to node state changes (e.g. scene complete) can be registered with the EventHandler.
    When an event is triggered, the EventHandler will take the specified action (e.g. activate a Path).
    Every character and every body has one.

    A body's handler takes the node actions (`ACTIVATE_PATH`, `DEACTIVATE_PATH`, `SET_COORDINATE`, `ATTACH`,
    `DETACH`, `CALLBACK`) and the path and attach events. Scenes, layers and appearance belong to characters, so
    registering those on a body raises `EventRegistrationNodeError`.

    Attributes:
        character (EffectCharacter | Body): The node whose events are handled by this EventHandler.
        registered_events: Registered event/action mappings keyed by the triggering event and caller object.

    Note:
        SEGMENT_ENTERED/EXITED events will trigger the first time the character enters or exits a segment.
        If looping, each loop will trigger the event, but not backwards motion as is possible with
        the bounce easing functions.

    """

    def __init__(self, character: EffectCharacter | world.Body) -> None:
        """Initialize the instance with the node it handles events for.

        Args:
            character (EffectCharacter | world.Body): The character or body for which the EventHandler is handling
                events.

        """
        # Typed as a character: a body's handler only takes the node actions, which bodies have too.
        self.character: EffectCharacter = typing.cast("EffectCharacter", character)
        self.registered_events: dict[
            tuple[EventHandler.Event, animation.Scene | motion.Waypoint | motion.Path | world.Body],
            list[
                tuple[
                    EventHandler.Action,
                    animation.Scene
                    | motion.Waypoint
                    | motion.Path
                    | world.Body
                    | int
                    | Coord
                    | Vec3
                    | EventHandler.Callback
                    | str
                    | None,
                ]
            ],
        ] = {}

    class Event(Enum):
        """An Event that can be registered with the EventHandler.

        Register Events with the EventHandler using the register_event method of the EventHandler class.

        Attributes:
            SEGMENT_ENTERED (Event): A path segment has been entered.
            SEGMENT_EXITED (Event): A path segment has been exited.
            PATH_ACTIVATED (Event): A path has been activated.
            PATH_COMPLETE (Event): A path has been completed.
            PATH_HOLDING (Event): A path has entered the holding state.
            SCENE_ACTIVATED (Event): An animation scene has been activated.
            SCENE_COMPLETE (Event): An animation scene has completed.
            ATTACHED (Event): The node was attached to a body (not the world root). The caller is the new parent.
            DETACHED (Event): The node left a body (not the world root), by `attach` to another or `detach`. The
                caller is the old parent.

        """

        SEGMENT_ENTERED = auto()
        SEGMENT_EXITED = auto()
        PATH_ACTIVATED = auto()
        PATH_COMPLETE = auto()
        PATH_HOLDING = auto()
        SCENE_ACTIVATED = auto()
        SCENE_COMPLETE = auto()
        ATTACHED = auto()
        DETACHED = auto()

    class Action(Enum):
        """Actions that can be taken when an event is triggered.

        An Action is taken when an Event is triggered. Register Actions with the EventHandler using the
        register_event method of the EventHandler class.

        Attributes:
            ACTIVATE_PATH (Action): Activates a path. The action target is the path itself or its ID.
            ACTIVATE_SCENE (Action): Activates an animation scene. The action target is the scene itself or its ID.
            DEACTIVATE_PATH (Action): Deactivates a path. The action target is the path itself, its ID,
                or None to deactivate the currently active path.
            DEACTIVATE_SCENE (Action): Deactivates an animation scene. The action target is the scene itself,
                its ID, or None to deactivate the currently active scene.
            RESET_APPEARANCE (Action): Resets the appearance of the character to the input symbol and color.
            SET_LAYER (Action): Sets the layer of the character. The action target is the layer number.
            SET_COORDINATE (Action): Moves the node, now. The action target is a `Coord`, a cell in the parent's
                frame that keeps the node's height, or a `Vec3`, a whole position in the parent's frame.
            CALLBACK (Action): Calls a callback function. The action target is an EventHandler.Callback object.
            ATTACH (Action): Attaches the node to a body, keeping its place in the world. The action target is the
                body.
            DETACH (Action): Detaches the node into the world, keeping its place. Takes no target.

        """

        ACTIVATE_PATH = auto()
        ACTIVATE_SCENE = auto()
        DEACTIVATE_PATH = auto()
        DEACTIVATE_SCENE = auto()
        RESET_APPEARANCE = auto()
        SET_LAYER = auto()
        SET_COORDINATE = auto()
        CALLBACK = auto()
        ATTACH = auto()
        DETACH = auto()

    @dataclass(init=False)
    class Callback:
        """A callback action target that can be taken when an event is triggered.

        Register callback actions with the EventHandler using the register_event method of the EventHandler class.

        The callback function will be called with the character and any additional arguments when the event
        is triggered. The character will be the first argument passed to the callback function followed by any
        additional arguments in the order they were passed to the Callback object.

        Example:
            Create a callback to set the character's visibility to False. The following code would be
            used within an effect where 'self' is the EffectIterator instance:

                cb = EventHandler.Callback(lambda c: self.terminal.set_character_visibility(c, is_visible=False))

        """

        callback: typing.Callable
        args: tuple[typing.Any, ...]

        def __init__(self, callback: typing.Callable, *args: typing.Any) -> None:
            """Initialize the instance with the callback function and arguments.

            Args:
                callback (typing.Callable): The callback function to call.
                args (tuple[typing.Any,...]): A tuple of arguments to pass to the callback function. The first argument
                    will be the character, followed by any additional arguments.

            """
            self.callback = callback
            self.args = args

    @typing.overload
    def register_event(
        self,
        event: Event,
        caller: animation.Scene | motion.Waypoint | motion.Path | world.Body | str,
        action: typing.Literal[Action.ACTIVATE_SCENE],
        target: animation.Scene | str,
    ) -> None: ...
    @typing.overload
    def register_event(
        self,
        event: Event,
        caller: animation.Scene | motion.Waypoint | motion.Path | world.Body | str,
        action: typing.Literal[Action.DEACTIVATE_SCENE],
        target: animation.Scene | str | None = ...,
    ) -> None: ...
    @typing.overload
    def register_event(
        self,
        event: Event,
        caller: animation.Scene | motion.Waypoint | motion.Path | world.Body | str,
        action: typing.Literal[Action.ACTIVATE_PATH],
        target: motion.Path | str,
    ) -> None: ...
    @typing.overload
    def register_event(
        self,
        event: Event,
        caller: animation.Scene | motion.Waypoint | motion.Path | world.Body | str,
        action: typing.Literal[Action.DEACTIVATE_PATH],
        target: motion.Path | str | None = ...,
    ) -> None: ...
    @typing.overload
    def register_event(
        self,
        event: Event,
        caller: animation.Scene | motion.Waypoint | motion.Path | world.Body | str,
        action: typing.Literal[Action.SET_COORDINATE],
        target: Coord | Vec3,
    ) -> None: ...
    @typing.overload
    def register_event(
        self,
        event: Event,
        caller: animation.Scene | motion.Waypoint | motion.Path | world.Body | str,
        action: typing.Literal[Action.SET_LAYER],
        target: int,
    ) -> None: ...
    @typing.overload
    def register_event(
        self,
        event: Event,
        caller: animation.Scene | motion.Waypoint | motion.Path | world.Body | str,
        action: typing.Literal[Action.CALLBACK],
        target: Callback,
    ) -> None: ...
    @typing.overload
    def register_event(
        self,
        event: Event,
        caller: animation.Scene | motion.Waypoint | motion.Path | world.Body | str,
        action: typing.Literal[Action.RESET_APPEARANCE],
        target: None = None,
    ) -> None: ...
    @typing.overload
    def register_event(
        self,
        event: Event,
        caller: animation.Scene | motion.Waypoint | motion.Path | world.Body | str,
        action: typing.Literal[Action.ATTACH],
        target: world.Body,
    ) -> None: ...
    @typing.overload
    def register_event(
        self,
        event: Event,
        caller: animation.Scene | motion.Waypoint | motion.Path | world.Body | str,
        action: typing.Literal[Action.DETACH],
        target: None = None,
    ) -> None: ...
    def register_event(
        self,
        event: Event,
        caller: animation.Scene | motion.Waypoint | motion.Path | world.Body | str,
        action: Action,
        target: animation.Scene | motion.Path | world.Body | int | Coord | Vec3 | Callback | str | None = None,
    ) -> None:
        """Register an event to be handled by the EventHandler.

        Note: Action.RESET_APPEARANCE does not accept a target.
        For `PATH_ACTIVATED`, `PATH_COMPLETE`, `SCENE_ACTIVATED`, and `SCENE_COMPLETE`,
        `caller` may be the triggering object itself or its registered ID string.
        `PATH_HOLDING` and segment events require their corresponding object instances.
        For `ACTIVATE_PATH`, `DEACTIVATE_PATH`, `ACTIVATE_SCENE`, and `DEACTIVATE_SCENE`,
        string targets are resolved from registered path or scene IDs. `DEACTIVATE_PATH`,
        `DEACTIVATE_SCENE`, and `RESET_APPEARANCE` may use `None` where supported by the action.
        `ATTACHED` and `DETACHED` take the parent body as the caller.

        Args:
            event (Event): The event to register.
            caller (animation.Scene | motion.Waypoint | motion.Path | world.Body | str): The object
                that triggers the event.
            action (Action): The action to take when the event is triggered.
            target (animation.Scene | motion.Path | world.Body | int | Coord | Vec3 | Callback | str | None):
                The target of the action.

        Raises:
            EventRegistrationCallerError: If the caller object is not the required type for the
                specified event.
            EventRegistrationTargetError: If the target is not the correct type for the action or if
                ``Action.RESET_APPEARANCE`` is provided with a target.
            DuplicateEventRegistrationError: If the exact same event-caller-action-target combination
                has already been registered.

        Example:
            Register an event to activate a scene when a Path is complete:
            `event_handler.register_event(EventHandler.Event.PATH_COMPLETE, some_path,
                EventHandler.Action.ACTIVATE_SCENE, some_scene)`

        """
        if isinstance(self.character, world.Body) and (event in _CHARACTER_EVENTS or action not in _NODE_ACTIONS):
            raise EventRegistrationNodeError(event, action)

        # find caller Path when provided path_id
        if event in (EventHandler.Event.PATH_ACTIVATED, EventHandler.Event.PATH_COMPLETE) and isinstance(caller, str):
            if (path_query_result := self.character.motion.query_path(caller)) is None:
                raise PathNotFoundError(path_id=caller)
            caller = path_query_result

        # find caller Scene when provided scene_id
        elif event in (EventHandler.Event.SCENE_ACTIVATED, EventHandler.Event.SCENE_COMPLETE) and isinstance(
            caller,
            str,
        ):
            if (scene_query_result := self.character.animation.query_scene(caller)) is None:
                raise SceneNotFoundError(scene_id=caller)
            caller = scene_query_result

        if _EVENT_CALLER_TYPES[event] != caller.__class__:
            raise EventRegistrationCallerError(event, caller, _EVENT_CALLER_TYPES[event])

        # find target Path when provided path_id
        if action in (EventHandler.Action.ACTIVATE_PATH, EventHandler.Action.DEACTIVATE_PATH) and isinstance(
            target,
            str,
        ):
            if (path_query_result := self.character.motion.query_path(target)) is None:
                raise PathNotFoundError(path_id=target)
            target = path_query_result

        # find target Scene when provided scene_id
        elif action in (EventHandler.Action.ACTIVATE_SCENE, EventHandler.Action.DEACTIVATE_SCENE) and isinstance(
            target,
            str,
        ):
            if (scene_query_result := self.character.animation.query_scene(target)) is None:
                raise SceneNotFoundError(scene_id=target)
            target = scene_query_result

        elif (
            action in (EventHandler.Action.DEACTIVATE_PATH, EventHandler.Action.DEACTIVATE_SCENE) and target is None
        ) or (action is EventHandler.Action.SET_COORDINATE and type(target) is Vec3):
            pass

        elif action is EventHandler.Action.DETACH:
            if target is not None:
                raise EventRegistrationTargetError(action, target, type(None))

        elif (action is EventHandler.Action.RESET_APPEARANCE and target is not None) or (
            _ACTION_TARGET_TYPES[action] != target.__class__
        ):
            raise EventRegistrationTargetError(action, target, _ACTION_TARGET_TYPES[action])

        assert isinstance(caller, (motion.Path, animation.Scene, motion.Waypoint, world.Body))
        new_event = (event, caller)
        new_action = (action, target)

        if new_event not in self.registered_events:
            self.registered_events[new_event] = []

        # Check for duplicate event-action-target combination
        if new_action in self.registered_events[new_event]:
            raise DuplicateEventRegistrationError(event, caller, action, target)

        self.registered_events[new_event].append(new_action)

    def _handle_event(
        self,
        event: Event,
        caller: animation.Scene | motion.Waypoint | motion.Path | world.Body,
    ) -> None:
        """Handle a registered event by executing all associated actions.

        This method processes an event triggered by a caller object (Scene, Waypoint, or Path) and
        executes all actions that were registered for this specific event-caller combination. If no
        actions are registered for the given event and caller, the method returns without doing anything.

        The method supports the following action types:
        - ACTIVATE_PATH: Activates a motion path for the character
        - ACTIVATE_SCENE: Activates an animation scene for the character
        - DEACTIVATE_PATH: Deactivates a specific motion path or, when the target is `None`,
          the currently active path
        - DEACTIVATE_SCENE: Deactivates a specific animation scene or, when the target is `None`,
          the currently active scene
        - RESET_APPEARANCE: Resets the character's appearance to its input symbol and,
          where applicable, its configured input colors
        - SET_LAYER: Sets the character's rendering layer
        - SET_COORDINATE: Moves the node to a cell (`Coord`) or a position (`Vec3`) in its parent's frame
        - CALLBACK: Executes a custom callback function with the character and additional arguments

        Args:
            event (Event): The event to handle. Must be one of the Event enum values.
            caller (animation.Scene | motion.Waypoint | motion.Path | world.Body): The object that
                triggered the event.
                The caller type must match the expected type for the given event (e.g., PATH_COMPLETE
                events must be triggered by motion.Path objects).

        Note:
            This method is typically called internally by the animation and motion systems when
            specific state changes occur. Events and their associated actions are registered using
            the register_event method.

        Example:
            When `Event.PATH_COMPLETE` is triggered for a registered path caller, all
            actions registered for that event/caller pair are executed in order.

        """
        event_actions = self.registered_events.get((event, caller))
        if event_actions is None:
            return
        for action, target in event_actions:
            if action is EventHandler.Action.ACTIVATE_PATH:
                self.character.motion.activate_path(target)  # type: ignore[arg-type]
            elif action is EventHandler.Action.ACTIVATE_SCENE:
                self.character.animation.activate_scene(target)  # type: ignore[arg-type]
            elif action is EventHandler.Action.DEACTIVATE_PATH:
                if target is None:
                    self.character.motion.deactivate_path()
                else:
                    self.character.motion.deactivate_path(target)  # type: ignore[arg-type]
            elif action is EventHandler.Action.DEACTIVATE_SCENE:
                if target is None:
                    self.character.animation.deactivate_scene()
                else:
                    self.character.animation.deactivate_scene(target)  # type: ignore[arg-type]
            elif action is EventHandler.Action.RESET_APPEARANCE:
                self.character.animation.set_appearance(self.character.input_symbol)
            elif action is EventHandler.Action.SET_LAYER:
                self.character.layer = target  # type: ignore[assignment]
            elif action is EventHandler.Action.SET_COORDINATE:
                if type(target) is Vec3:
                    self.character.motion.position = target
                else:
                    self.character.motion.set_coordinate(target)  # type: ignore[arg-type]
            elif action is EventHandler.Action.CALLBACK:
                target.callback(self.character, *target.args)  # type: ignore[union-attr]
            elif action is EventHandler.Action.ATTACH:
                self.character.attach(target)  # type: ignore[arg-type]
            elif action is EventHandler.Action.DETACH:
                self.character.detach()


# Registration rules are shared; per-character event actions remain independent.
_EVENT_CALLER_TYPES: typing.Mapping[
    EventHandler.Event,
    type[animation.Scene | motion.Waypoint | motion.Path | world.Body],
] = MappingProxyType(
    {
        EventHandler.Event.SEGMENT_ENTERED: motion.Waypoint,
        EventHandler.Event.SEGMENT_EXITED: motion.Waypoint,
        EventHandler.Event.PATH_ACTIVATED: motion.Path,
        EventHandler.Event.PATH_COMPLETE: motion.Path,
        EventHandler.Event.PATH_HOLDING: motion.Path,
        EventHandler.Event.SCENE_ACTIVATED: animation.Scene,
        EventHandler.Event.SCENE_COMPLETE: animation.Scene,
        EventHandler.Event.ATTACHED: world.Body,
        EventHandler.Event.DETACHED: world.Body,
    },
)
_ACTION_TARGET_TYPES: typing.Mapping[
    EventHandler.Action,
    type[animation.Scene | motion.Path | world.Body | int | Coord | Vec3 | EventHandler.Callback | None],
] = MappingProxyType(
    {
        EventHandler.Action.ACTIVATE_PATH: motion.Path,
        EventHandler.Action.ACTIVATE_SCENE: animation.Scene,
        EventHandler.Action.DEACTIVATE_PATH: motion.Path,
        EventHandler.Action.DEACTIVATE_SCENE: animation.Scene,
        EventHandler.Action.RESET_APPEARANCE: type(None),
        EventHandler.Action.SET_LAYER: int,
        EventHandler.Action.SET_COORDINATE: Coord,
        EventHandler.Action.CALLBACK: EventHandler.Callback,
        EventHandler.Action.ATTACH: world.Body,
        EventHandler.Action.DETACH: type(None),
    },
)
# Bodies have no animation, layer or appearance: these are the events and actions a body's handler refuses.
_CHARACTER_EVENTS = frozenset(
    {
        EventHandler.Event.SCENE_ACTIVATED,
        EventHandler.Event.SCENE_COMPLETE,
    },
)
_NODE_ACTIONS = frozenset(
    {
        EventHandler.Action.ACTIVATE_PATH,
        EventHandler.Action.DEACTIVATE_PATH,
        EventHandler.Action.SET_COORDINATE,
        EventHandler.Action.ATTACH,
        EventHandler.Action.DETACH,
        EventHandler.Action.CALLBACK,
    },
)


class EffectCharacter(world.SpatialNode):
    """A class representing a single character from the input data.

    EffectCharacters are created and managed by the Terminal and are used to apply
    animations and effects to individual characters. Additional non-input characters
    can be created with `Terminal.add_character()`.

    Methods:
        tick: Progress the character's animation and motion by one step.

    Attributes:
        character_id (int): The unique ID of the character, generated by the Terminal.
        input_symbol (str): The symbol for the character in the input data.
        input_coord (Coord): The coordinate of the character in the input data.
        is_visible (bool): Whether the character is currently visible and should be printed to the terminal.
        animation (animation.Animation): The animation object that controls the character's appearance.
        motion (motion.Motion): The motion object that controls the character's movement.
        parent (world.Body): The body the character's position is measured against: the terminal's text plane
            until it's moved elsewhere.
        position (g3.Vec3): The character's position in its parent's frame, `(column, row, height)` on the text
            plane. The same as `motion.position`.
        world_position (g3.Vec3): The character's position in the world.
        view (view.View): How the character is seen this frame: its cell, depth, facing and light.
        event_handler (EventHandler): The event handler object that handles events related to the character.
        layer (int): The layer of the character. Lower layers are painted first. Within a layer, characters are
            ordered by their depth from the camera, farther first. When characters on the same layer and at the same
            depth collide, the character with the higher `character_id` is painted last and wins the collision.
        is_fill_character (bool): Whether the character is a fill character. Fill characters are used to fill
            the empty cells of the Canvas.
        uses_input_preexisting_colors (bool): Whether engine-level `existing_color_handling="always"` should treat
            this character as input-derived and therefore replace effect-owned colors with the parsed input fg/bg
            pair, even when that pair is empty.
        links (set[EffectCharacter]): Linked neighboring characters used by spanning-tree algorithms.
        neighbors (dict[str, EffectCharacter | None]): Adjacent characters keyed by direction
            (`"north"`, `"east"`, `"south"`, `"west"`). Reading this property on a terminal-owned character lazily
            prepares the terminal's complete fill-character and neighbor graph.

    """

    def __init__(self, character_id: int, symbol: str, input_column: int, input_row: int) -> None:
        """Initialize the character instance with the character ID, symbol, and input coordinates.

        Args:
            character_id (int): The unique ID of the character, generated by the Terminal.
            symbol (str): The symbol for the character in the input data.
            input_column (int): The column of the character in the input data.
            input_row (int): The row of the character in the input data.

        """
        self._character_id: int = character_id
        self._input_symbol: str = symbol
        self._input_coord: Coord = Coord(input_column, input_row)
        self._is_visible: bool = False
        self._terminal_owner_token: typing.Callable[[], _CharacterOwner | None] | None = None
        self.animation: animation.Animation = animation.Animation(self)
        self.motion: motion.Motion = motion.Motion(self)
        self.event_handler: EventHandler = EventHandler(self)
        self._layer = 0
        self._depth_order = 0.0
        self.is_fill_character = False
        self.uses_input_preexisting_colors = False
        self.links: set[EffectCharacter] = set()
        self._neighbors: dict[str, EffectCharacter | None] | None = None
        self._view: view.View | None = None

    _ON_SURFACE = True

    @property
    def view(self) -> view.View:
        """How the character is seen from the camera: its cell, depth, facing, light and face."""
        if self._view is None:
            self._view = view.View(self)
        return self._view

    def _default_parent(self) -> world.Body:
        """Join the owning terminal's text plane, or the shared free plane for a character no terminal owns."""
        owner = self._terminal_owner_token() if self._terminal_owner_token is not None else None
        return owner.world.text_plane if owner is not None else world.free_text_plane()

    @property
    def position(self) -> g3.Vec3:
        """The character's position in its parent's frame: `(column, row, height)` on the text plane."""
        return self.motion.position

    def _place(self, position: g3.Vec3) -> None:
        motion = self.motion
        motion.current_coord = motion._cell
        motion._xyz = (position.x, position.y, position.z)
        motion._resolve()

    @property
    def neighbors(self) -> dict[str, EffectCharacter | None]:
        """Adjacent characters keyed by cardinal direction.

        Terminal-owned characters prepare their terminal's complete character graph
        on first access. Standalone characters receive an independent empty mapping.
        """
        if self._neighbors is None:
            owner = self._terminal_owner_token() if self._terminal_owner_token is not None else None
            if owner is not None:
                owner.prepare_character_graph()
            if self._neighbors is None:
                self._neighbors = {}
        return self._neighbors

    @property
    def input_symbol(self) -> str:
        """The symbol for the character in the input data."""
        return self._input_symbol

    @property
    def input_coord(self) -> Coord:
        """The coordinate of the character in the input data."""
        return self._input_coord

    def _set_input_coord(self, coord: Coord) -> None:
        """Set the input coordinate and synchronize the character's current position."""
        self._input_coord = coord
        self.motion.set_coordinate(coord)

    def _notify_current_visual_width_changed(self, previous_width: int) -> None:
        """Notify the owning terminal when the current visual changes display width."""
        owner = self._terminal_owner_token() if self._terminal_owner_token is not None else None
        if owner is not None:
            owner._notify_character_cell_width_changed(self, previous_width)

    @property
    def is_visible(self) -> bool:
        """Whether the character is currently visible and should be printed to the terminal."""
        return self._is_visible

    @property
    def character_id(self) -> int:
        """The unique ID of the character, generated by the Terminal."""
        return self._character_id

    @property
    def layer(self) -> int:
        """Rendering layer used to resolve character collisions."""
        return self._layer

    @layer.setter
    def layer(self, layer: int) -> None:
        """Set the rendering layer and invalidate terminal painter ordering when necessary."""
        previous_layer = self._layer
        if layer == previous_layer:
            return
        self._layer = layer
        owner = self._terminal_owner_token() if self._terminal_owner_token is not None else None
        if owner is not None:
            owner._notify_character_layer_changed(self, previous_layer)

    def _set_depth_order(self, order: float) -> None:
        """Set the order within the character's layer, from -0.5 (painted first) to 0.5, used for 3D depth.

        Characters that never set it stay at 0, so they keep their usual place among characters on their layer.
        """
        previous_order = self._depth_order
        if order == previous_order:
            return
        self._depth_order = order
        owner = self._terminal_owner_token() if self._terminal_owner_token is not None else None
        if owner is not None:
            owner._notify_character_depth_order_changed(self, previous_order)

    @property
    def is_active(self) -> bool:
        """Returns whether the character is currently active.

        A character is active when its animation has an incomplete active scene or its
        motion has an incomplete active path.

        Returns:
            bool: True if the character is active, False if not.

        """
        return bool(not self.animation.active_scene_is_complete() or not self.motion.movement_is_complete())

    def tick(self) -> None:
        """Progress the character by one tick.

        Motion is advanced first, then animation is stepped so animation logic can react
        to the character's updated motion state for the same tick.
        """
        self.motion.move()
        self.animation.step_animation()

    def _link(self, char: EffectCharacter, *, bidirectional: bool = True) -> None:
        """Link this character with another character.

        Used for spanning-tree algorithms. When `bidirectional` is True, the reverse link
        is added to `char` as well. Links are stored in a set, so repeated links are
        idempotent.

        Args:
            char (EffectCharacter): Character being linked to this character.
            bidirectional (bool, optional): Apply the link on both characters. Defaults to True.

        """
        if bidirectional:
            char._link(self, bidirectional=False)
        self.links.add(char)

    def __hash__(self) -> int:
        """Hash by `character_id`, so sets of characters iterate in the same order on every run.

        Equality stays identity. Hashing by memory address made the order of `active_characters` vary between runs,
        and with it the order effects drew random numbers, so `--seed` didn't reproduce some effects.
        """
        return self._character_id

    def __repr__(self) -> str:
        """Return a string representation of the EffectCharacter instance."""
        return (
            f"EffectCharacter(character_id={self.character_id}, symbol='{self.input_symbol}', "
            f"input_column={self.input_coord.column}, input_row={self.input_coord.row})"
        )
