"""Prints the input data in a random sequence, one character at a time.

Classes:
    RandomSequence: Prints the input data in a random sequence.
    RandomSequenceConfig: Configuration for the RandomSequence effect.
    RandomSequenceIterator: Iterator for the RandomSequence effect. Does not normally need to be called directly.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from terminaltexteffects import Color, ColorPair, EffectCharacter, Gradient
from terminaltexteffects.engine.base_config import (
    BaseConfig,
    FinalGradientDirectionArg,
    FinalGradientFramesArg,
    FinalGradientStepsArg,
    FinalGradientStopsArg,
)
from terminaltexteffects.engine.base_effect import BaseEffect, BaseEffectIterator
from terminaltexteffects.utils import argutils


def get_effect_resources() -> tuple[str, type[BaseEffect], type[BaseConfig]]:
    """Get the command, effect class, and configuration class for the effect.

    Returns:
        tuple[str, type[BaseEffect], type[BaseConfig]]: The command name, effect class, and configuration class.

    """
    return "randomsequence", RandomSequence, RandomSequenceConfig


@dataclass
class RandomSequenceConfig(BaseConfig):
    """Configuration for the RandomSequence effect.

    Attributes:
        speed (float): Speed of the animation as a percentage of the total number of characters to reveal in each tick.
            Valid values are 0 < n <= 1.
        final_gradient_stops (tuple[Color, ...]): Tuple of colors for the final color gradient. If only one color is
            provided, the characters will be displayed in that color.
        final_gradient_steps (tuple[int, ...] | int): Tuple of the number of gradient steps to use. More steps will
            create a smoother and longer gradient animation. Valid values are n > 0.
        final_gradient_frames (int): Number of frames to display each gradient step. Increase to slow down the
            gradient animation.
        final_gradient_direction (Gradient.Direction): Direction of the final gradient.

    """

    parser_spec: argutils.ParserSpec = argutils.ParserSpec(
        name="randomsequence",
        help="Prints the input data in a random sequence.",
        description="randomsequence | Prints the input data in a random sequence.",
        epilog=(
            "Example: terminaltexteffects randomsequence --speed 0.007 --final-gradient-stops 8A008A 00D1FF "
            "ffffff --final-gradient-steps 12 --final-gradient-frames 8 --final-gradient-direction vertical"
        ),
    )

    speed: float = argutils.ArgSpec(
        name="--speed",
        type=argutils.PositiveRatio.type_parser,
        default=0.007,
        metavar=argutils.PositiveRatio.METAVAR,
        help="Fraction of input characters to reveal per tick. Values must be greater than 0 and at most 1.",
    )  # pyright: ignore[reportAssignmentType]
    "float : Fraction of input characters to reveal per tick. Values must be greater than 0 and at most 1."

    final_gradient_stops: tuple[Color, ...] = FinalGradientStopsArg(
        default=(Color("#8A008A"), Color("#00D1FF"), Color("#FFFFFF")),
    )  # pyright: ignore[reportAssignmentType]
    (
        "tuple[Color, ...] : Tuple of colors for the final color gradient. "
        "If only one color is provided, the characters will be displayed in that color."
    )

    final_gradient_steps: tuple[int, ...] | int = FinalGradientStepsArg(
        default=12,
    )  # pyright: ignore[reportAssignmentType]
    (
        "tuple[int, ...] | int : Int or Tuple of ints for the number of gradient steps to use. "
        "More steps will create a smoother and longer gradient animation."
    )

    final_gradient_frames: int = FinalGradientFramesArg(
        default=8,
    )  # pyright: ignore[reportAssignmentType]
    "int : Number of frames to display each gradient step. Increase to slow down the gradient animation."

    final_gradient_direction: Gradient.Direction = FinalGradientDirectionArg(
        default=Gradient.Direction.VERTICAL,
    )  # pyright: ignore[reportAssignmentType]
    "Gradient.Direction : Direction of the final gradient."


class RandomSequenceIterator(BaseEffectIterator[RandomSequenceConfig]):
    """Iterator for the RandomSequence effect."""

    DYNAMIC_NEUTRAL_GRAY = Color("#808080")

    def __init__(self, effect: RandomSequence) -> None:
        """Initialize the effect iterator.

        Args:
            effect (RandomSequence): The effect to use for the iterator.

        """
        super().__init__(effect)
        self.pending_chars: list[EffectCharacter] = []
        self.character_final_color_map: dict[EffectCharacter, ColorPair] = {}
        self.characters_per_tick = max(int(self.config.speed * len(self.terminal._input_characters)), 1)
        self.build()

    def build(self) -> None:
        """Build the initial state of the effect."""
        terminal_background_color = self.terminal.config.terminal_background_color
        final_gradient = Gradient(*self.config.final_gradient_stops, steps=self.config.final_gradient_steps)
        final_gradient_mapping = final_gradient.build_coordinate_color_mapping(
            self.terminal.canvas.text_bottom,
            self.terminal.canvas.text_top,
            self.terminal.canvas.text_left,
            self.terminal.canvas.text_right,
            self.config.final_gradient_direction,
        )
        for character in self.terminal.get_characters():
            if self.terminal.config.existing_color_handling == "dynamic":
                self.character_final_color_map[character] = ColorPair(
                    fg=character.animation.input_fg_color,
                    bg=character.animation.input_bg_color,
                )
            else:
                self.character_final_color_map[character] = ColorPair(
                    fg=final_gradient_mapping[character.input_coord],
                )
            self.terminal.set_character_visibility(character, is_visible=False)
            gradient_scn = character.animation.new_scene()
            if self.terminal.config.existing_color_handling == "dynamic":
                final_fg_color = self.character_final_color_map[character].fg
                final_bg_color = self.character_final_color_map[character].bg
                if final_fg_color or final_bg_color:
                    fg_gradient = (
                        Gradient(terminal_background_color, final_fg_color, steps=7) if final_fg_color else None
                    )
                    bg_gradient = (
                        Gradient(terminal_background_color, final_bg_color, steps=7) if final_bg_color else None
                    )
                    gradient_scn.apply_gradient_to_symbols(
                        character.input_symbol,
                        self.config.final_gradient_frames,
                        fg_gradient=fg_gradient,
                        bg_gradient=bg_gradient,
                    )
                else:
                    gradient_scn.apply_gradient_to_symbols(
                        character.input_symbol,
                        self.config.final_gradient_frames,
                        fg_gradient=Gradient(terminal_background_color, self.DYNAMIC_NEUTRAL_GRAY, steps=7),
                    )
                    gradient_scn.add_frame(
                        character.input_symbol,
                        self.config.final_gradient_frames,
                        colors=ColorPair(),
                    )
            else:
                final_fg_color = self.character_final_color_map[character].fg
                assert final_fg_color is not None
                gradient = Gradient(terminal_background_color, final_fg_color, steps=7)
                gradient_scn.apply_gradient_to_symbols(
                    character.input_symbol,
                    self.config.final_gradient_frames,
                    fg_gradient=gradient,
                )
            character.animation.activate_scene(gradient_scn)
            self.pending_chars.append(character)
        random.shuffle(self.pending_chars)

    def __next__(self) -> str:
        """Return the next frame in the animation."""
        if self.pending_chars or self.active_characters:
            for _ in range(self.characters_per_tick):
                if self.pending_chars:
                    next_char = self.pending_chars.pop()
                    self.terminal.set_character_visibility(next_char, is_visible=True)
                    self.active_characters.add(next_char)
            self.update()
            return self.frame
        raise StopIteration


class RandomSequence(BaseEffect[RandomSequenceConfig]):
    """Prints the input data in a random sequence, one character at a time.

    Attributes:
        effect_config (RandomSequenceConfig): Configuration for the effect.
        terminal_config (TerminalConfig): Configuration for the terminal.

    """

    @property
    def _config_cls(self) -> type[RandomSequenceConfig]:
        return RandomSequenceConfig

    @property
    def _iterator_cls(self) -> type[RandomSequenceIterator]:
        return RandomSequenceIterator
