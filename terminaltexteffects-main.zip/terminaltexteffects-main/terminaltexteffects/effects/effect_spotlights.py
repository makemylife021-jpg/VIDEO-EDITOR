"""Spotlights search the text area, illuminating characters, before converging in the center and expanding.

Classes:
    Spotlights: Spotlights search the text area, illuminating characters, before converging in the center and expanding.
    SpotlightsConfig: Configuration for the Spotlights effect.
    SpotlightsIterator: Effect iterator for the Spotlights effect. Does not normally need to be called directly.
"""

from __future__ import annotations

import math
import random
from bisect import bisect_left, bisect_right
from dataclasses import dataclass
from functools import lru_cache

from terminaltexteffects import Color, ColorPair, Coord, EffectCharacter, Gradient, easing, geometry
from terminaltexteffects.engine import animation, motion
from terminaltexteffects.engine.base_config import (
    BaseConfig,
    FinalGradientDirectionArg,
    FinalGradientStepsArg,
    FinalGradientStopsArg,
)
from terminaltexteffects.engine.base_effect import BaseEffect, BaseEffectIterator
from terminaltexteffects.utils import argutils


def get_effect_resources() -> tuple[str, type[BaseEffect], type[BaseConfig]]:
    """Get the command, effect class, and configuration class for the effect.

    Returns:
        tuple[str, type[BaseEffect], type[BaseConfig]]: The command name, effect class, and configuration class.

    """
    return "spotlights", Spotlights, SpotlightsConfig


@dataclass
class SpotlightsConfig(BaseConfig):
    """Configuration for the Spotlights effect.

    Attributes:
        beam_width_ratio (float): Width of the beam of light as min(width, height) // n of the input text. Valid
            values are n > 0. Values where n < 1 are raised to 1.
        beam_falloff (float): Distance from the edge of the beam where the brightness begins to fall off, as a
            percentage of total beam width. Valid values are 0 <= n <= 1.
        search_duration (int): Duration of the search phase, in frames, before the spotlights converge in the center.
            Valid values are n > 0.
        search_speed_range (tuple[float, float]): Range of speeds for the spotlights during the search phase. The
            speed is a random value between the two provided values. Valid values are n > 0.
        spotlight_count (int): Number of spotlights to use. Valid values are n > 0.
        final_gradient_stops (tuple[Color, ...]): Tuple of colors for the final color gradient. If only one color is
            provided, the characters will be displayed in that color.
        final_gradient_steps (tuple[int, ...] | int): Tuple of the number of gradient steps to use. More steps will
            create a smoother and longer gradient animation. Valid values are n > 0.
        final_gradient_direction (Gradient.Direction): Direction of the final gradient.

    """

    parser_spec: argutils.ParserSpec = argutils.ParserSpec(
        name="spotlights",
        help="Spotlights search the text area, illuminating characters, before converging in the center and expanding.",
        description="spotlights | Spotlights search the text area, illuminating characters, before converging in the "
        "center and expanding.",
        epilog=(
            f"{argutils.EASING_EPILOG} Example: terminaltexteffects spotlights --final-gradient-stops ab48ff "
            "e7b2b2 fffebd --final-gradient-steps 12 --final-gradient-direction vertical --beam-width-ratio 2.0 "
            "--beam-falloff 0.3 --search-duration 550 --search-speed-range 0.35-0.75 --spotlight-count 3"
        ),
    )

    beam_width_ratio: float = argutils.ArgSpec(
        name="--beam-width-ratio",
        type=argutils.PositiveFloat.type_parser,
        default=2.0,
        metavar=argutils.PositiveFloat.METAVAR,
        help="Width of the beam of light as min(width, height) // n of the input text. Values less than 1 "
        "are raised to 1.",
    )  # pyright: ignore[reportAssignmentType]
    (
        "float : Width of the beam of light as min(width, height) // n of the input text. Values less than 1 "
        "are raised to 1."
    )

    beam_falloff: float = argutils.ArgSpec(
        name="--beam-falloff",
        type=argutils.NonNegativeRatio.type_parser,
        default=0.3,
        metavar=argutils.NonNegativeRatio.METAVAR,
        help="Distance from the edge of the beam where the brightness begins to fall off, as a percentage of "
        "total beam width. Valid values are 0 <= n <= 1.",
    )  # pyright: ignore[reportAssignmentType]
    (
        "float : Distance from the edge of the beam where the brightness begins to fall off, as a percentage "
        "of total beam width. Valid values are 0 <= n <= 1."
    )

    search_duration: int = argutils.ArgSpec(
        name="--search-duration",
        type=argutils.PositiveInt.type_parser,
        default=550,
        metavar=argutils.PositiveInt.METAVAR,
        help="Duration of the search phase, in frames, before the spotlights converge in the center.",
    )  # pyright: ignore[reportAssignmentType]
    "int : Duration of the search phase, in frames, before the spotlights converge in the center."

    search_speed_range: tuple[float, float] = argutils.ArgSpec(
        name="--search-speed-range",
        type=argutils.PositiveFloatRange.type_parser,
        default=(0.35, 0.75),
        metavar=argutils.PositiveFloatRange.METAVAR,
        help="Range of speeds for the spotlights during the search phase. The speed is a random value between the "
        "two provided values.",
    )  # pyright: ignore[reportAssignmentType]
    (
        "tuple[float, float] : Range of speeds for the spotlights during the search phase. The speed is a random "
        "value between the two provided values."
    )

    spotlight_count: int = argutils.ArgSpec(
        name="--spotlight-count",
        type=argutils.PositiveInt.type_parser,
        default=3,
        metavar=argutils.PositiveInt.METAVAR,
        help="Number of spotlights to use.",
    )  # pyright: ignore[reportAssignmentType]
    "int : Number of spotlights to use."

    final_gradient_stops: tuple[Color, ...] = FinalGradientStopsArg(
        default=(Color("#ab48ff"), Color("#e7b2b2"), Color("#fffebd")),
    )  # pyright: ignore[reportAssignmentType]
    (
        "tuple[Color, ...] : Tuple of colors for the final color gradient. If only one color is provided, the "
        "characters will be displayed in that color."
    )

    final_gradient_steps: tuple[int, ...] | int = FinalGradientStepsArg(
        default=12,
    )  # pyright: ignore[reportAssignmentType]
    (
        "tuple[int, ...] | int : Int or Tuple of ints for the number of gradient steps to use. More steps will "
        "create a smoother and longer gradient animation."
    )

    final_gradient_direction: Gradient.Direction = FinalGradientDirectionArg(
        default=Gradient.Direction.VERTICAL,
    )  # pyright: ignore[reportAssignmentType]
    "Gradient.Direction : Direction of the final gradient."


class SpotlightsIterator(BaseEffectIterator[SpotlightsConfig]):
    """Effect iterator for the Spotlights effect."""

    DYNAMIC_NEUTRAL_GRAY = Color("#808080")
    BRIGHTNESS_CACHE_SIZE = 4096

    def __init__(self, effect: Spotlights) -> None:
        """Initialize the effect iterator.

        Args:
            effect (Spotlights): The effect to use for the iterator.

        """
        super().__init__(effect)
        self.pending_chars: list[EffectCharacter] = []
        self.illuminated_chars: set[EffectCharacter] = set()
        self.character_color_map: dict[EffectCharacter, tuple[ColorPair, ColorPair]] = {}
        # Cache immutable results per iterator without retaining this iterator in the wrapper.
        self._cached_color_pair_brightness = lru_cache(maxsize=self.BRIGHTNESS_CACHE_SIZE)(
            self._adjust_color_pair_brightness,
        )
        self._appearance_state: dict[
            EffectCharacter,
            tuple[ColorPair, tuple[object, ...], animation.CharacterVisual, dict[str, object]],
        ] = {}
        self.build()

    @staticmethod
    def _adjust_color_pair_brightness(colors: ColorPair, brightness_factor: float) -> ColorPair:
        return ColorPair(
            fg=(animation.Animation.adjust_color_brightness(colors.fg, brightness_factor) if colors.fg else None),
            bg=(animation.Animation.adjust_color_brightness(colors.bg, brightness_factor) if colors.bg else None),
        )

    @staticmethod
    def _has_input_colors(character: EffectCharacter) -> bool:
        return any((character.animation.input_fg_color, character.animation.input_bg_color))

    def _is_spotlightable(self, character: EffectCharacter) -> bool:
        return character.input_symbol != " " or self._has_input_colors(character)

    def _get_expand_color_override(self, character: EffectCharacter) -> ColorPair | None:
        if self.terminal.config.existing_color_handling != "dynamic" or not self.expanding:
            return None
        if character.animation.input_fg_color is None and character.animation.input_bg_color is not None:
            return ColorPair(bg=character.animation.input_bg_color)
        if not self._has_input_colors(character):
            return ColorPair()
        return None

    def make_spotlights(self, num_spotlights: int) -> list[EffectCharacter]:
        """Create the spotlights.

        Args:
            num_spotlights (int): The number of spotlights to create.

        Returns:
            list[EffectCharacter]: The spotlights as a list of EffectCharacter instances.

        """
        spotlights: list[EffectCharacter] = []
        minimum_distance = self.terminal.canvas.right // 4
        for _ in range(num_spotlights):
            spotlight = self.terminal.add_character("O", self.terminal.canvas.random_coord(outside_scope=True))
            spotlights.append(spotlight)

            spotlight_target_coords: list[Coord] = []
            last_coord = self.terminal.canvas.random_coord()
            spotlight_target_coords.append(last_coord)
            for _ in range(10):
                next_coord = self.find_coord_at_minimum_distance(last_coord, minimum_distance)
                spotlight_target_coords.append(next_coord)
                last_coord = next_coord

            paths: list[motion.Path] = []
            for coord in spotlight_target_coords:
                path = spotlight.motion.new_path(
                    speed=random.uniform(self.config.search_speed_range[0], self.config.search_speed_range[1]),
                    ease=easing.in_out_quad,
                    path_id=str(len(paths)),
                )
                path.new_waypoint(coord, bezier_control=self.terminal.canvas.random_coord(outside_scope=True))
                paths.append(path)
            spotlight.motion.chain_paths(paths, loop=True)

            path = spotlight.motion.new_path(speed=0.5, ease=easing.in_out_sine, path_id="center")
            path.new_waypoint(self.terminal.canvas.center)

        return spotlights

    def find_coord_at_minimum_distance(self, origin_coord: Coord, minimum_distance: int) -> Coord:
        """Find a coordinate at a minimum distance from the origin.

        Args:
            origin_coord (Coord): Origin coordinate.
            minimum_distance (int): Minimum distance from the origin.

        Returns:
            Coord: The coordinate found.

        """
        coord_found = False
        while not coord_found:
            coord = self.terminal.canvas.random_coord()
            distance = geometry.find_length_of_line(origin_coord, coord, terminal_adjusted=True)
            if distance >= minimum_distance:
                coord_found = True
        return coord  # type: ignore[arg-type]

    def illuminate_chars(self, range_: int) -> None:
        """Illuminate characters within a range of the spotlights.

        Args:
            range_ (int): The range of the spotlights.

        """
        chars_in_range = self._get_chars_in_range(range_)
        chars_no_longer_in_range = self.illuminated_chars - chars_in_range
        for character in chars_no_longer_in_range:
            expand_override = self._get_expand_color_override(character)
            if expand_override is None:
                self._set_appearance(character, self.character_color_map[character][1])
            else:
                self._set_appearance(character, expand_override)

        centers = tuple(spotlight.motion.current_coord for spotlight in self.spotlights)
        for character in chars_in_range:
            distance = math.inf
            coord = character.input_coord
            for center in centers:
                beam_distance = math.hypot(
                    coord.column - center.column,
                    (coord.row - center.row) * geometry.TERMINAL_ROW_SCALE,
                )
                if beam_distance < distance:  # noqa: PLR1730 - Avoid a function call for each beam.
                    distance = beam_distance

            # A continuation cell can be covered even when its leading cell is outside the beam.
            # Zero falloff is a hard edge: every covered character receives full brightness.
            if self.config.beam_falloff and distance > range_ * (1 - self.config.beam_falloff):
                brightness_factor = max(
                    1 - (distance - range_ * (1 - self.config.beam_falloff)) / (range_ * self.config.beam_falloff),
                    0.2,
                )
                adjusted_color = self._cached_color_pair_brightness(
                    self.character_color_map[character][0],
                    brightness_factor,
                )
            else:
                adjusted_color = self.character_color_map[character][0]
            expand_override = self._get_expand_color_override(character)
            if expand_override is None:
                self._set_appearance(character, adjusted_color)
            else:
                self._set_appearance(character, expand_override)
        self.illuminated_chars = chars_in_range

    def _set_appearance(self, character: EffectCharacter, colors: ColorPair) -> None:
        """Reuse this effect's unchanged visuals, restoring appearance after external edits.

        Snapshot all instance fields, including styles and the formatted symbol, and the
        animation color policy. A changed or replaced visual goes through `set_appearance`
        again. Input-color overrides use the engine helper to compare effective colors.
        """
        anim = character.animation
        if anim.existing_color_handling == "always":
            anim.set_appearance_if_changed(character.input_symbol, colors)
            return
        visual = anim.current_character_visual
        policy = (
            anim.no_color,
            anim.use_xterm_colors,
            anim.existing_color_handling,
            anim.input_fg_color,
            anim.input_bg_color,
            anim.input_bold,
            character.uses_input_preexisting_colors,
        )
        previous = self._appearance_state.get(character)
        if (
            previous is not None
            and previous[0] == colors
            and previous[1] == policy
            and previous[2] is visual
            and previous[3] == visual.__dict__
        ):
            return
        anim.set_appearance(character.input_symbol, colors)
        visual = anim.current_character_visual
        self._appearance_state[character] = (colors, policy, visual, visual.__dict__.copy())

    def _build_spotlight_index(self) -> None:
        """Index authored input cells, including wide continuations and colored spaces.

        Input coordinates and symbols remain fixed during this effect. Build after applying
        each input symbol so the current visual width matches its authored footprint.
        Uncolored fill cells never participate in illumination and need not be materialized.
        """
        column_cells: dict[int, list[tuple[int, EffectCharacter]]] = {}
        for character in self.character_color_map:
            if not self._is_spotlightable(character):
                continue
            coord = character.input_coord
            for offset in range(character.animation.current_character_visual.cell_width):
                column_cells.setdefault(coord.column + offset, []).append((coord.row, character))
        self._spotlight_columns = sorted(column_cells)
        self._spotlight_cells: dict[int, tuple[tuple[int, ...], tuple[EffectCharacter, ...]]] = {}
        for column, cells in column_cells.items():
            cells.sort(key=lambda cell: cell[0])
            self._spotlight_cells[column] = (
                tuple(row for row, _ in cells),
                tuple(character for _, character in cells),
            )

    def _get_chars_in_range(self, range_: int) -> set[EffectCharacter]:
        """Select occupied cells using the same floating ellipse spans as the geometry helper."""
        if range_ < 0:
            msg = "radius must be non-negative."
            raise ValueError(msg)
        chars_in_range: set[EffectCharacter] = set()
        a_squared = range_**2
        b_squared = (range_ / geometry.TERMINAL_ROW_SCALE) ** 2
        for spotlight in self.spotlights:
            center = spotlight.motion.current_coord
            start = bisect_left(self._spotlight_columns, center.column - range_)
            stop = bisect_right(self._spotlight_columns, center.column + range_)
            for column in self._spotlight_columns[start:stop]:
                offset = int((b_squared * (1 - ((column - center.column) ** 2) / a_squared)) ** 0.5) if range_ else 0
                rows, characters = self._spotlight_cells[column]
                lo = bisect_left(rows, center.row - offset)
                hi = bisect_right(rows, center.row + offset)
                chars_in_range.update(characters[lo:hi])
        return chars_in_range

    def build(self) -> None:
        """Build the initial state of the effect."""
        self.spotlights: list[EffectCharacter] = self.make_spotlights(self.config.spotlight_count)
        final_gradient = Gradient(*self.config.final_gradient_stops, steps=self.config.final_gradient_steps)
        final_gradient_mapping = final_gradient.build_coordinate_color_mapping(
            self.terminal.canvas.text_bottom,
            self.terminal.canvas.text_top,
            self.terminal.canvas.text_left,
            self.terminal.canvas.text_right,
            self.config.final_gradient_direction,
        )
        for character in self.terminal.get_characters():
            if self.terminal.config.existing_color_handling == "dynamic":
                if character.animation.input_fg_color or character.animation.input_bg_color:
                    bright_fg = character.animation.input_fg_color
                    if bright_fg is None and character.animation.input_bg_color is not None:
                        bright_fg = self.DYNAMIC_NEUTRAL_GRAY
                    bright_pair = ColorPair(
                        fg=bright_fg,
                        bg=character.animation.input_bg_color,
                    )
                else:
                    bright_pair = ColorPair(fg=self.DYNAMIC_NEUTRAL_GRAY)
            else:
                color_bright = final_gradient_mapping[character.input_coord]
                bright_pair = ColorPair(fg=color_bright)
            dark_pair = self._cached_color_pair_brightness(bright_pair, 0.2)
            self.terminal.set_character_visibility(character, is_visible=True)
            self.character_color_map[character] = (bright_pair, dark_pair)
            self._set_appearance(character, dark_pair)
        self._build_spotlight_index()
        smallest_dimension = min(self.terminal.canvas.right, self.terminal.canvas.top)
        self.illuminate_range = max(
            int(
                min(
                    smallest_dimension // self.config.beam_width_ratio,
                    smallest_dimension,
                ),
            ),
            1,
        )
        self.search_duration = self.config.search_duration
        self.searching = True
        self.expanding = False
        self.complete = False
        for spotlight in self.spotlights:
            spotlight.motion.activate_path("0")
            self.active_characters.add(spotlight)

    def __next__(self) -> str:
        """Return the next frame in the animation."""
        if not self.complete:
            self.illuminate_chars(self.illuminate_range)
            if self.searching:
                self.search_duration -= 1
                if not self.search_duration:
                    for spotlight in self.spotlights:
                        spotlight.motion.activate_path("center")
                    self.searching = False
            if not any(spotlight.motion.active_path for spotlight in self.spotlights):
                while len(self.spotlights) > 1:
                    self.spotlights.pop()
                self.expanding = True
                self.illuminate_range += 1
                if self.illuminate_range > max(self.terminal.canvas.right, self.terminal.canvas.top) // 1.5:
                    self.complete = True

            self.update()
            return self.frame
        raise StopIteration


class Spotlights(BaseEffect[SpotlightsConfig]):
    """Spotlights search the text area, illuminating characters, before converging in the center and expanding.

    Attributes:
        effect_config (SpotlightsConfig): Configuration for the effect.
        terminal_config (TerminalConfig): Configuration for the terminal.

    """

    @property
    def _config_cls(self) -> type[SpotlightsConfig]:
        return SpotlightsConfig

    @property
    def _iterator_cls(self) -> type[SpotlightsIterator]:
        return SpotlightsIterator
