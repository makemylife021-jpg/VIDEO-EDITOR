"""Matrix digital rain effect.

Classes:
    Matrix: Matrix digital rain effect.
    MatrixConfig: Configuration for the Matrix effect.
    MatrixIterator: Iterator for the Matrix effect. Does not normally need to be called directly.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from terminaltexteffects import Animation, Color, ColorPair, Coord, EffectCharacter, Gradient, Terminal
from terminaltexteffects.engine.base_config import (
    BaseConfig,
    FinalGradientDirectionArg,
    FinalGradientFramesArg,
    FinalGradientStepsArg,
    FinalGradientStopsArg,
)
from terminaltexteffects.engine.base_effect import BaseEffect, BaseEffectIterator
from terminaltexteffects.utils import argutils

MATRIX_SYMBOLS_COMMON = (
    "2",
    "5",
    "9",
    "8",
    "Z",
    "*",
    ")",
    ":",
    ".",
    '"',
    "=",
    "+",
    "-",
    "¦",
    "|",
    "_",
)
MATRIX_SYMBOLS_KATA = (
    "ｦ",
    "ｱ",
    "ｳ",
    "ｴ",
    "ｵ",
    "ｶ",
    "ｷ",
    "ｹ",
    "ｺ",
    "ｻ",
    "ｼ",
    "ｽ",
    "ｾ",
    "ｿ",
    "ﾀ",
    "ﾂ",
    "ﾃ",
    "ﾅ",
    "ﾆ",
    "ﾇ",
    "ﾈ",
    "ﾊ",
    "ﾋ",
    "ﾎ",
    "ﾏ",
    "ﾐ",
    "ﾑ",
    "ﾒ",
    "ﾓ",
    "ﾔ",
    "ﾕ",
    "ﾗ",
    "ﾘ",
    "ﾜ",
)


def get_effect_resources() -> tuple[str, type[BaseEffect], type[BaseConfig]]:
    """Get the command, effect class, and configuration class for the effect.

    Returns:
        tuple[str, type[BaseEffect], type[BaseConfig]]: The command name, effect class, and configuration class.

    """
    return "matrix", Matrix, MatrixConfig


@dataclass
class MatrixConfig(BaseConfig):
    """Configuration for the Matrix effect.

    Attributes:
        highlight_color (Color): Color for the bottom of the rain column.
        rain_color_gradient (tuple[Color, ...]): Tuple of colors for the rain gradient. If only one color is "
            "provided, the characters will be displayed in that color.
        rain_symbols (tuple[str, ...]): Tuple of symbols to use for the rain.
        rain_fall_delay_range (tuple[int, int]): Speed of the falling rain as determined by the delay between rows. "
            "Actual delay is randomly selected from the range.
        rain_column_delay_range (tuple[int, int]): Range of frames to wait between adding new rain columns.
        rain_time (int): Time, in seconds, to display the rain effect before transitioning to the input text.
        symbol_swap_chance (float): Chance of swapping a character's symbol on each tick.
        color_swap_chance (float): Chance of swapping a character's color on each tick.
        resolve_delay (int): Number of frames to wait between resolving the next group of characters. This is used "
            "to adjust the speed of the final resolve phase.
        final_gradient_stops (tuple[Color, ...]): Tuple of colors for the final color gradient. If only one color "
            "is provided, the characters will be displayed in that color.
        final_gradient_steps (tuple[int, ...] | int): Int or Tuple of ints for the number of gradient steps to use. "
            "More steps will create a smoother and longer gradient animation.
        final_gradient_frames (int): Number of frames to display each gradient step. Increase to slow down the "
            "gradient animation.
        final_gradient_direction (Gradient.Direction): Direction of the final gradient.

    """

    parser_spec: argutils.ParserSpec = argutils.ParserSpec(
        name="matrix",
        help="Matrix digital rain effect.",
        description="matrix | Matrix digital rain effect.",
        epilog=(
            "Example: terminaltexteffects matrix --highlight-color dbffdb --rain-color-gradient 92be92 185318 "
            "--rain-symbols 2 5 9 8 Z '*' ')' : . '\"' = + - ¦ '|' _ ｦ ｱ ｳ ｴ ｵ ｶ ｷ ｹ ｺ ｻ ｼ ｽ ｾ ｿ ﾀ ﾁ ﾂ ﾃ ﾄ ﾅ ﾆ ﾇ ﾈ "
            "ﾉ ﾊ ﾋ ﾌ ﾍ ﾎ ﾏ ﾐ ﾑ ﾒ ﾓ ﾔ ﾕ ﾖ ﾗ ﾘ ﾙ ﾚ ﾛ ﾜ ﾝ ﾞ ﾟ --rain-fall-delay-range 2-15 "
            "--rain-column-delay-range 3-9 --rain-time 15 --symbol-swap-chance 0.005 --color-swap-chance 0.001 "
            "--resolve-delay 3 --final-gradient-stops 92be92 336b33 --final-gradient-steps 12 "
            "--final-gradient-frames 3 --final-gradient-direction radial"
        ),
    )
    highlight_color: Color = argutils.ArgSpec(
        name="--highlight-color",
        type=argutils.ColorArg.type_parser,
        default=Color("#dbffdb"),
        metavar=argutils.ColorArg.METAVAR,
        help="Color for the bottom of the rain column.",
    )  # pyright: ignore[reportAssignmentType]
    "Color : Color for the bottom of the rain column."

    rain_color_gradient: tuple[Color, ...] = argutils.ArgSpec(
        name="--rain-color-gradient",
        type=argutils.ColorArg.type_parser,
        nargs="+",
        action=argutils.TupleAction,
        default=(Color("#92be92"), Color("#185318")),
        metavar=argutils.ColorArg.METAVAR,
        help="Space separated, unquoted, list of colors for the rain gradient. Colors are selected from the "
        "gradient randomly. If only one color is provided, the characters will be displayed in that color.",
    )  # pyright: ignore[reportAssignmentType]
    (
        "tuple[Color, ...] : Tuple of colors for the rain gradient. If only one color is provided, the characters "
        "will be displayed in that color."
    )

    rain_symbols: tuple[str, ...] = argutils.ArgSpec(
        name="--rain-symbols",
        nargs="+",
        action=argutils.TupleAction,
        type=argutils.Symbol.type_parser,
        default=MATRIX_SYMBOLS_COMMON + MATRIX_SYMBOLS_KATA,
        metavar=argutils.Symbol.METAVAR,
        help="Space separated, unquoted, list of symbols to use for the rain.",
    )  # pyright: ignore[reportAssignmentType]
    "tuple[str, ...] : Tuple of symbols to use for the rain."

    rain_fall_delay_range: tuple[int, int] = argutils.ArgSpec(
        name="--rain-fall-delay-range",
        type=argutils.PositiveIntRange.type_parser,
        default=(2, 15),
        metavar=argutils.PositiveIntRange.METAVAR,
        help="Range for the speed of the falling rain as determined by the delay between rows. Actual delay is "
        "randomly selected from the range.",
    )  # pyright: ignore[reportAssignmentType]
    (
        "tuple[int, int] : Speed of the falling rain as determined by the delay between rows. Actual delay is "
        "randomly selected from the range."
    )

    rain_column_delay_range: tuple[int, int] = argutils.ArgSpec(
        name="--rain-column-delay-range",
        type=argutils.PositiveIntRange.type_parser,
        default=(3, 9),
        metavar=argutils.PositiveIntRange.METAVAR,
        help="Range of frames to wait between adding new rain columns.",
    )  # pyright: ignore[reportAssignmentType]
    "tuple[int, int] : Range of frames to wait between adding new rain columns."

    rain_time: int = argutils.ArgSpec(
        name="--rain-time",
        type=argutils.PositiveInt.type_parser,
        default=15,
        metavar=argutils.PositiveInt.METAVAR,
        help="Time, in seconds, to display the rain effect before transitioning to the input text.",
    )  # pyright: ignore[reportAssignmentType]
    "int : Time, in seconds, to display the rain effect before transitioning to the input text."

    symbol_swap_chance: float = argutils.ArgSpec(
        name="--symbol-swap-chance",
        type=argutils.NonNegativeRatio.type_parser,
        default=0.005,
        metavar=argutils.NonNegativeRatio.METAVAR,
        help="Probability of swapping a character's symbol on each tick, from 0 to 1. Set to 0 to disable.",
    )  # pyright: ignore[reportAssignmentType]
    "float : Probability of swapping a character's symbol on each tick, from 0 to 1. Set to 0 to disable."

    color_swap_chance: float = argutils.ArgSpec(
        name="--color-swap-chance",
        type=argutils.NonNegativeRatio.type_parser,
        default=0.001,
        metavar=argutils.NonNegativeRatio.METAVAR,
        help="Probability of swapping a character's color on each tick, from 0 to 1. Set to 0 to disable.",
    )  # pyright: ignore[reportAssignmentType]
    "float : Probability of swapping a character's color on each tick, from 0 to 1. Set to 0 to disable."

    resolve_delay: int = argutils.ArgSpec(
        name="--resolve-delay",
        type=argutils.PositiveInt.type_parser,
        default=3,
        metavar=argutils.PositiveInt.METAVAR,
        help="Number of frames to wait between resolving the next group of characters. "
        "This is used to adjust the speed of the final resolve phase.",
    )  # pyright: ignore[reportAssignmentType]
    (
        "int : Number of frames to wait between resolving the next group of characters. This is used to "
        "adjust the speed of the final resolve phase."
    )

    final_gradient_stops: tuple[Color, ...] = FinalGradientStopsArg(
        default=(Color("#92be92"), Color("#336b33")),
    )  # pyright: ignore[reportAssignmentType]
    (
        "tuple[Color, ...] : Tuple of colors for the final color gradient. If only one color is provided, the "
        "characters will be displayed in that color."
    )

    final_gradient_steps: tuple[int, ...] | int = FinalGradientStepsArg(
        default=12,
    )  # pyright: ignore[reportAssignmentType]
    (
        "tuple[int, ...] | int : Int or Tuple of ints for the number of gradient steps to use. More steps will "
        "create a smoother and longer gradient animation."
    )

    final_gradient_frames: int = FinalGradientFramesArg(
        default=3,
    )  # pyright: ignore[reportAssignmentType]
    "int : Number of frames to display each gradient step. Increase to slow down the gradient animation."

    final_gradient_direction: Gradient.Direction = FinalGradientDirectionArg(
        default=Gradient.Direction.RADIAL,
    )  # pyright: ignore[reportAssignmentType]
    "Gradient.Direction : Direction of the final gradient."


class MatrixIterator(BaseEffectIterator[MatrixConfig]):
    """Iterator for the Matrix effect."""

    class RainColumn:
        """Rain column for the Matrix effect."""

        def __init__(
            self,
            characters: list[EffectCharacter],
            terminal: Terminal,
            config: MatrixConfig,
            rain_colors: Gradient,
        ) -> None:
            """Initialize the rain column."""
            self.terminal = terminal
            self.config = config
            self.characters: list[EffectCharacter] = characters
            self.pending_characters: list[EffectCharacter] = []
            self.matrix_symbols: tuple[str, ...] = config.rain_symbols
            self.rain_colors = rain_colors
            self.column_drop_chance = 0.08
            self.setup_column("rain")

        def setup_column(self, phase: str) -> None:
            """Set up the rain column for the specified phase."""
            self.pending_characters.clear()
            self.phase = phase
            self.is_full = False
            for character in self.characters:
                self.terminal.set_character_visibility(character, is_visible=False)
                self.pending_characters.append(character)
                character.motion.current_coord = character.input_coord
            self.visible_characters: list[EffectCharacter] = []
            if self.phase == "fill":
                self.base_rain_fall_delay = random.randint(
                    max(self.config.rain_fall_delay_range[0] // 3, 1),
                    max(self.config.rain_fall_delay_range[1] // 3, 1),
                )
            else:
                self.base_rain_fall_delay = random.randint(
                    self.config.rain_fall_delay_range[0],
                    self.config.rain_fall_delay_range[1],
                )
            self.active_rain_fall_delay = 0
            if self.phase == "rain":
                self.length = random.randint(max(1, int(len(self.characters) * 0.1)), len(self.characters))
            else:
                self.length = len(self.characters)
            self.hold_time = 0
            if self.length == len(self.characters):
                self.hold_time = random.randint(20, 45)

        def trim_column(self) -> None:
            """Trim the rain column."""
            if not self.visible_characters:
                return
            popped_char = self.visible_characters.pop(0)
            self.terminal.set_character_visibility(popped_char, is_visible=False)
            if len(self.visible_characters) > 1:
                self.fade_last_character()

        def drop_column(self) -> None:
            """Drop the rain column."""
            remaining_characters = []
            for character in self.visible_characters:
                next_coord = Coord(
                    character.motion.current_coord.column,
                    character.motion.current_coord.row - 1,
                )
                character.motion.current_coord = next_coord
                if next_coord.row < self.terminal.canvas.bottom:
                    self.terminal.set_character_visibility(character, is_visible=False)
                else:
                    remaining_characters.append(character)
            self.visible_characters = remaining_characters

        def fade_last_character(self) -> None:
            """Fade the last character in the rain column."""
            darker_color = Animation.adjust_color_brightness(random.choice(self.rain_colors[-3:]), 0.65)  # type: ignore[arg-type]
            self.visible_characters[0].animation.set_appearance(
                self.visible_characters[0].animation.current_character_visual.symbol,
                colors=ColorPair(fg=darker_color),
            )

        def resolve_char(self) -> EffectCharacter:
            """Resolve a character in the rain column.

            Returns:
                EffectCharacter: The resolved character.

            """
            return self.visible_characters.pop(random.randint(0, len(self.visible_characters) - 1))

        def tick(self) -> None:
            """Advance the rain column by one tick."""
            if not self.active_rain_fall_delay:
                if self.pending_characters:
                    next_char = self.pending_characters.pop(0)
                    next_char.animation.set_appearance(
                        random.choice(self.matrix_symbols),
                        colors=ColorPair(fg=self.config.highlight_color),
                    )
                    previous_character = self.visible_characters[-1] if self.visible_characters else None
                    # if there is a previous character, remove the highlight
                    if previous_character:
                        previous_character.animation.set_appearance(
                            previous_character.animation.current_character_visual.symbol,
                            colors=ColorPair(
                                fg=random.choice(self.rain_colors),
                            ),
                        )
                    self.terminal.set_character_visibility(next_char, is_visible=True)
                    self.visible_characters.append(next_char)

                # if no pending characters, but still visible characters, trim the column
                # unless the column is the full height of the canvas, then respect the hold
                # time before trimming
                elif self.visible_characters:
                    # adjust the bottom character color to remove the lightlight.
                    # always do this on the first hold frame, then
                    # randomly adjust the bottom character's color
                    # this is separately handled from the rest to prevent the
                    # highlight color from being replaced before appropriate
                    if (
                        self.visible_characters[-1].animation.current_character_visual.colors
                        and self.visible_characters[-1].animation.current_character_visual.colors.fg
                        == self.config.highlight_color
                    ):
                        self.visible_characters[-1].animation.set_appearance(
                            self.visible_characters[-1].animation.current_character_visual.symbol,
                            colors=ColorPair(fg=random.choice(self.rain_colors)),
                        )

                    if self.hold_time:
                        self.hold_time -= 1
                    elif self.phase == "rain":
                        if random.random() < self.column_drop_chance:
                            self.drop_column()
                        self.trim_column()

                # if the column is longer than the preset length while still adding characters, trim it
                if len(self.visible_characters) > self.length:
                    self.trim_column()
                self.active_rain_fall_delay = self.base_rain_fall_delay

            else:
                self.active_rain_fall_delay -= 1

            # randomly change the symbol and/or color of the characters
            next_color: Color | None
            for character in self.visible_characters:
                symbol_swap = random.random() < self.config.symbol_swap_chance
                next_symbol = random.choice(self.matrix_symbols) if symbol_swap else None
                color_swap = random.random() < self.config.color_swap_chance
                next_color = random.choice(self.rain_colors) if color_swap else None
                if not (symbol_swap or color_swap):
                    continue
                current_visual = character.animation.current_character_visual
                if not symbol_swap:
                    next_symbol = current_visual.symbol
                current_color = current_visual.colors.fg if current_visual.colors else None
                if not color_swap:
                    next_color = current_color
                if next_symbol != current_visual.symbol or next_color != current_color:
                    character.animation.set_appearance(next_symbol, colors=ColorPair(fg=next_color))

    def __init__(self, effect: Matrix) -> None:
        """Initialize the Matrix effect iterator."""
        super().__init__(effect)
        if self.terminal.visible_top >= 4 and self.terminal.visible_top * self.terminal.visible_right >= 256:
            self.terminal.enable_row_cache()
        self.pending_columns: list[MatrixIterator.RainColumn] = []
        self.character_final_color_map: dict[EffectCharacter, ColorPair] = {}
        self.active_columns: list[MatrixIterator.RainColumn] = []
        self.full_columns: list[MatrixIterator.RainColumn] = []
        self.rain_colors = Gradient(*self.config.rain_color_gradient, steps=6)
        self.column_delay = 0
        self.resolve_delay = self.config.resolve_delay
        self.final_frame_shown = False
        self.rain_complete = False
        self.phase = "rain"
        self.build()
        self.rain_start = self.terminal.clock()

    @staticmethod
    def _has_input_colors(character: EffectCharacter) -> bool:
        return any((character.animation.input_fg_color, character.animation.input_bg_color))

    def build(self) -> None:
        """Build the initial state of the effect."""
        resolve_gradients: dict[Color, Gradient] = {}

        def resolve_gradient(color: Color) -> Gradient:
            """Reuse a resolve gradient for each endpoint color during scene construction."""
            if color not in resolve_gradients:
                resolve_gradients[color] = Gradient(self.config.highlight_color, color, steps=8)
            return resolve_gradients[color]

        final_gradient_mapping: dict[Coord, Color] = {}
        if self.terminal.config.existing_color_handling != "dynamic":
            final_gradient = Gradient(*self.config.final_gradient_stops, steps=self.config.final_gradient_steps)
            final_gradient_mapping = final_gradient.build_coordinate_color_mapping(
                self.terminal.canvas.text_bottom,
                self.terminal.canvas.text_top,
                self.terminal.canvas.text_left,
                self.terminal.canvas.text_right,
                self.config.final_gradient_direction,
            )
        for character in self.terminal.get_characters():
            if self.terminal.config.existing_color_handling == "dynamic":
                self.character_final_color_map[character] = ColorPair(
                    fg=character.animation.input_fg_color,
                    bg=character.animation.input_bg_color,
                )
            else:
                self.character_final_color_map[character] = ColorPair(
                    fg=final_gradient_mapping[character.input_coord],
                )
            final_fg_color = self.character_final_color_map[character].fg
            final_bg_color = self.character_final_color_map[character].bg
            resolve_scn = character.animation.new_scene(scene_id="resolve")
            if self.terminal.config.existing_color_handling == "dynamic":
                fg_gradient = resolve_gradient(final_fg_color) if final_fg_color else None
                bg_gradient = resolve_gradient(final_bg_color) if final_bg_color else None
                if fg_gradient or bg_gradient:
                    resolve_scn.apply_gradient_to_symbols(
                        character.input_symbol,
                        self.config.final_gradient_frames,
                        fg_gradient=fg_gradient,
                        bg_gradient=bg_gradient,
                    )
                else:
                    resolve_scn.add_frame(
                        character.input_symbol,
                        self.config.final_gradient_frames,
                        colors=ColorPair(),
                    )
            else:
                assert final_fg_color is not None
                for color in resolve_gradient(final_fg_color):
                    resolve_scn.add_frame(
                        character.input_symbol,
                        self.config.final_gradient_frames,
                        colors=ColorPair(fg=color),
                    )

        for column_chars in self.terminal.get_characters_grouped(
            argutils.CharacterGroup.COLUMN_LEFT_TO_RIGHT,
            outer_fill_chars=True,
            inner_fill_chars=True,
        ):
            column_chars.reverse()
            self.pending_columns.append(
                MatrixIterator.RainColumn(column_chars, self.terminal, self.config, self.rain_colors),
            )
        random.shuffle(self.pending_columns)

    def __next__(self) -> str:  # noqa: PLR0915
        """Return the next frame in the animation."""
        if self.phase in ("rain", "fill"):
            if not self.column_delay:
                if self.phase == "rain":
                    for _ in range(random.randint(1, 3)):
                        if self.pending_columns:
                            self.active_columns.append(self.pending_columns.pop(0))
                else:
                    while self.pending_columns:
                        self.active_columns.append(self.pending_columns.pop(0))
                if self.phase == "rain":
                    self.column_delay = random.randint(
                        self.config.rain_column_delay_range[0],
                        self.config.rain_column_delay_range[1],
                    )
                else:
                    self.column_delay = 1
            else:
                self.column_delay -= 1
            for column in self.active_columns:
                column.tick()

                if not column.pending_characters:
                    if column.phase == "fill" and not column.is_full:
                        self.full_columns.append(column)
                        column.is_full = True
                    elif not column.visible_characters:
                        column.setup_column(self.phase)
                        self.pending_columns.append(column)

            self.active_columns = [column for column in self.active_columns if column.visible_characters]
            if (
                self.phase == "fill"
                and not self.pending_columns
                and all((not column.pending_characters and column.phase == "fill") for column in self.active_columns)
            ):
                self.phase = "resolve"
                self.active_columns.clear()

            if (
                self.phase == "rain"
                and self.config.rain_time > 0
                and self.terminal.clock() - self.rain_start > self.config.rain_time
            ):
                self.rain_complete = True
                self.phase = "fill"
                for column in self.active_columns:
                    column.hold_time = 0
                    column.column_drop_chance = 1
                for column in self.pending_columns:
                    column.setup_column(self.phase)

        elif self.phase == "resolve":
            for column in self.full_columns:
                column.tick()
                if column.visible_characters:
                    if not self.resolve_delay:
                        for _ in range(random.randint(1, 4)):
                            if column.visible_characters:
                                next_char = column.resolve_char()
                                if next_char.input_symbol != " " or self._has_input_colors(next_char):
                                    next_char.animation.activate_scene("resolve")
                                    self.active_characters.add(next_char)
                                else:
                                    self.terminal.set_character_visibility(next_char, is_visible=False)
                        self.resolve_delay = self.config.resolve_delay
                    else:
                        self.resolve_delay -= 1

            self.full_columns = [column for column in self.full_columns if column.visible_characters]

        if (
            self.full_columns
            or self.active_columns
            or self.active_characters
            or self.pending_columns
            or not self.rain_complete
        ):
            self.update()
            return self.frame
        if not self.final_frame_shown:
            self.final_frame_shown = True
            self.update()
            return self.frame
        raise StopIteration


class Matrix(BaseEffect[MatrixConfig]):
    """Matrix digital rain effect.

    Attributes:
        effect_config (MatrixConfig): Configuration for the Matrix effect.
        terminal_config (TerminalConfig): Configuration for the terminal.

    """

    @property
    def _config_cls(self) -> type[MatrixConfig]:
        return MatrixConfig

    @property
    def _iterator_cls(self) -> type[MatrixIterator]:
        return MatrixIterator
