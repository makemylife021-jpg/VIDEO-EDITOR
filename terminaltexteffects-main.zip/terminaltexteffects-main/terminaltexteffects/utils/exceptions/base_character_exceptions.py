"""Custom exceptions for handling errors related to EffectCharacters in the terminaltexteffects package."""

from __future__ import annotations

from typing import TYPE_CHECKING

from terminaltexteffects.utils.exceptions.base_terminaltexteffects_exception import TerminalTextEffectsError

if TYPE_CHECKING:
    from terminaltexteffects import Coord, EventHandler, Path, Scene, Waypoint
    from terminaltexteffects.engine.world import Body
    from terminaltexteffects.utils.geometry3d import Vec3


class InvalidSymbolError(TerminalTextEffectsError):
    """Raised when a character or visual symbol violates the display-cell contract."""

    def __init__(self, symbol: str) -> None:
        """Initialize an `InvalidSymbolError`.

        Args:
            symbol (str): Invalid symbol supplied by the caller or input stream.

        """
        self.symbol = symbol
        self.message = (
            "Symbols must contain exactly one printable Unicode code point with a terminal width of one or two cells. "
            f"Received: {symbol!r}."
        )
        super().__init__(self.message)


class EventRegistrationCallerError(TerminalTextEffectsError):
    """Raised when an event is registered with an invalid event -> caller relationship.

    Each event can only be registered with a related caller type. This error is raised when an event is registered with
    a caller that is not of the required type. For example, a Scene will never trigger a Path related event,
    and vice versa.

    The following are the valid caller types for each event:

    Event -> Caller

        - SEGMENT_* -> Path
        - PATH_*    -> Path
        - SCENE_*   -> Scene
        - ATTACHED, DETACHED -> Body
    """

    def __init__(
        self,
        event: EventHandler.Event,
        caller: Scene | Waypoint | Path | Body | str,
        required: type[Scene | Waypoint | Path | Body],
    ) -> None:
        """Initialize an EventRegistrationCallerError.

        Args:
            event (EventHandler.Event): The event that was registered.
            caller (Scene | Waypoint | Path | Body | str): The object provided to trigger the event.
            required (Scene | Waypoint | Path | Body): The valid caller types for the event.

        """
        self.event = event
        self.caller = caller
        self.required = required
        self.message = (
            f"Event `{event.name}` registered with caller type `{caller.__class__.__name__}`. Event `{event.name}` "
            f"requires caller type `{required.__name__}`."
        )
        super().__init__(self.message)


class EventRegistrationTargetError(TerminalTextEffectsError):
    """Raised when an event is registered with an invalid action -> target relationship.

    Each event action can only be registered with a related target type. This error is raised when an event action
    is registered with a target that is not of the required type. For example, an ACTIVATE_SCENE action
    will can not activate on a Path target.

    The following are the valid target types for each action:

    Action -> Target

        - *_SCENE          -> Scene
        - *_PATH           -> Path
        - SET_LAYER        -> Int
        - SET_COORDINATE   -> Coord
        - CALLBACK         -> EventHandler.Callback
        - RESET_APPEARANCE -> None
        - ATTACH           -> Body
        - DETACH           -> None
    """

    def __init__(
        self,
        action: EventHandler.Action,
        target: Scene | Path | Body | int | Coord | Vec3 | EventHandler.Callback | str | None,
        required: type[Scene | Path | Body | int | Coord | Vec3 | EventHandler.Callback | str | None],
    ) -> None:
        """Initialize an EventRegistrationTargetError.

        Args:
            action (EventHandler.Action): The action that was registered.
            target (Scene | Path | Body | int | Coord | Vec3 | EventHandler.Callback | str | None): The target
                provided to the action.
            required (type[Scene | Path | Body | int | Coord | Vec3 | EventHandler.Callback | str | None]): The valid
                target types.

        """
        self.action = action
        self.target = target
        self.required = required
        self.message = (
            f"Event action `{action.name}` registered with target type `{target.__class__.__name__}`. "
            f"Action `{action.name}` requires target type `{required.__name__}`."
        )
        super().__init__(self.message)


class DuplicateEventRegistrationError(TerminalTextEffectsError):
    """Raised when attempting to register a duplicate event-action combination.

    This error is raised when trying to register the same event-caller-action-target combination
    that has already been registered. Each unique combination can only be registered once to prevent
    duplicate event handling.

    """

    def __init__(
        self,
        event: EventHandler.Event,
        caller: Scene | Waypoint | Path | Body,
        action: EventHandler.Action,
        target: Scene | Path | Body | int | Coord | Vec3 | EventHandler.Callback | str | None,
    ) -> None:
        """Initialize a DuplicateEventRegistrationError.

        Args:
            event (EventHandler.Event): The event that was already registered.
            caller (Scene | Waypoint | Path | Body): The caller object that was already registered.
            action (EventHandler.Action): The action that was already registered.
            target (Scene | Path | Body | int | Coord | Vec3 | EventHandler.Callback | str | None): The target that was
                already registered.

        """
        self.event = event
        self.caller = caller
        self.action = action
        self.target = target
        self.message = (
            f"Duplicate event registration: Event `{event.name}` with caller `{caller.__class__.__name__}`, "
            f"action `{action.name}`, and target `{target.__class__.__name__ if target is not None else 'None'}` "
            f"has already been registered."
        )
        super().__init__(self.message)


class EventRegistrationNodeError(TerminalTextEffectsError):
    """Raised when a body's event handler is given an event or action that only characters have.

    Bodies have no animation, layer or appearance, so a body's handler takes the path and attach events and the
    node actions: `ACTIVATE_PATH`, `DEACTIVATE_PATH`, `SET_COORDINATE`, `ATTACH`, `DETACH` and `CALLBACK`.
    """

    def __init__(self, event: EventHandler.Event, action: EventHandler.Action) -> None:
        """Initialize an EventRegistrationNodeError.

        Args:
            event (EventHandler.Event): The event that was registered.
            action (EventHandler.Action): The action that was registered.

        """
        self.event = event
        self.action = action
        self.message = (
            f"A body can't register event `{event.name}` with action `{action.name}`. Bodies take path and attach "
            "events with ACTIVATE_PATH, DEACTIVATE_PATH, SET_COORDINATE, ATTACH, DETACH or CALLBACK."
        )
        super().__init__(self.message)
