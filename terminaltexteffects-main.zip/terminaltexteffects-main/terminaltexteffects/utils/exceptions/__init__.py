"""TerminalTextEffects exceptions module."""

from terminaltexteffects.utils.exceptions.animation_exceptions import (
    ActivateEmptySceneError,
    AnimationSceneError,
    DuplicateSceneIDError,
    FrameDurationError,
    SceneNotFoundError,
)
from terminaltexteffects.utils.exceptions.base_character_exceptions import (
    DuplicateEventRegistrationError,
    EventRegistrationCallerError,
    EventRegistrationNodeError,
    EventRegistrationTargetError,
    InvalidSymbolError,
)
from terminaltexteffects.utils.exceptions.motion_exceptions import (
    ActivateEmptyPathError,
    DuplicatePathIDError,
    DuplicateWaypointIDError,
    PathInvalidSpeedError,
    PathNotFoundError,
    WaypointNotFoundError,
)
from terminaltexteffects.utils.exceptions.terminal_exceptions import (
    EmptyInputError,
    InvalidCharacterCoordinateError,
    InvalidCharacterError,
    InvalidCharacterGroupError,
    InvalidCharacterOrderError,
    InvalidCharacterSortError,
    InvalidCharacterVisibilityError,
    InvalidColorSortError,
    TerminalOutputActiveError,
    TerminalOutputNotPreparedError,
    UnsupportedAnsiSequenceError,
)
