"""TerminalTextEffects utilities module."""
